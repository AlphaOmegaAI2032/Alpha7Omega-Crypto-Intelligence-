import type { HolderProfile, HolderSlice } from "@/lib/market/types";
import type { WhaleWallet } from "@/lib/market/intel";

const STATUS_FILL: Record<string, string> = {
  drip: "var(--color-down)",
  silent: "var(--color-wait)",
  cex: "var(--color-accent)",
  lp: "var(--color-up)",
  kol: "var(--color-muted)",
};

export function WhaleMap({
  holders,
  whales,
  symbol,
}: {
  holders: HolderProfile | null;
  whales: WhaleWallet[];
  symbol: string;
}) {
  const slices = (holders?.slices || []).filter((s) => s.pct > 0);
  const poolPct = guessPool(slices, holders);
  const overhang = Math.max(0, (holders?.top10Pct || 0) - poolPct);

  return (
    <div className="space-y-4">
      <CliffStack slices={slices} poolPct={poolPct} symbol={symbol} overhang={overhang} inventory={holders?.inventoryToPool} />
      {slices.length ? <SliceDonut slices={slices} top100={holders?.top100Pct ?? 0} /> : null}
      {whales.length ? <FlowArrows whales={whales} /> : null}
    </div>
  );
}

function guessPool(slices: HolderSlice[], holders: HolderProfile | null) {
  const lp = slices.find((s) => /lp|pancake|raydium|orca|pool/i.test(s.label));
  if (lp) return lp.pct;
  if (holders?.inventoryToPool?.includes("×")) {
    const n = Number(holders.inventoryToPool.replace(/[^\d.]/g, ""));
    if (n > 1) return Math.max(0.2, 10 / n);
  }
  return 0.8;
}

function CliffStack({
  slices,
  poolPct,
  symbol,
  overhang,
  inventory,
}: {
  slices: HolderSlice[];
  poolPct: number;
  symbol: string;
  overhang: number;
  inventory?: string;
}) {
  const rows = slices.slice(0, 8);
  const max = Math.max(poolPct, ...rows.map((s) => s.pct), 1);
  return (
    <section className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium">Inventory cliff</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted">
        The thin bar is the DEX pool. Every block above it is a wallet that can sell through that pool. If the stack
        is tall, one bag breaks {symbol}.
      </p>
      <div className="mt-4 space-y-1.5">
        {rows.map((s) => (
          <div key={s.label}>
            <div className="mb-0.5 flex items-baseline justify-between gap-2 font-mono text-[11px]">
              <span className="truncate text-muted">{s.label}</span>
              <span className="tabular text-fg">{s.pct.toFixed(2)}%</span>
            </div>
            <div className="h-3 overflow-hidden rounded-sm bg-elevated">
              <div
                className="h-full bg-fg/70"
                style={{ width: `${Math.max(4, (s.pct / max) * 100)}%` }}
              />
            </div>
          </div>
        ))}
        <div className="pt-2">
          <div className="mb-0.5 flex items-baseline justify-between gap-2 font-mono text-[11px]">
            <span className="text-up">DEX pool (what the book can actually eat)</span>
            <span className="tabular text-up">{poolPct.toFixed(2)}%</span>
          </div>
          <div className="h-4 overflow-hidden rounded-sm bg-elevated">
            <div className="h-full bg-up" style={{ width: `${Math.max(6, (poolPct / max) * 100)}%` }} />
          </div>
        </div>
      </div>
      <p className="mt-3 font-mono text-[11px] text-faint">
        Overhang ~{overhang.toFixed(1)} pts of top-10 vs pool
        {inventory ? ` · inventory/pool ${inventory}` : ""}. Everything above the green bar is the cliff.
      </p>
    </section>
  );
}

function SliceDonut({ slices, top100 }: { slices: HolderSlice[]; top100: number }) {
  const w = 320;
  const h = 220;
  const cx = 110;
  const cy = 110;
  const r = 78;
  const r0 = 44;
  const total = Math.max(100, slices.reduce((s, x) => s + x.pct, 0));
  let acc = 0;
  const colors = ["#eceae4", "#8c8b86", "#3ecf8e", "#d6a84f", "#e23c32", "#6b6a66", "#d9d4c8", "#3a3a42"];
  const arcs = slices.slice(0, 8).map((s, i) => {
    const a0 = (acc / total) * Math.PI * 2 - Math.PI / 2;
    acc += s.pct;
    const a1 = (acc / total) * Math.PI * 2 - Math.PI / 2;
    return { ...s, a0, a1, color: colors[i % colors.length] };
  });

  return (
    <section className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium">Who actually owns it</h3>
      <p className="mt-1 text-sm text-muted">Top 100 hold {top100}%. The donut is the labelled bag, not Twitter followers.</p>
      <div className="mt-3 flex flex-col items-center gap-4 sm:flex-row">
        <svg viewBox={`0 0 ${w} ${h}`} className="h-[220px] w-full max-w-[320px]" role="img" aria-label="Holder donut">
          {arcs.map((a) => (
            <path key={a.label} d={annular(cx, cy, r0, r, a.a0, a.a1)} fill={a.color} opacity="0.9" />
          ))}
          <circle cx={cx} cy={cy} r={r0 - 2} fill="var(--color-surface)" />
          <text x={cx} y={cy - 4} textAnchor="middle" fill="var(--color-fg)" fontSize="14" fontFamily="IBM Plex Mono, monospace">
            {top100.toFixed(0)}%
          </text>
          <text x={cx} y={cy + 12} textAnchor="middle" fill="var(--color-muted)" fontSize="9" fontFamily="IBM Plex Mono, monospace">
            top 100
          </text>
        </svg>
        <ul className="w-full space-y-1.5 text-xs">
          {arcs.map((a) => (
            <li key={a.label} className="flex items-center gap-2">
              <span className="size-2 shrink-0 rounded-sm" style={{ background: a.color }} />
              <span className="min-w-0 flex-1 truncate text-muted">{a.label}</span>
              <span className="font-mono tabular text-fg">{a.pct.toFixed(1)}%</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function annular(cx: number, cy: number, r0: number, r1: number, a0: number, a1: number) {
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const p = (r: number, a: number) => [cx + Math.cos(a) * r, cy + Math.sin(a) * r];
  const [x0, y0] = p(r1, a0);
  const [x1, y1] = p(r1, a1);
  const [x2, y2] = p(r0, a1);
  const [x3, y3] = p(r0, a0);
  return `M ${x0} ${y0} A ${r1} ${r1} 0 ${large} 1 ${x1} ${y1} L ${x2} ${y2} A ${r0} ${r0} 0 ${large} 0 ${x3} ${y3} Z`;
}

function FlowArrows({ whales }: { whales: WhaleWallet[] }) {
  const drip = whales.filter((w) => w.status === "drip" || w.verdict === "DRIP" || w.verdict === "DUMPING");
  const silent = whales.filter((w) => w.status === "silent");
  const cex = whales.filter((w) => w.status === "cex");
  const lp = whales.filter((w) => w.status === "lp");

  const nodes = [
    { id: "silent", label: "Silent bags", n: silent.length, fill: "var(--color-wait)" },
    { id: "drip", label: "Drip / dump", n: drip.length, fill: "var(--color-down)" },
    { id: "cex", label: "CEX routers", n: cex.length, fill: "var(--color-accent)" },
    { id: "lp", label: "LP / pool", n: lp.length, fill: "var(--color-up)" },
  ];

  return (
    <section className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium">How the bags move</h3>
      <p className="mt-1 text-sm text-muted">
        Silent wallets sit. Drip wallets feed the pool. CEX routers are inventory, not believers. If drip is live,
        the chart is being sold, not discovered.
      </p>
      <svg viewBox="0 0 360 150" className="mt-3 h-[150px] w-full" role="img" aria-label="Whale flow">
        {nodes.map((n, i) => {
          const x = 18 + (i % 2) * 180;
          const y = 16 + Math.floor(i / 2) * 68;
          return (
            <g key={n.id}>
              <rect x={x} y={y} width="150" height="48" rx="8" fill="var(--color-elevated)" stroke="var(--color-line)" />
              <text x={x + 12} y={y + 20} fill="var(--color-muted)" fontSize="10" fontFamily="IBM Plex Sans, sans-serif">
                {n.label}
              </text>
              <text x={x + 12} y={y + 38} fill={n.fill} fontSize="16" fontFamily="IBM Plex Mono, monospace">
                {n.n}
              </text>
            </g>
          );
        })}
        <path d="M 168 40 H 196" stroke="var(--color-down)" strokeWidth="2" markerEnd="url(#arr)" fill="none" />
        <path d="M 93 64 V 84" stroke="var(--color-wait)" strokeWidth="2" fill="none" />
        <defs>
          <marker id="arr" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 Z" fill="var(--color-down)" />
          </marker>
        </defs>
      </svg>
      <ul className="space-y-2 text-sm">
        {whales.slice(0, 5).map((w) => (
          <li key={w.address || w.label} className="flex items-start justify-between gap-2">
            <span className="min-w-0">
              <span className="font-medium text-fg">{w.label}</span>
              <span className="mt-0.5 block text-xs text-muted">{w.note}</span>
            </span>
            <span className={`shrink-0 font-mono text-[11px] uppercase ${w.verdict === "DRIP" || w.verdict === "DUMPING" ? "text-down" : "text-faint"}`}>
              {w.verdict}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
