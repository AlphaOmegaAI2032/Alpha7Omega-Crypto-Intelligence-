import { Link } from "@tanstack/react-router";
import { BOOK, EARLY_CRASH, EDGE, IGNORE, MATRIX } from "@/lib/market/desk-book";
import { pct, px } from "@/lib/market/format";
import { CLOCK, SESSION, STAMPS } from "@/lib/market/tape-clock";
import { useState } from "react";

type Quote = { price: number; chg: number | null };

export function MatrixPanel({ quotes }: { quotes: Record<string, Quote> }) {
  const [stamp, setStamp] = useState<(typeof STAMPS)[number]>("09:50");
  const clock = CLOCK.find((c) => c.t === stamp) ?? CLOCK[0];

  return (
    <div className="space-y-4">
      <section className="glass rounded-xl p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-faint">
          {SESSION.weekday} {SESSION.date} · {SESSION.tz}
        </p>
        <h2 className="mt-1 text-sm font-medium">Isolated book — stamp-indexed</h2>
        <p className="mt-1 text-sm text-muted">{SESSION.note}</p>
        <div className="mt-3 flex flex-wrap gap-1">
          {STAMPS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStamp(s)}
              className={`h-11 rounded-md px-3 font-mono text-xs ${
                stamp === s ? "bg-accent text-accent-fg" : "bg-surface text-muted"
              }`}
            >
              {s} SAST
            </button>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">
          <span className="font-mono text-wait">{clock.t}</span> · {clock.body}
        </p>
      </section>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {BOOK.slice(0, 9).map((b) => {
            const q = quotes[b.sym.toUpperCase()];
            return (
              <article key={b.id} className="glass rounded-xl p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <Link to="/ta" search={{ s: `${b.sym}USDT` }} className="font-mono font-semibold hover:underline">
                    {b.sym}
                  </Link>
                  <span
                    className={`font-mono text-[10px] uppercase ${
                      b.stance.includes("long") ? "text-up" : b.stance.includes("short") || b.stance === "fade" ? "text-down" : "text-muted"
                    }`}
                  >
                    {b.stance}
                  </span>
                </div>
                <div className="mt-2 flex items-baseline justify-between">
                  <span className="font-mono tabular">{px(q?.price ?? b.stampPx)}</span>
                  <span className={`font-mono text-xs tabular ${(q?.chg ?? b.stampChg) >= 0 ? "text-up" : "text-down"}`}>
                    {pct(q?.chg ?? b.stampChg)}
                  </span>
                </div>
                <p className="mt-2 text-xs text-muted">{b.trigger}</p>
                <p className="mt-1 font-mono text-[10px] text-faint">
                  Stop {b.stop} · {b.targets}
                </p>
              </article>
            );
          })}
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        {MATRIX.map((m) => (
          <article key={m.id} className="glass rounded-xl p-4">
            <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{m.call}</p>
            <h3 className="mt-1 text-sm font-medium">{m.title}</h3>
            <p className="mt-2 text-sm text-muted">{m.names}</p>
            <p className="mt-2 text-xs text-faint">{m.why}</p>
          </article>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <section className="glass rounded-xl p-4">
          <h3 className="text-sm font-medium">Fade watch — 1h red only</h3>
          <ul className="mt-3 space-y-2">
            {EARLY_CRASH.map((e) => (
              <li key={e.sym}>
                <span className="font-mono text-sm">{e.sym}</span>
                <p className="text-xs text-muted">{e.why}</p>
              </li>
            ))}
          </ul>
        </section>
        <section className="glass rounded-xl p-4">
          <h3 className="text-sm font-medium">Who to ignore</h3>
          <ul className="mt-3 space-y-2">
            {IGNORE.map((i) => (
              <li key={i.action}>
                <p className="text-sm">{i.action}</p>
                <p className="text-xs text-muted">{i.names}</p>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="glass rounded-xl p-4">
        <h3 className="text-sm font-medium">What the tape hid</h3>
        <ul className="mt-3 grid gap-3 md:grid-cols-2">
          {EDGE.slice(0, 6).map((e) => (
            <li key={e.title}>
              <p className="text-sm">{e.title}</p>
              <p className="mt-1 text-xs text-muted">{e.body}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
