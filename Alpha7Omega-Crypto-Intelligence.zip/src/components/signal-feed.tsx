import { Badge } from "@/components/ui/badge";
import { Sparkline } from "@/components/sparkline";
import { pct, usd } from "@/lib/market/format";
import { changeOf } from "@/lib/market/heat";
import { verdictClass, verdictLabel } from "@/lib/market/labels";
import { topInteresting } from "@/lib/market/signals";
import type { BubbleCoin, Timeframe } from "@/lib/market/types";

export function SignalFeed({
  coins,
  tf,
  onOpen,
}: {
  coins: BubbleCoin[];
  tf: Timeframe;
  onOpen: (c: BubbleCoin) => void;
}) {
  const rows = topInteresting(coins, tf, 8);
  if (!rows.length) return null;
  return (
    <div className="mt-4">
      <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-faint">
        What is actually interesting
      </div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {rows.map((c) => {
          const chg = changeOf(c, tf);
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => onOpen(c)}
              className="rounded-lg border border-line bg-surface px-3 py-3 text-left hover:border-line-strong"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-sm font-semibold">{c.symbol}</span>
                {c.verdict === "SHORT_HARD" || c.verdict === "FADE" || c.verdict === "BREAKOUT" ? (
                  <Badge className={verdictClass(c.verdict)}>{verdictLabel(c.verdict)}</Badge>
                ) : c.signal !== "NONE" ? (
                  <Badge className="bg-elevated text-muted">{c.signal}</Badge>
                ) : null}
              </div>
              <div className={`mt-1 font-mono text-sm tabular ${(chg ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                {pct(chg)}
              </div>
              <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted">
                {c.why || `${c.sector.toUpperCase()} · ${usd(c.mcap)}`}
              </p>
              {c.spark ? <Sparkline values={c.spark} className="mt-2 h-7 w-full" /> : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}
