import { useEffect, useRef } from "react";
import { changeOf, heatColor, heatScale } from "@/lib/market/heat";
import { fundingPct, pct, usd } from "@/lib/market/format";
import { SECTOR_LABEL } from "@/lib/market/sectors";
import type { BubbleCoin, Sector, Timeframe } from "@/lib/market/types";

export type { Timeframe };
export type SizeBy = "mcap" | "volume" | "heat" | "oi" | "turnover";
export type Layout = "pack" | "sector" | "cliff" | "galaxy" | "squeeze";

type Node = {
  coin: BubbleCoin;
  x: number;
  y: number;
  r: number;
  phase: number;
};

const SECTOR_ORDER: Sector[] = ["btc", "l1", "l2", "defi", "ai", "meme", "privacy", "tradfi", "other", "stable"];

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function sizeValue(c: BubbleCoin, sizeBy: SizeBy, tf: Timeframe): number {
  if (sizeBy === "volume") return Math.max(1, c.volume);
  if (sizeBy === "oi") return Math.max(1, c.oiUsd || c.hlOi || c.mcap * 0.04);
  if (sizeBy === "turnover") return Math.max(0.0001, (c.turnover || c.volMcap || 0.01) * Math.sqrt(Math.max(c.mcap, 1)));
  if (sizeBy === "heat") return Math.max(1, Math.abs(changeOf(c, tf) ?? 0) * Math.sqrt(Math.max(c.volume, 1)));
  return Math.max(1, c.mcap);
}

function spiralPack(nodes: Node[], W: number, H: number) {
  const cx = W / 2;
  const cy = H / 2 + 4;
  const sorted = [...nodes].sort((a, b) => b.r - a.r);
  const placed: Node[] = [];
  const golden = Math.PI * (3 - Math.sqrt(5));
  for (const n of sorted) {
    if (!placed.length) {
      n.x = cx;
      n.y = cy;
      placed.push(n);
      continue;
    }
    let found = false;
    for (let k = 0; k < 900; k++) {
      const rad = n.r + 6 + Math.sqrt(k) * 6.4;
      const ang = k * golden;
      const x = cx + Math.cos(ang) * rad;
      const y = cy + Math.sin(ang) * rad * (H / W);
      if (x - n.r < 3 || y - n.r < 3 || x + n.r > W - 3 || y + n.r > H - 3) continue;
      let ok = true;
      for (const p of placed) {
        const dx = x - p.x;
        const dy = y - p.y;
        const min = n.r + p.r + 1.5;
        if (dx * dx + dy * dy < min * min) {
          ok = false;
          break;
        }
      }
      if (!ok) continue;
      n.x = x;
      n.y = y;
      found = true;
      break;
    }
    if (!found) {
      n.x = 8 + n.r + (hash(n.coin.symbol) % Math.max(1, W - 16 - n.r * 2));
      n.y = 8 + n.r + ((hash(n.coin.name) >> 3) % Math.max(1, H - 16 - n.r * 2));
    }
    placed.push(n);
  }
}

function attract(nodes: Node[], W: number, H: number, layout: Layout) {
  for (const n of nodes) {
    let tx = W / 2;
    let ty = H / 2;
    if (layout === "sector") {
      const i = Math.max(0, SECTOR_ORDER.indexOf(n.coin.sector));
      const col = i % 5;
      const row = Math.floor(i / 5);
      tx = ((col + 0.5) / 5) * W;
      ty = ((row + 0.5) / 2) * H;
    } else if (layout === "cliff") {
      const s = n.coin.score / 100;
      tx = W * (0.18 + s * 0.7);
      ty = H * (0.52 - (n.coin.verdict === "BREAKOUT" ? 0.16 : 0) - (n.coin.chg24h ?? 0) / 380);
    } else if (layout === "galaxy") {
      if (n.coin.symbol === "BTC") {
        tx = W / 2;
        ty = H / 2;
      } else {
        const si = Math.max(0, SECTOR_ORDER.indexOf(n.coin.sector));
        const ang = (si / SECTOR_ORDER.length) * Math.PI * 2 + (hash(n.coin.symbol) % 80) / 80 - 0.4;
        const dist = 58 + Math.sqrt(n.coin.rank || 40) * 16;
        tx = W / 2 + Math.cos(ang) * dist;
        ty = H / 2 + Math.sin(ang) * dist * 0.78;
      }
    } else if (layout === "squeeze") {
      const fund = Math.max(-0.0012, Math.min(0.0012, n.coin.funding ?? 0));
      const chg = Math.max(-22, Math.min(22, n.coin.chg24h ?? 0));
      tx = W * (0.5 + fund / 0.0024);
      ty = H * (0.5 - chg / 50);
    }
    n.x += (tx - n.x) * 0.05;
    n.y += (ty - n.y) * 0.05;
  }
}

function collide(nodes: Node[]) {
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i];
      const b = nodes[j];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const min = a.r + b.r + 1.3;
      const d2 = dx * dx + dy * dy;
      if (d2 >= min * min || d2 === 0) continue;
      const d = Math.sqrt(d2);
      const overlap = (min - d) / 2;
      const ux = dx / d;
      const uy = dy / d;
      a.x -= ux * overlap;
      a.y -= uy * overlap;
      b.x += ux * overlap;
      b.y += uy * overlap;
    }
  }
}

function drawSpark(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, spark: number[]) {
  if (spark.length < 8 || r < 26) return;
  const w = r * 1.15;
  const h = r * 0.42;
  const left = x - w / 2;
  const top = y + 1;
  let min = spark[0];
  let max = spark[0];
  for (const v of spark) {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  const span = max - min || 1;
  ctx.beginPath();
  spark.forEach((v, i) => {
    const px = left + (i / (spark.length - 1)) * w;
    const py = top + h - ((v - min) / span) * h;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  });
  ctx.strokeStyle = "rgba(236,234,228,0.72)";
  ctx.lineWidth = 1.05;
  ctx.stroke();
}

export function BubbleField({
  coins,
  tf,
  sizeBy,
  layout,
  query,
  selectedId,
  pinned,
  onSelect,
}: {
  coins: BubbleCoin[];
  tf: Timeframe;
  sizeBy: SizeBy;
  layout: Layout;
  query: string;
  selectedId: string | null;
  pinned?: string[];
  onSelect: (c: BubbleCoin | null) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const tipRef = useRef<HTMLDivElement>(null);
  const nodesRef = useRef<Node[]>([]);
  const hoverRef = useRef<string | null>(null);
  const camRef = useRef({ x: 0, y: 0, k: 1 });
  const dragRef = useRef<{ id: number; x: number; y: number; moved: boolean } | null>(null);
  const structRef = useRef("");

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    const tip = tipRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const q = query.trim().toUpperCase();
    const scale = heatScale(tf);
    const pinSet = new Set((pinned || []).map((s) => s.toUpperCase()));
    let raf = 0;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const world = (clientX: number, clientY: number) => {
      const rect = canvas.getBoundingClientRect();
      const cam = camRef.current;
      return {
        x: (clientX - rect.left - cam.x) / cam.k,
        y: (clientY - rect.top - cam.y) / cam.k,
      };
    };

    const ranked = () => {
      if (coins.length <= 180) return coins;
      const scored = coins.map((c) => ({ c, v: sizeValue(c, sizeBy, tf) }));
      scored.sort((a, b) => b.v - a.v);
      return scored.slice(0, 180).map((s) => s.c);
    };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      rebuild(w, h);
    };

    const rebuild = (w: number, h: number) => {
      const list = ranked();
      if (!list.length) {
        nodesRef.current = [];
        return;
      }
      const values = list.map((c) => sizeValue(c, sizeBy, tf));
      const max = Math.max(...values, 1);
      const min = Math.min(...values, max);
      const minR = w < 500 ? 10 : 12;
      const maxR = w < 500 ? 46 : 62;
      const prev = new Map(nodesRef.current.map((n) => [n.coin.symbol, n]));
      const key = `${layout}|${sizeBy}|${tf}|${list.length}`;
      const keep = structRef.current === key && prev.size > list.length * 0.5;
      structRef.current = key;
      const nodes: Node[] = list.map((c, i) => {
        const raw = sizeValue(c, sizeBy, tf);
        const t = (Math.log(raw) - Math.log(min)) / Math.max(0.0001, Math.log(max) - Math.log(min));
        const r = minR + Math.sqrt(Math.max(0, t)) * (maxR - minR);
        const old = prev.get(c.symbol);
        return { coin: c, x: old?.x ?? w / 2, y: old?.y ?? h / 2, r, phase: i * 0.37 };
      });
      if (!keep) {
        if (layout === "pack") spiralPack(nodes, w, h);
        else {
          spiralPack(nodes, w, h);
          const extra = layout === "galaxy" || layout === "squeeze" ? 28 : 22;
          for (let i = 0; i < extra; i++) {
            attract(nodes, w, h, layout);
            collide(nodes);
          }
        }
      } else {
        collide(nodes);
      }
      nodesRef.current = nodes;
    };

    const hit = (clientX: number, clientY: number) => {
      const { x, y } = world(clientX, clientY);
      let best: Node | null = null;
      let bestD = Infinity;
      for (const n of nodesRef.current) {
        const dx = x - n.x;
        const dy = y - n.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d <= n.r + 3 && d < bestD) {
          best = n;
          bestD = d;
        }
      }
      return best;
    };

    const draw = () => {
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cam = camRef.current;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      ctx.strokeStyle = "rgba(236,234,228,0.035)";
      ctx.lineWidth = 1;
      for (let x = 20; x < w; x += 44) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }

      ctx.save();
      ctx.setTransform(dpr * cam.k, 0, 0, dpr * cam.k, dpr * cam.x, dpr * cam.y);

      const nodes = nodesRef.current;
      if (!reduced && layout !== "pack") {
        attract(nodes, w, h, layout);
        collide(nodes);
      }

      if (layout === "cliff") {
        ctx.fillStyle = "rgba(226,60,50,0.06)";
        ctx.fillRect(w * 0.62, 0, w * 0.4, h);
        ctx.fillStyle = "rgba(226,60,50,0.7)";
        ctx.font = "600 10px 'IBM Plex Mono', monospace";
        ctx.textAlign = "right";
        ctx.fillText("CLIFF  →  dump structure", w - 16, 16);
      }

      if (layout === "squeeze") {
        ctx.fillStyle = "rgba(226,60,50,0.05)";
        ctx.fillRect(w * 0.5, 0, w * 0.5, h);
        ctx.fillStyle = "rgba(236,234,228,0.28)";
        ctx.font = "600 9px 'IBM Plex Mono', monospace";
        ctx.textAlign = "left";
        ctx.fillText("neg funding", 12, h - 14);
        ctx.textAlign = "right";
        ctx.fillText("crowded longs →", w - 12, h - 14);
      }

      if (layout === "sector" || layout === "galaxy") {
        ctx.font = "600 9px 'IBM Plex Mono', monospace";
        ctx.fillStyle = "rgba(236,234,228,0.28)";
        ctx.textAlign = "center";
        if (layout === "sector") {
          for (let i = 0; i < SECTOR_ORDER.length; i++) {
            const col = i % 5;
            const row = Math.floor(i / 5);
            const tx = ((col + 0.5) / 5) * w;
            const ty = 14 + row * (h / 2);
            ctx.fillText(SECTOR_LABEL[SECTOR_ORDER[i]], tx, ty);
          }
        }
      }

      const t = performance.now() / 1000;
      for (const n of nodes) {
        n.x = Math.max(n.r + 3, Math.min(w - n.r - 3, n.x));
        n.y = Math.max(n.r + 3, Math.min(h - n.r - 3, n.y));
        const chg = changeOf(n.coin, tf) ?? 0;
        const dim = q && !n.coin.symbol.includes(q) && !n.coin.name.toUpperCase().includes(q);
        const pulse = n.coin.trending || n.coin.signal === "EXPLODE" || Math.abs(chg) > scale ? 1 + Math.sin(t * 2.2 + n.phase) * 0.04 : 1;
        const rr = n.r * (reduced ? 1 : pulse);
        ctx.globalAlpha = dim ? 0.12 : 1;
        ctx.beginPath();
        ctx.arc(n.x, n.y, rr, 0, Math.PI * 2);
        ctx.fillStyle = heatColor(chg, scale);
        ctx.fill();

        const ring =
          n.coin.verdict === "SHORT_HARD"
            ? "#e23c32"
            : n.coin.verdict === "FADE"
              ? "rgba(226,60,50,0.75)"
              : n.coin.verdict === "BREAKOUT"
                ? "#3ecf8e"
                : pinSet.has(n.coin.symbol)
                  ? "#eceae4"
                  : n.coin.trending
                    ? "#d6a84f"
                    : n.coin.funding && n.coin.funding > 0.0003
                      ? "#d6a84f"
                      : "rgba(236,234,228,0.14)";
        ctx.lineWidth = n.coin.verdict === "SHORT_HARD" ? 2.5 : n.coin.trending || pinSet.has(n.coin.symbol) ? 1.8 : 1.15;
        ctx.strokeStyle = ring;
        ctx.stroke();

        if (n.coin.athChg != null && n.coin.athChg > -8) {
          ctx.beginPath();
          ctx.arc(n.x, n.y, rr * 0.78, 0, Math.PI * 2);
          ctx.strokeStyle = "rgba(236,234,228,0.35)";
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        if (selectedId === n.coin.id || hoverRef.current === n.coin.id) {
          ctx.lineWidth = 2.2;
          ctx.strokeStyle = "#eceae4";
          ctx.beginPath();
          ctx.arc(n.x, n.y, rr, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.fillStyle = "#eceae4";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        if (rr >= 16) {
          ctx.font = `600 ${rr >= 28 ? 11 : 9}px 'IBM Plex Mono', monospace`;
          ctx.fillText(n.coin.symbol.slice(0, rr > 34 ? 8 : 5), n.x, n.y - (rr >= 26 && n.coin.spark ? 8 : rr >= 22 ? 5 : 0));
        }
        if (rr >= 26 && n.coin.spark) drawSpark(ctx, n.x, n.y, rr, n.coin.spark);
        if (rr >= 22) {
          ctx.font = `500 ${rr >= 32 ? 10 : 8}px 'IBM Plex Mono', monospace`;
          ctx.fillText(`${chg > 0 ? "+" : ""}${chg.toFixed(1)}%`, n.x, n.y + (n.coin.spark && rr >= 26 ? 11 : 8));
        }
        ctx.globalAlpha = 1;
      }

      ctx.restore();
      raf = requestAnimationFrame(draw);
    };

    const showTip = (e: PointerEvent, n: Node | null) => {
      if (!tip) return;
      if (!n) {
        tip.style.opacity = "0";
        return;
      }
      const chg = changeOf(n.coin, tf);
      const bits = [
        `<b>${n.coin.symbol}</b> ${pct(chg)}`,
        n.coin.sector.toUpperCase(),
        usd(n.coin.mcap),
      ];
      if (n.coin.funding != null) bits.push(`fund ${fundingPct(n.coin.funding)}`);
      if (n.coin.oiUsd) bits.push(`OI ${usd(n.coin.oiUsd)}`);
      if (n.coin.signal !== "NONE") bits.push(n.coin.signal);
      tip.innerHTML = bits.join(" · ");
      const rect = wrap.getBoundingClientRect();
      tip.style.opacity = "1";
      tip.style.left = `${Math.min(rect.width - 220, Math.max(8, e.clientX - rect.left + 12))}px`;
      tip.style.top = `${Math.min(rect.height - 40, Math.max(8, e.clientY - rect.top + 12))}px`;
    };

    const onMove = (e: PointerEvent) => {
      const drag = dragRef.current;
      if (drag && drag.id === e.pointerId) {
        const dx = e.clientX - drag.x;
        const dy = e.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
        camRef.current.x += dx;
        camRef.current.y += dy;
        drag.x = e.clientX;
        drag.y = e.clientY;
        canvas.style.cursor = "grabbing";
        return;
      }
      const n = hit(e.clientX, e.clientY);
      hoverRef.current = n?.coin.id ?? null;
      canvas.style.cursor = n ? "pointer" : "grab";
      showTip(e, n);
    };
    const onDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      dragRef.current = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: false };
      canvas.setPointerCapture(e.pointerId);
    };
    const onUp = (e: PointerEvent) => {
      const drag = dragRef.current;
      dragRef.current = null;
      if (!drag || drag.moved) return;
      const n = hit(e.clientX, e.clientY);
      onSelect(n ? n.coin : null);
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const cam = camRef.current;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const next = Math.max(0.55, Math.min(3.2, cam.k * (e.deltaY < 0 ? 1.08 : 0.92)));
      const k = next / cam.k;
      cam.x = mx - (mx - cam.x) * k;
      cam.y = my - (my - cam.y) * k;
      cam.k = next;
    };
    const onLeave = () => {
      hoverRef.current = null;
      if (tip) tip.style.opacity = "0";
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("wheel", onWheel);
    };
  }, [coins, tf, sizeBy, layout, query, selectedId, pinned, onSelect]);

  const scale = heatScale(tf);

  return (
    <div
      ref={wrapRef}
      className="relative mb-2 h-[min(56vh,680px)] w-full overflow-hidden rounded-lg border border-line bg-bg"
    >
      <canvas ref={canvasRef} className="block h-full w-full touch-none" />
      <div
        ref={tipRef}
        className="pointer-events-none absolute z-10 max-w-xs rounded-sm bg-elevated px-2 py-1 font-mono text-[11px] text-fg opacity-0"
      />
      <div className="pointer-events-none absolute bottom-10 left-3 right-3 flex items-end justify-between gap-3">
        <p className="font-mono text-[10px] uppercase tracking-widest text-faint">
          drag to pan · wheel to zoom · tap a bubble
        </p>
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-[10px] text-down">-{scale}%</span>
          <div
            className="h-1.5 w-24 rounded-full"
            style={{
              background: "linear-gradient(90deg, #e23c32 0%, #303036 50%, #3ecf8e 100%)",
            }}
          />
          <span className="font-mono text-[10px] text-up">+{scale}%</span>
        </div>
      </div>
    </div>
  );
}
