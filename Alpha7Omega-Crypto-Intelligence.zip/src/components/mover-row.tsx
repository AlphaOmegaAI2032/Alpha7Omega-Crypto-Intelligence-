import { Badge } from "@/components/ui/badge";
import { CliffBar } from "@/components/cliff-bar";
import { fundingPct, pct, px, usd } from "@/lib/market/format";
import { kindLabel, verdictClass, verdictLabel } from "@/lib/market/labels";
import type { ScoredMover } from "@/lib/market/types";

export function MoverRow({
  item,
  onOpen,
}: {
  item: ScoredMover;
  onOpen: () => void;
}) {
  const last = item.perp?.last ?? item.dex?.priceUsd;
  const chg = item.perp?.change24h ?? item.dex?.changeH24;
  const up = (chg ?? 0) >= 0;
  return (
    <button
      type="button"
      onClick={onOpen}
      className="flex w-full flex-col gap-2 rounded-lg border border-line bg-surface px-3 py-3 text-left transition-colors hover:border-line-strong hover:bg-elevated active:scale-[0.99]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="truncate font-mono text-[15px] font-semibold tracking-tight">
              {item.symbol}
            </span>
            <Badge className="bg-elevated text-faint">{kindLabel(item.kind)}</Badge>
          </div>
          <div className="mt-1 font-mono text-xs text-muted">
            {item.perp?.venue === "binance" ? "Binance" : item.perp ? item.perp.venue : "DEX"}
            {item.dex ? ` · liq ${usd(item.dex.liquidityUsd)}` : " · perp only"}
            {item.cliff ? ` · cliff ${item.cliff.toFixed(1)}×` : ""}
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono text-[15px] tabular text-fg">{px(last)}</div>
          <div className={`font-mono text-xs tabular ${up ? "text-up" : "text-down"}`}>
            {pct(chg)}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        <Badge className={verdictClass(item.verdict)}>{verdictLabel(item.verdict)}</Badge>
        <span className="font-mono text-[10px] text-faint">score {item.score}</span>
        {item.perp ? (
          <span className="font-mono text-[10px] text-faint">
            fund {fundingPct(item.perp.funding)}
          </span>
        ) : null}
        {item.dex?.changeH1 != null ? (
          <span
            className={`font-mono text-[10px] ${item.dex.changeH1 < 0 ? "text-down" : "text-muted"}`}
          >
            1h {pct(item.dex.changeH1, 1)}
          </span>
        ) : null}
        {item.fromHighPct != null && item.fromHighPct < -1 ? (
          <span className="font-mono text-[10px] text-down">
            {item.fromHighPct.toFixed(1)}% off high
          </span>
        ) : null}
      </div>
      {item.perp && item.dex && item.perp.oiUsd > 0 && item.dex.liquidityUsd > 0 ? (
        <CliffBar oi={item.perp.oiUsd} liq={item.dex.liquidityUsd} />
      ) : null}
      {item.reasons[0] ? (
        <p className="line-clamp-2 text-xs leading-snug text-muted">{item.reasons[0]}</p>
      ) : null}
    </button>
  );
}
