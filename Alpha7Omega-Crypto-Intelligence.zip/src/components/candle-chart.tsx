import type { Candle } from "@/lib/market/book";

export function CandleChart({ candles }: { candles: Candle[] }) {
  if (candles.length < 4) {
    return (
      <div className="flex h-[280px] items-center justify-center rounded-xl border border-dashed border-line text-sm text-muted">
        No candles on the wire.
      </div>
    );
  }
  const w = 720;
  const h = 280;
  const pad = { l: 8, r: 56, t: 12, b: 8 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const hi = Math.max(...candles.map((c) => c.h));
  const lo = Math.min(...candles.map((c) => c.l));
  const span = hi - lo || 1;
  const y = (p: number) => pad.t + ((hi - p) / span) * innerH;
  const bw = Math.max(2, innerW / candles.length - 1.2);
  const ticks = [hi, lo + span * 0.5, lo];

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-[280px] w-full" role="img" aria-label="Candles">
      {ticks.map((p) => (
        <g key={p}>
          <line x1={pad.l} x2={w - pad.r} y1={y(p)} y2={y(p)} stroke="var(--color-line)" strokeWidth="1" />
          <text x={w - pad.r + 6} y={y(p) + 4} fill="var(--color-faint)" fontSize="10" fontFamily="IBM Plex Mono, monospace">
            {p >= 100 ? p.toFixed(1) : p.toPrecision(4)}
          </text>
        </g>
      ))}
      {candles.map((c, i) => {
        const x = pad.l + (i + 0.5) * (innerW / candles.length);
        const up = c.c >= c.o;
        const color = up ? "var(--color-up)" : "var(--color-down)";
        const bodyTop = y(Math.max(c.o, c.c));
        const bodyBot = y(Math.min(c.o, c.c));
        const bh = Math.max(1, bodyBot - bodyTop);
        return (
          <g key={c.t}>
            <line x1={x} x2={x} y1={y(c.h)} y2={y(c.l)} stroke={color} strokeWidth="1" />
            <rect x={x - bw / 2} y={bodyTop} width={bw} height={bh} fill={color} />
          </g>
        );
      })}
    </svg>
  );
}
