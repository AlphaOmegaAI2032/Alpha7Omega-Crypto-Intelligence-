import { Link } from "@tanstack/react-router";
import { NOW, type NowCard } from "@/lib/market/desk-book";
import { pct, px } from "@/lib/market/format";

type Quote = { price: number; chg: number | null };

const BUCKETS: Array<{
  id: NowCard["bucket"];
  title: string;
  kicker: string;
  ring: string;
}> = [
  { id: "now", title: "Short this hour", kicker: "Take · isolated", ring: "border-down/40 bg-down/5" },
  { id: "wait", title: "Armed / skip dust", kicker: "Not yet", ring: "border-wait/40 bg-wait/5" },
  { id: "never", title: "Do not fade as P&D", kicker: "Quality / beta", ring: "border-line bg-surface" },
  { id: "late", title: "Too late — already dumped", kicker: "Inverse knife", ring: "border-line bg-surface" },
];

export function NowBook({ quotes }: { quotes: Record<string, Quote> }) {
  return (
    <section className="mb-6 space-y-3">
      <div className="glass rounded-xl p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-wait">Wed 09:50 SAST · Binance USDT-M ranking</p>
        <h2 className="mt-1 text-base font-medium leading-snug">
          Three shorts this hour. Everything else on that ranking is a trap.
        </h2>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">
          09:35 said wait the 1h. 09:50: USELESS 1h is +1%, FF stalled, funding still fat. That is the window. Isolated.
          Never 38×. Never market-short a still-green 5m. SOPH/FORM/COLLECT are already the dump.
        </p>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {BUCKETS.map((b) => {
          const rows = NOW.filter((r) => r.bucket === b.id);
          return (
            <article key={b.id} className={`rounded-xl border p-4 ${b.ring}`}>
              <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{b.kicker}</p>
              <h3 className="mt-1 text-sm font-medium">{b.title}</h3>
              <div className="mt-3 space-y-2">
                {rows.map((r) => (
                  <NowRow key={r.id} row={r} q={quotes[r.sym.toUpperCase()]} />
                ))}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function NowRow({ row, q }: { row: NowCard; q?: Quote }) {
  const pxv = q?.price ?? row.px;
  const chg = q?.chg ?? row.chg;
  const tone =
    row.bucket === "now"
      ? "text-down"
      : row.bucket === "never"
        ? "text-up"
        : row.bucket === "wait"
          ? "text-wait"
          : "text-muted";
  return (
    <Link
      to="/ta"
      search={{ s: `${row.sym}USDT` }}
      className="block rounded-lg border border-line bg-bg/40 px-3 py-2.5 hover:border-line-strong"
    >
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex min-w-0 items-baseline gap-2">
          <span className="font-mono text-sm font-semibold">{row.sym}</span>
          <span className={`font-mono text-[10px] uppercase tracking-wide ${tone}`}>{row.call}</span>
        </div>
        <div className="flex items-baseline gap-2 font-mono text-xs tabular">
          <span>{px(pxv)}</span>
          <span className={chg >= 0 ? "text-up" : "text-down"}>{pct(chg)}</span>
        </div>
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-muted">{row.trigger}</p>
      <p className="mt-0.5 font-mono text-[10px] text-faint">
        Stop {row.stop} · {row.size}
      </p>
    </Link>
  );
}
