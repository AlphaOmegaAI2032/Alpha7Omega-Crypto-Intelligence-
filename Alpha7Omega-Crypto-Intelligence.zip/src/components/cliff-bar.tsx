import { usd } from "@/lib/market/format";

export function CliffBar({
  oi,
  liq,
  label = "OI vs pool",
}: {
  oi: number;
  liq: number;
  label?: string;
}) {
  const total = Math.max(oi + liq, 1);
  const oiPct = Math.min(98, (oi / total) * 100);
  return (
    <div className="mt-2">
      <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-widest text-faint">
        <span>{label}</span>
        <span>
          {usd(oi)} / {usd(liq)}
        </span>
      </div>
      <div className="flex h-1.5 overflow-hidden rounded-full bg-elevated">
        <div className="bg-down" style={{ width: `${oiPct}%` }} />
        <div className="bg-up" style={{ width: `${100 - oiPct}%` }} />
      </div>
    </div>
  );
}
