import { Link } from "@tanstack/react-router";
import {
  CIRCLED,
  CIRCLED_BOARDS,
  CIRCLED_META,
  callClass,
  markLabel,
  type CircledRow,
} from "@/lib/market/circled";
import { pct, px } from "@/lib/market/format";

type Quote = { price: number; chg: number | null };

export function CircledTape({ quotes }: { quotes: Record<string, Quote> }) {
  return (
    <section className="mb-6 space-y-3">
      <div className="glass rounded-xl p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-wait">
          Circled tape · {CIRCLED_META.stamp}
        </p>
        <h2 className="mt-1 text-base font-medium leading-snug">Your purple marks, decoded.</h2>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">{CIRCLED_META.note}</p>
        <p className="mt-1 font-mono text-[11px] text-faint">{CIRCLED_META.source}</p>
      </div>
      <div className="grid gap-3 lg:grid-cols-3">
        {CIRCLED_BOARDS.map((b) => (
          <article key={b.id} className="rounded-xl border border-line bg-surface p-4">
            <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{b.title}</p>
            <p className="mt-1 text-[12px] leading-relaxed text-muted">{b.kicker}</p>
            <div className="mt-3 space-y-1.5">
              {CIRCLED.filter((r) => r.board === b.id).map((r) => (
                <CircledRowView key={r.id} row={r} q={quotes[r.sym.toUpperCase()]} />
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function CircledRowView({ row, q }: { row: CircledRow; q?: Quote }) {
  const pxv = q?.price ?? row.px;
  const chg = q?.chg ?? row.chg;
  return (
    <Link
      to="/ta"
      search={{ s: `${row.sym}USDT` }}
      className="block rounded-lg border border-line bg-bg/40 px-2.5 py-2 hover:border-line-strong"
    >
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex min-w-0 items-baseline gap-1.5">
          <span className="font-mono text-[11px] text-faint" aria-hidden>
            {markLabel(row.mark)}
          </span>
          <span className="font-mono text-sm font-semibold">{row.sym}</span>
          <span className={`truncate font-mono text-[10px] uppercase tracking-wide ${callClass(row.call)}`}>
            {row.label}
          </span>
        </div>
        <div className="flex shrink-0 items-baseline gap-2 font-mono text-[11px] tabular">
          <span>{px(pxv)}</span>
          <span className={chg >= 0 ? "text-up" : "text-down"}>{pct(chg)}</span>
        </div>
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-muted">{row.why}</p>
    </Link>
  );
}
