export function PageHead({
  kicker,
  title,
  right,
}: {
  kicker: string;
  title: string;
  right?: string;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <p className="text-xs uppercase tracking-widest text-muted">{kicker}</p>
        <h1 className="mt-1 text-balance text-2xl font-medium tracking-tight text-fg">{title}</h1>
      </div>
      {right ? <p className="font-mono text-xs text-muted">{right}</p> : null}
    </div>
  );
}
