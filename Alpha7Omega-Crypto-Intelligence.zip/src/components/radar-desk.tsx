import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { BreakoutRow } from "@/components/breakout-row";
import { RadarTable } from "@/components/radar-table";
import { WatchStrip } from "@/components/watch-strip";
import type { BreakoutHit, BreakoutResponse, ScoredMover } from "@/lib/market/types";

type Sub = "breakouts" | "cliff" | "boosts" | "watch";
type ChainF = "all" | "solana" | "bsc" | "base" | "ethereum";
type SortF = "score" | "vol" | "chg" | "cliff" | "age";

const WATCH_KEY = "a7o_breakout_watch";

function loadWatch(): string[] {
  try {
    const raw = localStorage.getItem(WATCH_KEY);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}

export function RadarDesk({
  hits,
  loading,
  error,
  notes,
  mars,
  useless,
  onOpenHit,
  onOpenMover,
}: {
  hits: BreakoutHit[];
  loading: boolean;
  error: boolean;
  notes?: string[];
  mars: ScoredMover | null;
  useless: ScoredMover | null;
  onOpenHit: (h: BreakoutHit) => void;
  onOpenMover: (m: ScoredMover) => void;
}) {
  const [sub, setSub] = useState<Sub>("breakouts");
  const [chain, setChain] = useState<ChainF>("all");
  const [ageH, setAgeH] = useState(0);
  const [minLiq, setMinLiq] = useState(25_000);
  const [sort, setSort] = useState<SortF>("score");
  const [q, setQ] = useState("");
  const [qLive, setQLive] = useState("");
  const [watch, setWatch] = useState<string[]>([]);

  useEffect(() => {
    setWatch(loadWatch());
  }, []);

  useEffect(() => {
    const id = setTimeout(() => setQLive(q.trim()), 400);
    return () => clearTimeout(id);
  }, [q]);

  const search = useQuery({
    queryKey: ["search", qLive],
    queryFn: async () => {
      const r = await fetch(`/api/search?q=${encodeURIComponent(qLive)}`);
      if (!r.ok) throw new Error("search failed");
      return (await r.json()) as BreakoutResponse;
    },
    enabled: qLive.length >= 2,
    refetchInterval: 30_000,
  });

  const merged = useMemo(() => {
    const map = new Map<string, BreakoutHit>();
    for (const h of hits) map.set(h.id, h);
    for (const h of search.data?.hits || []) map.set(h.id, h);
    return [...map.values()];
  }, [hits, search.data]);

  const rows = useMemo(() => {
    let list = merged.filter((h) => {
      if (chain !== "all" && h.chain !== chain) return false;
      const liq = h.dex?.liquidityUsd || 0;
      if (minLiq && liq < minLiq && sub !== "watch") return false;
      if (ageH && h.dex?.pairCreatedAt) {
        const hours = (Date.now() - h.dex.pairCreatedAt) / 3_600_000;
        if (hours > ageH) return false;
      }
      if (sub === "cliff") return (h.fdvCliff || 0) >= 25 && (h.dex?.fdv || h.dex?.marketCap || 0) >= 1_000_000;
      if (sub === "boosts") return (h.boost || 0) > 0 || h.source === "boost" || h.source === "cto";
      if (sub === "watch") return watch.includes(h.id) || watch.includes(h.address.toLowerCase());
      if (sub === "breakouts") {
        return (
          h.verdict === "BREAKOUT" ||
          h.score >= 18 ||
          h.source === "pump" ||
          h.source === "live" ||
          h.source === "search"
        );
      }
      return true;
    });
    list = [...list].sort((a, b) => {
      if (sort === "vol") return (b.dex?.volumeH1 || 0) - (a.dex?.volumeH1 || 0);
      if (sort === "chg") return (b.dex?.changeH1 || 0) - (a.dex?.changeH1 || 0);
      if (sort === "cliff") return (b.fdvCliff || 0) - (a.fdvCliff || 0);
      if (sort === "age") return (b.createdAt || b.dex?.pairCreatedAt || 0) - (a.createdAt || a.dex?.pairCreatedAt || 0);
      return b.score - a.score;
    });
    return list;
  }, [merged, chain, minLiq, ageH, sub, sort, watch]);

  const pin = (h: BreakoutHit) => {
    const id = h.address.toLowerCase();
    setWatch((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      localStorage.setItem(WATCH_KEY, JSON.stringify(next));
      return next;
    });
  };

  return (
    <section>
      <WatchStrip mars={mars} useless={useless} onOpen={onOpenMover} />
      <p className="mb-3 text-sm text-muted">
        First prints vs inventory cliffs. Boosts and CTOs are paid visibility — often the distribution
        ad. Size off pool depth. Search a ticker or CA.
      </p>
      <div className="mb-2 flex gap-1 overflow-x-auto">
        {(
          [
            ["breakouts", "Breakouts"],
            ["cliff", "Cliff shorts"],
            ["boosts", "Paid boosts"],
            ["watch", "Watchlist"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setSub(id)}
            className={`h-11 shrink-0 rounded-md px-3 font-mono text-[11px] uppercase tracking-wide ${
              sub === id ? "bg-accent text-accent-fg" : "bg-surface text-muted"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search ticker / CA"
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 font-mono text-sm text-fg outline-none placeholder:text-faint focus:border-line-strong"
        />
        <div className="flex flex-wrap gap-1">
          <Select
            value={chain}
            onChange={(v) => setChain(v as ChainF)}
            opts={[
              ["all", "All chains"],
              ["solana", "Solana"],
              ["bsc", "BSC"],
              ["base", "Base"],
              ["ethereum", "ETH"],
            ]}
          />
          <Select
            value={String(ageH)}
            onChange={(v) => setAgeH(Number(v))}
            opts={[
              ["0", "Any age"],
              ["1", "≤ 1h"],
              ["6", "≤ 6h"],
              ["24", "≤ 24h"],
              ["168", "≤ 7d"],
            ]}
          />
          <Select
            value={String(minLiq)}
            onChange={(v) => setMinLiq(Number(v))}
            opts={[
              ["0", "Any liq"],
              ["10000", "Liq ≥ $10k"],
              ["25000", "Liq ≥ $25k"],
              ["100000", "Liq ≥ $100k"],
            ]}
          />
          <Select
            value={sort}
            onChange={(v) => setSort(v as SortF)}
            opts={[
              ["score", "Score"],
              ["vol", "1h vol"],
              ["chg", "1h %"],
              ["cliff", "Cliff"],
              ["age", "Newest"],
            ]}
          />
        </div>
      </div>
      {qLive.length >= 2 && search.isFetching ? (
        <p className="mb-2 font-mono text-[10px] text-faint">Searching DexScreener…</p>
      ) : null}
      {loading && qLive.length < 2 ? (
        <div className="grid gap-2 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="skel h-24 rounded-lg" />
          ))}
        </div>
      ) : error && qLive.length < 2 ? (
        <div className="rounded-lg border border-down/40 bg-down/10 px-4 py-3 text-sm text-down">
          Breakout feed failed.
        </div>
      ) : rows.length === 0 ? (
        <div className="rounded-lg border border-dashed border-line px-4 py-8 text-center text-sm text-muted">
          {sub === "watch" ? "Watchlist empty. Pin a row from Breakouts." : "No prints cleared the filter."}
        </div>
      ) : (
        <>
          <RadarTable
            rows={rows.slice(0, 90)}
            onOpen={onOpenHit}
            watched={watch}
            onPin={pin}
          />
          <div className="grid gap-2 lg:hidden">
            {rows.slice(0, 40).map((h) => (
              <BreakoutRow key={h.id} item={h} onOpen={() => onOpenHit(h)} />
            ))}
          </div>
        </>
      )}
      <p className="mt-3 font-mono text-[10px] text-faint">
        {rows.length} names
        {notes?.length ? ` · ${notes.join(" · ")}` : ""}
        {search.data?.sourceNotes?.length ? ` · ${search.data.sourceNotes.join(" · ")}` : ""}
      </p>
    </section>
  );
}

function Select({
  value,
  onChange,
  opts,
}: {
  value: string;
  onChange: (v: string) => void;
  opts: [string, string][];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-11 rounded-md border border-line bg-surface px-2 font-mono text-[11px] uppercase tracking-wide text-fg"
    >
      {opts.map(([v, l]) => (
        <option key={v} value={v}>
          {l}
        </option>
      ))}
    </select>
  );
}
