import { Badge } from "@/components/ui/badge";
import { ageLabel, pct, px, usd } from "@/lib/market/format";
import { sourceLabel, verdictClass, verdictLabel } from "@/lib/market/labels";
import type { BreakoutHit } from "@/lib/market/types";

export function BreakoutRow({
  item,
  onOpen,
}: {
  item: BreakoutHit;
  onOpen: () => void;
}) {
  const chg = item.dex?.changeH1 ?? item.dex?.changeM5;
  const up = (chg ?? 0) >= 0;
  const volLiq =
    item.dex && item.dex.liquidityUsd > 0 ? item.dex.volumeH1 / item.dex.liquidityUsd : 0;
  return (
    <button
      type="button"
      onClick={onOpen}
      className="flex w-full items-start gap-3 rounded-lg border border-line bg-surface px-3 py-3 text-left transition-colors hover:border-line-strong hover:bg-elevated active:scale-[0.99]"
    >
      {item.imageUrl ? (
        <img
          src={item.imageUrl}
          alt=""
          className="mt-0.5 size-9 shrink-0 rounded-md bg-elevated object-cover"
          crossOrigin="anonymous"
        />
      ) : (
        <div className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-elevated font-mono text-[10px] text-faint">
          {item.symbol.slice(0, 3)}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="truncate font-mono text-[15px] font-semibold">{item.symbol}</div>
            <div className="truncate font-mono text-[10px] uppercase tracking-wide text-faint">
              {item.chain} · {sourceLabel(item.source)} · {ageLabel(item.createdAt || item.dex?.pairCreatedAt)}
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-sm tabular">{px(item.dex?.priceUsd)}</div>
            <div className={`font-mono text-xs tabular ${up ? "text-up" : "text-down"}`}>
              {pct(chg, 1)}
            </div>
          </div>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          <Badge className={verdictClass(item.verdict)}>{verdictLabel(item.verdict)}</Badge>
          <span className="font-mono text-[10px] text-faint">
            liq {usd(item.dex?.liquidityUsd)} · vol1h {usd(item.dex?.volumeH1)}
          </span>
          {volLiq >= 1 ? (
            <span className="font-mono text-[10px] text-up">{volLiq.toFixed(1)}× vol/liq</span>
          ) : null}
          {item.fdvCliff && item.fdvCliff > 10 ? (
            <span className="font-mono text-[10px] text-down">{item.fdvCliff.toFixed(0)}× fdv/pool</span>
          ) : null}
          {item.boost ? (
            <span className="font-mono text-[10px] text-wait">{item.boost}× boost</span>
          ) : null}
        </div>
        {item.reasons[0] ? (
          <p className="mt-1.5 line-clamp-2 text-xs leading-snug text-muted">{item.reasons[0]}</p>
        ) : null}
      </div>
    </button>
  );
}
