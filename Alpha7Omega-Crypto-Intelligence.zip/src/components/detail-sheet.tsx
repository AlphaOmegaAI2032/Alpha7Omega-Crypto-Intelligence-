import { Drawer } from "vaul";
import { ExternalLink, Pin, X } from "lucide-react";
import { Sparkline } from "@/components/sparkline";
import { Badge } from "@/components/ui/badge";
import { CliffBar } from "@/components/cliff-bar";
import { ageLabel, fundIn, fundingPct, pct, px, usd } from "@/lib/market/format";
import { holdersFor } from "@/lib/market/holders";
import { kindLabel, sourceLabel, verdictClass, verdictLabel } from "@/lib/market/labels";
import type { BreakoutHit, BubbleCoin, ScoredMover } from "@/lib/market/types";

type Target =
  | { mode: "mover"; item: ScoredMover }
  | { mode: "hit"; item: BreakoutHit }
  | { mode: "bubble"; item: BubbleCoin };

export function DetailSheet({
  open,
  onOpenChange,
  target,
  pinned,
  onTogglePin,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  target: Target | null;
  pinned?: string[];
  onTogglePin?: (symbol: string) => void;
}) {
  const item = target?.item;
  const isBubble = target?.mode === "bubble";
  const dex = !isBubble && item && "dex" in item ? item.dex : null;
  const perp = target?.mode === "mover" ? target.item.perp : null;
  const bubble = isBubble ? target.item : null;
  const verdict = item?.verdict;
  const reasons = item?.reasons || [];
  const holders = target?.mode === "mover" || target?.mode === "bubble" ? holdersFor(target.item.symbol) : null;
  const invalidation = target?.mode === "mover" ? target.item.invalidation : null;
  const isPinned = !!(item && "symbol" in item && pinned?.includes(item.symbol.toUpperCase()));

  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-40 bg-bg/70" />
        <Drawer.Content className="fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[88vh] max-w-lg flex-col rounded-t-xl border border-line bg-surface outline-none">
          <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-line-strong" />
          <div className="flex items-start justify-between gap-3 px-4 pb-2 pt-4">
            <div>
              <Drawer.Title className="font-mono text-lg font-semibold tracking-tight text-fg">
                {item?.symbol ?? "—"}
              </Drawer.Title>
              <p className="mt-0.5 text-xs text-muted">{item && "name" in item ? item.name : ""}</p>
            </div>
            <div className="flex items-center gap-2">
              {verdict ? <Badge className={verdictClass(verdict)}>{verdictLabel(verdict)}</Badge> : null}
              {item && "symbol" in item && onTogglePin ? (
                <button
                  type="button"
                  aria-label={isPinned ? "Unpin" : "Pin"}
                  onClick={() => onTogglePin(item.symbol)}
                  className={`flex size-11 items-center justify-center rounded-md ${isPinned ? "text-fg" : "text-muted hover:text-fg"}`}
                >
                  <Pin className="size-4" />
                </button>
              ) : null}
              <button
                type="button"
                aria-label="Close"
                onClick={() => onOpenChange(false)}
                className="flex size-11 items-center justify-center rounded-md text-muted hover:text-fg"
              >
                <X className="size-4" />
              </button>
            </div>
          </div>

          <div className="overflow-y-auto px-4 pb-8">
            {bubble?.spark ? (
              <div className="mb-3 rounded-md bg-elevated px-3 py-2">
                <div className="font-mono text-[10px] uppercase tracking-widest text-faint">7d path</div>
                <Sparkline values={bubble.spark} className="mt-1 h-12 w-full" />
              </div>
            ) : null}

            {bubble ? (
              <div className="grid grid-cols-2 gap-2">
                <Stat label="Price" value={px(bubble.price)} />
                <Stat label="24h" value={pct(bubble.chg24h)} tone={(bubble.chg24h ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="1h" value={pct(bubble.chg1h)} tone={(bubble.chg1h ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="7d" value={pct(bubble.chg7d)} tone={(bubble.chg7d ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="30d" value={pct(bubble.chg30d)} tone={(bubble.chg30d ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="90d" value={pct(bubble.chg90d)} tone={(bubble.chg90d ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="1y" value={pct(bubble.chg1y)} tone={(bubble.chg1y ?? 0) >= 0 ? "up" : "down"} />
                <Stat
                  label="Vs ATH"
                  value={pct(bubble.athChg)}
                  tone={bubble.athChg != null && bubble.athChg > -12 ? "down" : "muted"}
                />
                <Stat label="Mcap" value={usd(bubble.mcap)} />
                <Stat label="24h vol" value={usd(bubble.volume)} />
                <Stat label="Vol Δ" value={pct(bubble.volChg)} tone={(bubble.volChg ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="Turnover" value={bubble.turnover != null ? `${(bubble.turnover * 100).toFixed(1)}%` : "—"} />
                <Stat label="OI" value={usd(bubble.oiUsd)} />
                <Stat
                  label="Funding"
                  value={fundingPct(bubble.funding)}
                  tone={(bubble.funding ?? 0) > 0 ? "down" : "muted"}
                />
                <Stat
                  label="Cliff"
                  value={bubble.cliff ? `${bubble.cliff.toFixed(1)}×` : "—"}
                  tone={bubble.cliff && bubble.cliff > 8 ? "down" : "muted"}
                />
                <Stat label="DEX liq" value={usd(bubble.dexLiq)} />
                <Stat label="TVL" value={usd(bubble.tvl)} />
                <Stat label="Rank" value={bubble.rank != null ? `#${bubble.rank}` : "—"} />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <Stat label="Last" value={px(perp?.last ?? dex?.priceUsd)} />
                <Stat
                  label="24h"
                  value={pct(perp?.change24h ?? dex?.changeH24)}
                  tone={(perp?.change24h ?? dex?.changeH24 ?? 0) >= 0 ? "up" : "down"}
                />
                <Stat label="1h DEX" value={pct(dex?.changeH1)} tone={(dex?.changeH1 ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="5m DEX" value={pct(dex?.changeM5)} tone={(dex?.changeM5 ?? 0) >= 0 ? "up" : "down"} />
                <Stat label="DEX liq" value={usd(dex?.liquidityUsd)} />
                <Stat label="FDV" value={usd(dex?.fdv ?? dex?.marketCap)} />
                <Stat label="DEX 24h vol" value={usd(dex?.volumeH24)} />
                <Stat label="Perp 24h vol" value={usd(perp?.volumeQuote)} />
                <Stat label="Funding" value={fundingPct(perp?.funding)} tone={(perp?.funding ?? 0) > 0 ? "down" : "muted"} />
                <Stat label="OI" value={usd(perp?.oiUsd)} />
                {target?.mode === "mover" ? (
                  <>
                    <Stat
                      label="Cliff (OI/pool)"
                      value={target.item.cliff ? `${target.item.cliff.toFixed(1)}×` : "—"}
                      tone={target.item.cliff && target.item.cliff > 8 ? "down" : "muted"}
                    />
                    <Stat
                      label="Pool / FDV"
                      value={target.item.poolPctFdv != null ? `${target.item.poolPctFdv.toFixed(2)}%` : "—"}
                      tone={target.item.poolPctFdv != null && target.item.poolPctFdv < 1 ? "down" : "muted"}
                    />
                  </>
                ) : target?.mode === "hit" ? (
                  <>
                    <Stat
                      label="FDV / pool"
                      value={target.item.fdvCliff ? `${target.item.fdvCliff.toFixed(0)}×` : "—"}
                      tone={target.item.fdvCliff && target.item.fdvCliff > 40 ? "down" : "muted"}
                    />
                    <Stat label="Boost" value={target.item.boost ? `${target.item.boost}×` : "—"} />
                  </>
                ) : null}
                <Stat label="Pair age" value={ageLabel(dex?.pairCreatedAt)} />
                <Stat
                  label={perp?.nextFunding ? "Next fund" : "1h buys/sells"}
                  value={perp?.nextFunding ? fundIn(perp.nextFunding) : dex ? `${dex.buysH1}/${dex.sellsH1}` : "—"}
                />
              </div>
            )}

            {perp && dex && perp.oiUsd > 0 && dex.liquidityUsd > 0 ? (
              <CliffBar oi={perp.oiUsd} liq={dex.liquidityUsd} />
            ) : null}

            {dex ? <FlowBar buys={dex.buysH1} sells={dex.sellsH1} /> : null}

            {target?.mode === "mover" ? (
              <p className="mt-3 font-mono text-[10px] uppercase tracking-widest text-faint">
                {kindLabel(target.item.kind)}
                {target.item.flags.length ? ` · ${target.item.flags.join(" · ")}` : ""}
                {target.item.perp?.venue ? ` · ${target.item.perp.venue}` : ""}
              </p>
            ) : target?.mode === "hit" ? (
              <p className="mt-3 font-mono text-[10px] uppercase tracking-widest text-faint">
                {sourceLabel(target.item.source)} · {target.item.chain}
              </p>
            ) : bubble ? (
              <p className="mt-3 font-mono text-[10px] uppercase tracking-widest text-faint">
                {bubble.sector.toUpperCase()}
                {bubble.signal !== "NONE" ? ` · ${bubble.signal}` : ""}
                {bubble.trending ? " · TRENDING" : ""}
                {bubble.flags.length ? ` · ${bubble.flags.join(" · ")}` : ""}
              </p>
            ) : null}

            {bubble?.why ? <p className="mt-3 text-sm leading-relaxed text-muted">{bubble.why}</p> : null}

            {item && "note" in item && item.note ? (
              <p className="mt-3 text-sm leading-relaxed text-muted">{item.note}</p>
            ) : null}

            {invalidation ? (
              <div className="mt-3 rounded-md border border-line bg-elevated px-3 py-2.5">
                <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Invalidation</div>
                <p className="mt-1 text-sm leading-relaxed text-fg">{invalidation}</p>
              </div>
            ) : null}

            {reasons.length ? (
              <ul className="mt-4 space-y-1.5">
                {reasons.map((r) => (
                  <li key={r} className="flex gap-2 text-sm text-fg">
                    <span className="mt-2 size-1 shrink-0 rounded-full bg-accent" />
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            ) : null}

            {holders ? (
              <div className="mt-5">
                <div className="font-mono text-[10px] uppercase tracking-widest text-faint">
                  Holders · top 100 {holders.top100Pct}% · {holders.inventoryToPool} vs pool
                </div>
                <ul className="mt-2 space-y-2">
                  {holders.slices.map((s) => (
                    <li key={s.label} className="rounded-md bg-elevated px-3 py-2">
                      <div className="flex justify-between gap-2 font-mono text-xs">
                        <span className="text-fg">{s.label}</span>
                        {s.pct ? <span className="text-muted">{s.pct}%</span> : null}
                      </div>
                      <p className="mt-0.5 text-xs text-muted">{s.note}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            {dex?.url || bubble?.dexUrl ? (
              <a
                href={dex?.url || bubble?.dexUrl || "#"}
                target="_blank"
                rel="noreferrer"
                className="mt-5 flex h-11 items-center justify-center gap-2 rounded-md bg-accent text-sm font-medium text-accent-fg"
              >
                Open DexScreener
                <ExternalLink className="size-3.5" />
              </a>
            ) : null}

            <p className="mt-4 text-[11px] leading-relaxed text-faint">
              Not financial advice. Isolated margin only. Size off open interest and pool depth, not
              the green print. Boosts are paid visibility — often the distribution advertisement.
            </p>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

function Stat({
  label,
  value,
  tone = "muted",
}: {
  label: string;
  value: string;
  tone?: "up" | "down" | "muted";
}) {
  const color = tone === "up" ? "text-up" : tone === "down" ? "text-down" : "text-fg";
  return (
    <div className="rounded-md bg-elevated px-3 py-2.5">
      <div className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</div>
      <div className={`mt-1 font-mono text-sm tabular ${color}`}>{value}</div>
    </div>
  );
}

function FlowBar({ buys, sells }: { buys: number; sells: number }) {
  const total = buys + sells;
  const bp = total > 0 ? (buys / total) * 100 : 50;
  return (
    <div className="mt-3">
      <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-widest text-faint">
        <span className="text-up">Buys {buys}</span>
        <span className="text-down">Sells {sells}</span>
      </div>
      <div className="flex h-1.5 overflow-hidden rounded-full bg-elevated">
        <div className="bg-up" style={{ width: `${bp}%` }} />
        <div className="bg-down" style={{ width: `${100 - bp}%` }} />
      </div>
    </div>
  );
}
