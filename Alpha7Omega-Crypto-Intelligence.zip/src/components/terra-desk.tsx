import { Sparkline } from "@/components/sparkline";
import { ago, compact, fundingPct, pct, px, qty, usd } from "@/lib/market/format";
import type { Impostor, TerraAsset, TerraChain, TerraPerp, TerraProto } from "@/lib/market/terra";

function tone(v: number | null | undefined) {
  if (v == null || !Number.isFinite(v) || v === 0) return "text-muted";
  return v > 0 ? "text-up" : "text-down";
}

function pill(v: number | null | undefined) {
  if (v == null || !Number.isFinite(v)) return "bg-elevated text-muted";
  return v >= 0 ? "bg-up/15 text-up" : "bg-down/15 text-down";
}

export function VerdictList({ lines }: { lines: string[] }) {
  if (!lines.length) return null;
  return (
    <section className="glass rounded-xl p-4">
      <p className="text-xs uppercase tracking-widest text-muted">What is actually going on</p>
      <ol className="mt-3 space-y-3">
        {lines.map((line, i) => (
          <li key={i} className="flex gap-3 text-sm leading-relaxed text-fg">
            <span className="font-mono text-xs tabular text-faint">{String(i + 1).padStart(2, "0")}</span>
            <span>{line}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function AssetCard({ a }: { a: TerraAsset }) {
  return (
    <section className="glass rounded-xl p-4">
      <div className="flex items-baseline justify-between gap-2">
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">{a.symbol}</p>
          <p className="mt-0.5 text-sm text-subtle">{a.name}</p>
        </div>
        <span className={`inline-flex min-w-[4.5rem] justify-end rounded-md px-2 py-1 font-mono text-xs tabular font-medium ${pill(a.chg24h)}`}>
          {pct(a.chg24h)}
        </span>
      </div>
      <p className="mt-3 font-mono text-2xl tabular text-fg">{px(a.price)}</p>
      <Sparkline values={a.spark} className="mt-2 h-8 w-full" />
      <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 font-mono text-[11px] tabular">
        <div className="flex justify-between gap-2">
          <dt className="text-faint">Mcap</dt>
          <dd>{usd(a.mcap, 0)}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">24h vol</dt>
          <dd>{usd(a.vol24, 0)}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">1h</dt>
          <dd className={tone(a.chg1h)}>{pct(a.chg1h)}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">7d</dt>
          <dd className={tone(a.chg7d)}>{pct(a.chg7d)}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">Circ</dt>
          <dd>{qty(a.circ)}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">Turnover</dt>
          <dd>{a.turnover != null ? `${(a.turnover * 100).toFixed(1)}%` : "—"}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">Rank</dt>
          <dd>{a.rank ?? "—"}</dd>
        </div>
        <div className="flex justify-between gap-2">
          <dt className="text-faint">30d</dt>
          <dd className={tone(a.chg30d)}>{pct(a.chg30d)}</dd>
        </div>
      </dl>
    </section>
  );
}

export function SupplyStack({
  genesis,
  burned,
  bonded,
  unbonding,
  supply,
}: {
  genesis: number;
  burned: number;
  bonded: number;
  unbonding: number;
  supply: number;
}) {
  const float = Math.max(0, supply - bonded - unbonding);
  const max = Math.max(genesis, 1);
  const segs = [
    { label: "Burned", n: burned, cls: "bg-down" },
    { label: "Bonded", n: bonded, cls: "bg-fg" },
    { label: "Unbonding", n: unbonding, cls: "bg-wait" },
    { label: "Float", n: float, cls: "bg-fg/35" },
  ];
  return (
    <section className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium">LUNC supply anatomy</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted">
        May 2022 genesis {qty(genesis)}. Everything left of the burn is gone. Bonded is locked 21 days. The float is
        what can actually hit a book.
      </p>
      <div className="mt-4 flex h-4 overflow-hidden rounded-sm bg-elevated">
        {segs.map((s) => (
          <div
            key={s.label}
            className={s.cls}
            style={{ width: `${Math.max(s.n > 0 ? 2 : 0, (s.n / max) * 100)}%` }}
            title={`${s.label} ${qty(s.n)}`}
          />
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {segs.map((s) => (
          <div key={s.label}>
            <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{s.label}</p>
            <p className="font-mono text-sm tabular">{qty(s.n)}</p>
            <p className="font-mono text-[11px] text-muted">{((s.n / max) * 100).toFixed(1)}%</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ChainCard({ c }: { c: TerraChain }) {
  return (
    <section className="glass rounded-xl p-4">
      <div className="flex items-baseline justify-between gap-2">
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">{c.id}</p>
          <h3 className="mt-1 text-base font-medium">{c.label}</h3>
        </div>
        <span className="font-mono text-[11px] text-faint">#{c.height.toLocaleString("en-US")}</span>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 font-mono text-[12px] tabular">
        <Row k="Supply" v={qty(c.supply)} />
        {c.ustcSupply != null ? <Row k="USTC" v={qty(c.ustcSupply)} /> : <Row k="TVL" v={usd(c.tvl, 0)} />}
        <Row k="Bonded" v={`${qty(c.bonded)} · ${c.bondedPct.toFixed(1)}%`} />
        <Row k="Unbonding" v={`${qty(c.unbonding)} · ${c.unbondingPct.toFixed(1)}%`} />
        <Row k="Inflation" v={`${c.inflation.toFixed(1)}%`} />
        <Row k="Burn tax" v={c.burnTax != null ? `${c.burnTax.toFixed(1)}%` : "none"} />
        <Row k="Validators" v={String(c.validators)} />
        <Row k="Top-10 set" v={`${c.top10ValPct.toFixed(1)}%`} />
        <Row k="Community" v={qty(c.community)} />
        <Row k="Last block txs" v={String(c.txsInBlock)} />
      </dl>
      {c.burnSplit != null ? (
        <p className="mt-3 text-xs leading-relaxed text-muted">
          Tax split: {c.burnSplit.toFixed(0)}% oracle / community, {100 - c.burnSplit}% burned. 21-day unbond.
        </p>
      ) : (
        <p className="mt-3 text-xs leading-relaxed text-muted">
          Phoenix issues at {c.inflation.toFixed(0)}% inflation. Unbonding queue is the tell — {c.unbondingPct.toFixed(1)}%
          of supply is leaving the set.
        </p>
      )}
      <div className="mt-4 space-y-1.5">
        {c.topVals.map((v) => (
          <div key={v.moniker}>
            <div className="mb-0.5 flex items-baseline justify-between gap-2 font-mono text-[11px]">
              <span className="truncate text-muted">{v.moniker}</span>
              <span className="tabular text-fg">{v.share.toFixed(1)}%</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-sm bg-elevated">
              <div className="h-full bg-fg/70" style={{ width: `${Math.max(4, v.share * 4)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2">
      <dt className="text-faint">{k}</dt>
      <dd className="text-fg">{v}</dd>
    </div>
  );
}

export function DualOrbs({ lunc, luna }: { lunc: TerraAsset; luna: TerraAsset }) {
  const a = Math.max(lunc.mcap, 1);
  const b = Math.max(luna.mcap, 1);
  const rLunc = 42;
  const rLuna = Math.max(14, (Math.sqrt(b / a) * rLunc) | 0);
  return (
    <section className="glass rounded-xl p-4">
      <p className="text-xs uppercase tracking-widest text-muted">Two chains, one ticker family</p>
      <div className="mt-4 flex items-end justify-around gap-4">
        <Orb r={rLunc} label="LUNC" sub={`${usd(lunc.mcap, 0)} · columbus-5`} up={(lunc.chg24h ?? 0) >= 0} />
        <Orb r={rLuna} label="LUNA" sub={`${usd(luna.mcap, 0)} · phoenix-1`} up={(luna.chg24h ?? 0) >= 0} />
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted">
        Area scales with market cap. Classic is still ~{((a / b) | 0)}× Terra 2.0. If a feed shows LUNA +1,000%, it is
        not this circle.
      </p>
    </section>
  );
}

function Orb({ r, label, sub, up }: { r: number; label: string; sub: string; up: boolean }) {
  const s = r * 2 + 8;
  return (
    <div className="flex flex-col items-center">
      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} aria-hidden>
        <circle
          cx={s / 2}
          cy={s / 2}
          r={r}
          fill={up ? "color-mix(in oklab, var(--color-up) 35%, var(--color-surface))" : "color-mix(in oklab, var(--color-down) 35%, var(--color-surface))"}
          stroke={up ? "var(--color-up)" : "var(--color-down)"}
          strokeWidth="1.5"
        />
      </svg>
      <p className="mt-2 font-mono text-sm">{label}</p>
      <p className="font-mono text-[11px] text-muted">{sub}</p>
    </div>
  );
}

export function ImpostorTape({ rows }: { rows: Impostor[] }) {
  if (!rows.length) {
    return (
      <section className="glass rounded-xl p-4">
        <h3 className="text-sm font-medium">Impostor tape</h3>
        <p className="mt-2 text-sm text-muted">No ticker-snatch LUNA mint is printing a CLIFF on DexScreener right now.</p>
      </section>
    );
  }
  return (
    <section>
      <div className="mb-3">
        <h2 className="text-sm font-medium">Impostor tape — not Terra</h2>
        <p className="mt-1 max-w-3xl text-sm leading-relaxed text-muted">
          Same four letters, different mint. CLIFF is 24h volume ÷ pool. If that number is huge and the pair is hours
          old, the inventory is the pool.
        </p>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {rows.map((r) => (
          <article key={`${r.chain}:${r.pair}`} className="glass rounded-xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-mono text-xs uppercase tracking-widest text-faint">
                  {r.chain} · {r.dex}
                </p>
                <h3 className="mt-1 truncate text-base font-medium">
                  {r.symbol}
                  <span className="ml-2 font-mono text-xs font-normal text-muted">/{r.quote}</span>
                </h3>
                <p className="truncate text-xs text-subtle">{r.name}</p>
              </div>
              <span
                className={`shrink-0 rounded-md px-2 py-1 font-mono text-[10px] uppercase tracking-wide ${
                  r.verdict === "SHORT_HARD"
                    ? "bg-down/20 text-down"
                    : r.verdict === "FADE"
                      ? "bg-wait/20 text-wait"
                      : "bg-elevated text-muted"
                }`}
              >
                {r.verdict.replace("_", " ")}
              </span>
            </div>
            <div className="mt-3 flex flex-wrap items-baseline gap-x-4 gap-y-1 font-mono text-sm tabular">
              <span>{px(r.price)}</span>
              <span className={tone(r.chgH24)}>{pct(r.chgH24, 0)}</span>
              <span className="text-muted">1h {pct(r.chgH1)}</span>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px] tabular">
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Pool</dt>
                <dd>{usd(r.liq, 0)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">24h vol</dt>
                <dd>{usd(r.vol24, 0)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">CLIFF</dt>
                <dd className={r.cliff >= 40 ? "text-down" : "text-fg"}>{r.cliff.toFixed(0)}×</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">FDV</dt>
                <dd>{usd(r.fdv, 0)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Buys / sells</dt>
                <dd>
                  {compact(r.buys)} / {compact(r.sells)}
                </dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Age</dt>
                <dd>{r.createdAt ? ago(r.createdAt) : "—"}</dd>
              </div>
            </dl>
            <p className="mt-3 text-sm leading-relaxed text-muted">{r.note}</p>
            <p className="mt-2 truncate font-mono text-[10px] text-faint">{r.address}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

export function PerpSeats({ rows }: { rows: TerraPerp[] }) {
  if (!rows.length) return null;
  return (
    <section>
      <h2 className="mb-3 text-sm font-medium">Gate USDT-M seats</h2>
      <div className="grid gap-3 sm:grid-cols-2">
        {rows.map((p) => (
          <article key={p.contract} className="glass rounded-xl p-4">
            <div className="flex items-baseline justify-between">
              <p className="text-xs uppercase tracking-widest text-muted">{p.contract}</p>
              <span className={`font-mono text-xs tabular ${tone(p.change24)}`}>{pct(p.change24)}</span>
            </div>
            <p className="mt-2 font-mono text-xl tabular">{px(p.last)}</p>
            <Sparkline values={p.spark} className="mt-2 h-8 w-full" />
            <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px] tabular">
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Mark</dt>
                <dd>{px(p.mark)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Funding</dt>
                <dd>{fundingPct(p.funding)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">OI</dt>
                <dd>{usd(p.oiUsd, 0)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Perp vol</dt>
                <dd>{usd(p.volQuote, 0)}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">Lev cap</dt>
                <dd>{p.leverageMax ? `${p.leverageMax}×` : "—"}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-faint">OI tokens</dt>
                <dd>{qty(p.oiTokens)}</dd>
              </div>
            </dl>
          </article>
        ))}
      </div>
    </section>
  );
}

export function ProtoList({ rows }: { rows: TerraProto[] }) {
  if (!rows.length) return null;
  return (
    <section className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium">On-chain DeFi (Llama)</h3>
      <p className="mt-1 text-sm text-muted">Protocols that actually sit on Terra Classic or Terra 2.0 — not Lido's historical tag.</p>
      <ul className="mt-3 divide-y divide-line">
        {rows.map((p) => (
          <li key={p.name} className="flex items-baseline justify-between gap-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm">{p.name}</p>
              <p className="font-mono text-[11px] text-faint">
                {p.category} · {p.chains.join(" · ") || "—"}
              </p>
            </div>
            <div className="text-right font-mono text-xs tabular">
              <p>{usd(p.tvl, 0)}</p>
              <p className={tone(p.change1d)}>{pct(p.change1d, 1)}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
