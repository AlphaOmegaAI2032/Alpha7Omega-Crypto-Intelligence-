import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { WhaleMap } from "@/components/whale-map";
import { ago, pct, px, usd } from "@/lib/market/format";
import { INTEL_UNIVERSE, type DailyDigest, type IntelResponse } from "@/lib/market/intel";

export function IntelPanel({
  symbol,
  onSymbol,
}: {
  symbol: string;
  onSymbol: (s: string) => void;
}) {
  const intel = useQuery({
    queryKey: ["intel", symbol],
    queryFn: async () => {
      const r = await fetch(`/api/intel?symbol=${encodeURIComponent(symbol)}`);
      if (!r.ok) throw new Error("intel failed");
      return (await r.json()) as IntelResponse;
    },
    refetchInterval: 25_000,
  });
  const daily = useQuery({
    queryKey: ["daily"],
    queryFn: async () => {
      const r = await fetch("/api/daily");
      if (!r.ok) throw new Error("daily failed");
      return (await r.json()) as DailyDigest;
    },
    refetchInterval: 60_000,
  });

  const d = intel.data;

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-1">
        {INTEL_UNIVERSE.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => onSymbol(s)}
            className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase tracking-wide ${
              symbol === s ? "bg-accent text-accent-fg" : "bg-surface text-muted hover:text-fg"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <section>
        <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.14em] text-fg">1 · Tax token mechanics</h2>
        {intel.isLoading ? (
          <div className="skel mt-3 h-40 rounded-lg" />
        ) : intel.isError || !d ? (
          <p className="mt-3 text-sm text-down">Could not load tax brief.</p>
        ) : (
          <div className="mt-3 rounded-lg border border-line bg-surface p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="font-mono text-lg font-semibold">{d.tax.symbol}</div>
                <div className="text-xs text-muted">{d.tax.name}</div>
              </div>
              <Badge className={d.tax.proxy ? "bg-down/15 text-down" : "bg-elevated text-muted"}>
                {d.tax.proxy ? "UPGRADEABLE PROXY" : d.tax.pattern}
              </Badge>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Mini label="Buy tax" value={d.tax.buyTax} />
              <Mini label="Sell tax" value={d.tax.sellTax} />
              <Mini label="Mark" value={px(d.priceUsd)} />
              <Mini label="DEX liq" value={usd(d.liq)} />
            </div>
            <p className="mt-3 text-sm leading-relaxed text-wait">{d.tax.scannerLie}</p>
            <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted">
              {d.tax.bullets.map((b) => (
                <li key={b} className="border-l border-line pl-3">
                  {b}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm leading-relaxed text-fg">{d.tax.perpGap}</p>
            <p className="mt-2 font-mono text-[11px] text-faint">Invalidation: {d.tax.invalidation}</p>
            {d.tax.contract ? (
              <p className="mt-2 break-all font-mono text-[10px] text-faint">
                {d.tax.chain} · {d.tax.contract}
              </p>
            ) : null}
          </div>
        )}
      </section>

      <section>
        <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.14em] text-fg">2 · Whale wallet flows</h2>
        {intel.isLoading || !d ? (
          <div className="skel mt-3 h-40 rounded-lg" />
        ) : (
          <>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Mini label="Pool buys" value={String(d.flowSummary.buys)} hint={usd(d.flowSummary.buyUsd)} />
              <Mini
                label="Pool sells"
                value={String(d.flowSummary.sells)}
                hint={usd(d.flowSummary.sellUsd)}
                tone="down"
              />
              <Mini
                label="Sell / buy"
                value={
                  d.flowSummary.buyUsd > 0
                    ? `${(d.flowSummary.sellUsd / d.flowSummary.buyUsd).toFixed(2)}×`
                    : "—"
                }
                tone={d.flowSummary.sellUsd > d.flowSummary.buyUsd ? "down" : "up"}
              />
              <Mini
                label="Drip in window"
                value={d.dripLive ? "YES" : "No print"}
                tone={d.dripLive ? "down" : undefined}
              />
            </div>
            <p className="mt-2 font-mono text-[10px] text-faint">{d.flowSummary.window}</p>

            <div className="mt-4">
              <WhaleMap holders={d.holders} whales={d.whales} symbol={d.symbol} />
            </div>

            {d.whales.length ? (
              <div className="mt-3 grid gap-2">
                {d.whales.map((w) => (
                  <div key={w.label} className="rounded-lg border border-line bg-surface px-3 py-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-mono text-sm font-semibold">{w.label}</div>
                      <Badge
                        className={
                          w.verdict === "DUMPING" || w.verdict === "DRIP" || w.verdict === "MIGRATING"
                            ? "bg-down/15 text-down"
                            : w.status === "silent"
                              ? "bg-wait/15 text-wait"
                              : "bg-elevated text-muted"
                        }
                      >
                        {w.verdict}
                      </Badge>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <Mini
                        label="Bag"
                        value={w.tokens != null ? `${(w.tokens / 1_000_000).toFixed(2)}M` : "—"}
                      />
                      <Mini
                        label="Δ vs last"
                        value={
                          w.delta != null
                            ? `${w.delta >= 0 ? "+" : ""}${(w.delta / 1_000_000).toFixed(2)}M`
                            : "—"
                        }
                        tone={w.delta != null && w.delta < 0 ? "down" : undefined}
                      />
                      <Mini label="USD" value={usd(w.usd)} />
                      <Mini
                        label="% supply"
                        value={w.pctSupply != null ? `${w.pctSupply.toFixed(2)}%` : "—"}
                      />
                    </div>
                    <p className="mt-2 font-mono text-[11px] text-faint">
                      {w.verdict} · dest {w.dest}
                    </p>
                    <p className="mt-2 text-xs leading-relaxed text-muted">{w.note}</p>
                    {w.address ? (
                      <p className="mt-1 break-all font-mono text-[10px] text-faint">{w.address}</p>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : null}

            {d.holders ? (
              <div className="mt-3 rounded-lg border border-line bg-surface p-4">
                <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Concentration</div>
                <div className="mt-2 grid grid-cols-3 gap-2">
                  <Mini label="Top 10" value={`${d.holders.top10Pct}%`} />
                  <Mini label="Top 100" value={`${d.holders.top100Pct}%`} />
                  <Mini label="Inv / pool" value={d.holders.inventoryToPool} tone="down" />
                </div>
                <div className="mt-3 space-y-2">
                  {d.holders.slices.map((s) => (
                    <div key={s.label} className="flex items-start justify-between gap-3 text-xs">
                      <div>
                        <div className="text-fg">{s.label}</div>
                        <div className="text-faint">{s.note}</div>
                      </div>
                      <div className="shrink-0 font-mono text-muted">
                        {s.pct}% · {s.tokens}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            <div className="mt-3 overflow-x-auto rounded-lg border border-line">
              <table className="w-full min-w-[640px] text-left text-sm">
                <thead>
                  <tr className="border-b border-line font-mono text-[10px] uppercase tracking-widest text-faint">
                    <th className="px-3 py-2">Side</th>
                    <th className="px-3 py-2">USD</th>
                    <th className="px-3 py-2">Tokens</th>
                    <th className="px-3 py-2">Wallet</th>
                    <th className="px-3 py-2">When</th>
                  </tr>
                </thead>
                <tbody>
                  {d.flows.slice(0, 16).map((f) => (
                    <tr key={f.hash + f.at} className="border-b border-line/60">
                      <td className={`px-3 py-2 font-mono ${f.side === "sell" ? "text-down" : "text-up"}`}>
                        {f.side}
                      </td>
                      <td className="px-3 py-2 font-mono tabular">{usd(f.usd)}</td>
                      <td className="px-3 py-2 font-mono tabular">{f.tokens.toFixed(0)}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-muted">
                        {f.wallet ? `${f.wallet.slice(0, 6)}…${f.wallet.slice(-4)}` : "—"}
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px] text-faint">{ago(f.at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {d.topTakers.length ? (
              <p className="mt-2 font-mono text-[10px] text-faint">
                Top sellers this window:{" "}
                {d.topTakers
                  .slice(0, 4)
                  .map((t) => `${t.wallet.slice(0, 6)}… ${usd(t.sellUsd)}`)
                  .join(" · ")}
              </p>
            ) : null}
            {d.sourceNotes.length ? (
              <p className="mt-2 font-mono text-[10px] text-faint">{d.sourceNotes.join(" · ")}</p>
            ) : null}
          </>
        )}
      </section>

      <section>
        <h2 className="font-mono text-sm font-semibold uppercase tracking-[0.14em] text-fg">3 · Daily scan</h2>
        <p className="mt-1 text-sm text-muted">
          Armed for 07:00 Africa/Johannesburg. Same desk: fade list, heat, tax lever, whale prints.
        </p>
        {daily.isLoading ? (
          <div className="skel mt-3 h-40 rounded-lg" />
        ) : daily.isError || !daily.data ? (
          <p className="mt-3 text-sm text-down">Daily desk failed. Retrying.</p>
        ) : (
          <DailyCard data={daily.data} />
        )}
      </section>
    </div>
  );
}

function DailyCard({ data }: { data: DailyDigest }) {
  return (
    <div className="mt-3 rounded-lg border border-line bg-surface p-4">
      <div className="font-mono text-[10px] uppercase tracking-widest text-faint">
        Brief · {ago(data.generatedAt)} · F&G {data.fng ?? "—"} {data.fngLabel} · BTC.D {data.btcDom.toFixed(1)}%
      </div>
      <p className="mt-2 text-base font-medium leading-snug text-fg">{data.headline}</p>
      <div className="mt-4">
        <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Fade desk</div>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {data.shorts.map((s) => (
            <div key={s.symbol} className="rounded-md border border-line px-3 py-2">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-mono font-semibold">{s.symbol}</span>
                <span className={`font-mono text-sm ${(s.chg24h ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                  {pct(s.chg24h)}
                </span>
              </div>
              <div className="font-mono text-[11px] text-faint">
                score {s.score}
                {s.cliff != null ? ` · cliff ${s.cliff.toFixed(0)}×` : ""}
              </div>
              <p className="mt-1 text-xs text-muted">{s.reason}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-4">
        <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Heat</div>
        <div className="mt-2 flex flex-wrap gap-2">
          {data.heat.map((h) => (
            <span key={h.symbol} className="rounded-md bg-elevated px-2 py-1 font-mono text-xs">
              {h.symbol}{" "}
              <span className={(h.chg24h ?? 0) >= 0 ? "text-up" : "text-down"}>{pct(h.chg24h)}</span>
            </span>
          ))}
        </div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Whale alerts</div>
        {data.whaleAlerts.map((a) => (
          <p key={a} className="text-sm leading-relaxed text-muted">
            {a}
          </p>
        ))}
      </div>
      <div className="mt-4 space-y-2">
        <div className="font-mono text-[10px] uppercase tracking-widest text-faint">Tax watch</div>
        {data.taxWatch.map((a) => (
          <p key={a} className="text-sm leading-relaxed text-muted">
            {a}
          </p>
        ))}
      </div>
      <ul className="mt-4 space-y-1 text-xs text-faint">
        {data.thesis.map((t) => (
          <li key={t}>{t}</li>
        ))}
      </ul>
    </div>
  );
}

function Mini({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "up" | "down";
}) {
  return (
    <div>
      <div className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</div>
      <div
        className={`mt-0.5 font-mono text-sm tabular ${
          tone === "down" ? "text-down" : tone === "up" ? "text-up" : "text-fg"
        }`}
      >
        {value}
      </div>
      {hint ? <div className="font-mono text-[10px] text-faint">{hint}</div> : null}
    </div>
  );
}
