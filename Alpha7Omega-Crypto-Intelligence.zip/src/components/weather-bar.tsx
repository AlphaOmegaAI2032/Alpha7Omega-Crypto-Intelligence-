import { pct, usd } from "@/lib/market/format";
import { CAT_TO_SECTOR } from "@/lib/market/sectors";
import type { MarketPulse, Sector } from "@/lib/market/types";

export function WeatherBar({
  pulse,
  onSector,
}: {
  pulse: MarketPulse;
  onSector: (s: Sector | "all") => void;
}) {
  const weather =
    pulse.weather === "risk-on" ? "Risk on" : pulse.weather === "risk-off" ? "Risk off" : "Mixed";
  const weatherTone =
    pulse.weather === "risk-on" ? "text-up" : pulse.weather === "risk-off" ? "text-down" : "text-fg";

  return (
    <div className="mb-3">
      {pulse.deskNote ? (
        <p className="mb-2 max-w-4xl text-sm leading-relaxed text-muted">{pulse.deskNote}</p>
      ) : null}
      <div className="flex gap-2 overflow-x-auto pb-1">
        <Kpi label="Weather" value={weather} hint={pulse.fngLabel || "breadth + F&G"} tone={weatherTone} />
        <Kpi
          label="Crypto mcap"
          value={usd(pulse.totalMcap)}
          hint={`${pulse.activeCoins || "—"} coins`}
        />
        <Kpi
          label="24h mcap"
          value={pct(pulse.marketChange24)}
          hint={`vol ${usd(pulse.volume24)}`}
          tone={pulse.marketChange24 >= 0 ? "text-up" : "text-down"}
        />
        <Kpi
          label="BTC.D"
          value={`${pulse.btcDom.toFixed(1)}%`}
          hint={
            pulse.btcDomChg != null
              ? `${pulse.btcDomChg >= 0 ? "+" : ""}${pulse.btcDomChg.toFixed(2)}  ETH ${pulse.ethDom.toFixed(1)}%`
              : `ETH ${pulse.ethDom.toFixed(1)}%`
          }
        />
        <Kpi
          label="Breadth"
          value={`${pulse.breadthPct.toFixed(0)}% green`}
          hint={pulse.altseason != null ? `altseason ${pulse.altseason}` : "ex-stables"}
          tone={pulse.breadthPct >= 55 ? "text-up" : pulse.breadthPct <= 40 ? "text-down" : "text-fg"}
        />
        <Kpi
          label="Fear & greed"
          value={pulse.fng != null ? String(pulse.fng) : "—"}
          hint={pulse.fngLabel || "alternative.me"}
          tone={pulse.fng != null && pulse.fng >= 55 ? "text-up" : pulse.fng != null && pulse.fng <= 40 ? "text-down" : "text-fg"}
        />
        <Kpi
          label="Mempool"
          value={pulse.mempoolSat != null ? `${pulse.mempoolSat} sat` : "—"}
          hint={
            pulse.hashrateEh != null
              ? `${pulse.hashrateEh.toFixed(0)} EH/s`
              : pulse.diffProgress != null
                ? `diff ${pulse.diffProgress.toFixed(0)}%`
                : "mempool.space"
          }
        />
        <Kpi
          label="DeFi TVL"
          value={usd(pulse.totalTvl)}
          hint={pulse.defiMcap ? `DeFi mcap ${usd(pulse.defiMcap)}` : "DeFiLlama"}
        />
      </div>
      {pulse.categories.length ? (
        <div className="mt-2 flex gap-1 overflow-x-auto pb-1">
          <span className="flex h-11 shrink-0 items-center font-mono text-[10px] uppercase tracking-widest text-faint">
            Rotation
          </span>
          {pulse.categories.map((c) => {
            const mapped = CAT_TO_SECTOR[c.name];
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => mapped && onSector(mapped)}
                className="h-11 shrink-0 rounded-md border border-line bg-surface px-3 text-left hover:border-line-strong"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] text-fg">{c.name}</span>
                  <span className={`font-mono text-[11px] tabular ${c.change24 >= 0 ? "text-up" : "text-down"}`}>
                    {pct(c.change24, 1)}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  tone = "text-fg",
}: {
  label: string;
  value: string;
  hint: string;
  tone?: string;
}) {
  return (
    <div className="w-[9.75rem] shrink-0 rounded-lg border border-line bg-surface px-3 py-3 sm:w-[10.5rem] lg:w-auto lg:min-w-[8.5rem] lg:flex-1">
      <div className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</div>
      <div className={`mt-1 truncate font-mono text-lg tabular sm:text-xl ${tone}`}>{value}</div>
      <div className="mt-0.5 truncate text-[11px] text-muted">{hint}</div>
    </div>
  );
}
