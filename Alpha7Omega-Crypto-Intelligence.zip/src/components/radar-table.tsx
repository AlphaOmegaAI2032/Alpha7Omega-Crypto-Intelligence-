import { ageLabel, pct, px, usd } from "@/lib/market/format";
import { sourceLabel, verdictClass, verdictLabel } from "@/lib/market/labels";
import type { BreakoutHit } from "@/lib/market/types";

export function RadarTable({
  rows,
  onOpen,
  watched,
  onPin,
}: {
  rows: BreakoutHit[];
  onOpen: (item: BreakoutHit) => void;
  watched?: string[];
  onPin?: (item: BreakoutHit) => void;
}) {
  return (
    <div className="hidden overflow-x-auto rounded-lg border border-line lg:block">
      <table className="w-full min-w-[1180px] border-collapse text-left">
        <thead>
          <tr className="border-b border-line text-[10px] font-medium uppercase tracking-widest text-faint">
            <th className="px-3 py-2">Token</th>
            <th className="px-3 py-2">Chain</th>
            <th className="px-3 py-2">Price</th>
            <th className="px-3 py-2">5m</th>
            <th className="px-3 py-2">1h</th>
            <th className="px-3 py-2">6h</th>
            <th className="px-3 py-2">Liq</th>
            <th className="px-3 py-2">FDV</th>
            <th className="px-3 py-2">Cliff</th>
            <th className="px-3 py-2">1h vol</th>
            <th className="px-3 py-2">Vol/liq</th>
            <th className="px-3 py-2">B/S 1h</th>
            <th className="px-3 py-2">Boost</th>
            <th className="px-3 py-2">Call</th>
            <th className="px-3 py-2">Age</th>
            <th className="px-3 py-2" />
          </tr>
        </thead>
        <tbody>
          {rows.map((h) => {
            const volLiq =
              h.dex && h.dex.liquidityUsd > 0 ? h.dex.volumeH1 / h.dex.liquidityUsd : 0;
            const chg1 = h.dex?.changeH1;
            const chg5 = h.dex?.changeM5;
            const chg6 = h.dex?.changeH6;
            const pinned = watched?.includes(h.address.toLowerCase());
            return (
              <tr
                key={h.id}
                onClick={() => onOpen(h)}
                className="cursor-pointer border-b border-line hover:bg-elevated"
              >
                <td className="px-3 py-2">
                  <div className="font-mono text-sm font-semibold">{h.symbol}</div>
                  <div className="max-w-[140px] truncate font-mono text-[10px] text-faint">
                    {h.name}
                  </div>
                </td>
                <td className="px-3 py-2 font-mono text-[11px] uppercase text-muted">
                  {h.chain}
                  <span className="block text-[10px] text-faint">{sourceLabel(h.source)}</span>
                </td>
                <td className="px-3 py-2 font-mono text-sm tabular">{px(h.dex?.priceUsd)}</td>
                <td className={`px-3 py-2 font-mono text-sm tabular ${(chg5 ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                  {pct(chg5, 1)}
                </td>
                <td className={`px-3 py-2 font-mono text-sm tabular ${(chg1 ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                  {pct(chg1, 1)}
                </td>
                <td className={`px-3 py-2 font-mono text-sm tabular ${(chg6 ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                  {pct(chg6, 1)}
                </td>
                <td className="px-3 py-2 font-mono text-sm tabular">{usd(h.dex?.liquidityUsd)}</td>
                <td className="px-3 py-2 font-mono text-sm tabular">{usd(h.dex?.fdv ?? h.dex?.marketCap)}</td>
                <td className="px-3 py-2 font-mono text-sm tabular text-down">
                  {h.fdvCliff ? `${h.fdvCliff.toFixed(0)}×` : "—"}
                </td>
                <td className="px-3 py-2 font-mono text-sm tabular">{usd(h.dex?.volumeH1)}</td>
                <td className="px-3 py-2 font-mono text-sm tabular">
                  {volLiq ? `${volLiq.toFixed(1)}×` : "—"}
                </td>
                <td className="px-3 py-2 font-mono text-[11px] tabular text-muted">
                  {h.dex ? `${h.dex.buysH1}/${h.dex.sellsH1}` : "—"}
                </td>
                <td className="px-3 py-2 font-mono text-sm tabular text-wait">
                  {h.boost ? `${h.boost}×` : "—"}
                </td>
                <td className="px-3 py-2">
                  <span className={`inline-block rounded-full px-2 py-0.5 text-[10px] ${verdictClass(h.verdict)}`}>
                    {verdictLabel(h.verdict)}
                  </span>
                </td>
                <td className="px-3 py-2 font-mono text-[11px] text-faint">
                  {ageLabel(h.createdAt || h.dex?.pairCreatedAt)}
                </td>
                <td className="px-3 py-2">
                  {onPin ? (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onPin(h);
                      }}
                      className={`h-11 min-w-11 rounded-md px-2 font-mono text-[11px] ${
                        pinned ? "bg-accent text-accent-fg" : "bg-elevated text-muted"
                      }`}
                    >
                      {pinned ? "PIN" : "+"}
                    </button>
                  ) : null}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
