import { Link } from "@tanstack/react-router";
import type { GiMark } from "@/lib/market/client-store";
import { pct, px } from "@/lib/market/format";

export function GiList({ marks, limit }: { marks: GiMark[]; limit?: number }) {
  const rows = (limit ? marks.slice(0, limit) : marks).filter(Boolean);
  if (!rows.length) {
    return <p className="text-sm text-muted">No marks on the book yet. DeepHeat will post when a window opens.</p>;
  }
  return (
    <ul className="space-y-2">
      {rows.map((m) => (
        <li key={m.id} className="flex items-start justify-between gap-3 border-b border-line pb-2 last:border-0">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-sm font-semibold">{m.symbol}</span>
              <span className={`font-mono text-[10px] uppercase ${m.side === "short" ? "text-down" : "text-up"}`}>
                {m.side} {m.status}
              </span>
            </div>
            <p className="mt-0.5 truncate text-xs text-muted">{m.note}</p>
          </div>
          <div className="shrink-0 text-right">
            <div className="font-mono text-sm tabular">{px(m.entry)}</div>
            {m.pnl != null ? (
              <div className={`font-mono text-[11px] tabular ${m.pnl >= 0 ? "text-up" : "text-down"}`}>
                {pct(m.pnl * 100, 2)}
              </div>
            ) : null}
          </div>
        </li>
      ))}
    </ul>
  );
}

export function GiTable({ marks }: { marks: GiMark[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[820px] text-left text-sm">
        <thead className="text-[11px] uppercase tracking-[0.16em] text-muted">
          <tr className="border-b border-line">
            <th className="py-2 font-medium">Date</th>
            <th className="py-2 font-medium">Market</th>
            <th className="py-2 font-medium">Side</th>
            <th className="py-2 font-medium">Entry</th>
            <th className="py-2 font-medium">Target / stop</th>
            <th className="py-2 font-medium">Status</th>
            <th className="py-2 font-medium">PnL</th>
          </tr>
        </thead>
        <tbody>
          {marks.map((m) => (
            <tr key={m.id} className="border-b border-line/70">
              <td className="py-2 font-mono text-xs tabular text-muted">{m.day}</td>
              <td className="py-2">
                <Link to="/ta" search={{ s: `${m.symbol}USDT` }} className="font-mono font-semibold hover:underline">
                  {m.symbol}
                </Link>
              </td>
              <td className={`py-2 font-mono text-xs uppercase ${m.side === "short" ? "text-down" : "text-up"}`}>
                {m.side}
              </td>
              <td className="py-2 font-mono tabular">{px(m.entry)}</td>
              <td className="py-2 font-mono text-xs tabular text-muted">
                {px(m.target)} / {px(m.stop)}
              </td>
              <td className="py-2 font-mono text-xs uppercase text-muted">{m.status}</td>
              <td className={`py-2 font-mono tabular ${ (m.pnl ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                {m.pnl != null ? pct(m.pnl * 100, 2) : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
