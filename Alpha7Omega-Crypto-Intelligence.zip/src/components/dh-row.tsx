import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { BRAND } from "@/lib/brand";
import type { DeepHeatRow } from "@/lib/market/deepheat";
import { pct, px } from "@/lib/market/format";
import { SECTOR_LABEL } from "@/lib/market/sectors";

export function DhRow({
  row,
  onPin,
  pinned,
}: {
  row: DeepHeatRow;
  onPin?: (symbol: string) => void;
  pinned?: boolean;
}) {
  const up = row.chg24 >= 0;
  return (
    <article className="glass rounded-xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-sm font-semibold tracking-tight">{row.symbol}</span>
            <Badge className="bg-elevated text-faint">{SECTOR_LABEL[row.sector]}</Badge>
            <span className={`font-mono text-xs tabular ${up ? "text-up" : "text-down"}`}>
              {pct(row.chg24, 2)}
            </span>
          </div>
          <p className="mt-1 text-sm leading-relaxed text-muted">{row.thesis}</p>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-mono text-[10px] uppercase tracking-widest text-faint">{BRAND.dh}</div>
          <div className="font-mono text-xl tabular">{row.dh}</div>
          <div className="font-mono text-xs tabular text-muted">{px(row.price)}</div>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Link
          to="/ta"
          search={{ s: `${row.symbol}USDT` }}
          className="inline-flex h-8 items-center rounded-sm bg-elevated px-2.5 font-mono text-xs uppercase tracking-wide text-fg hover:bg-line"
        >
          TA
        </Link>
        {onPin ? (
          <button
            type="button"
            onClick={() => onPin(row.symbol)}
            className={`inline-flex h-8 items-center rounded-sm px-2.5 font-mono text-xs uppercase tracking-wide ${
              pinned ? "bg-accent text-accent-fg" : "bg-elevated text-muted"
            }`}
          >
            {pinned ? "Pinned" : "Pin"}
          </button>
        ) : null}
      </div>
    </article>
  );
}
