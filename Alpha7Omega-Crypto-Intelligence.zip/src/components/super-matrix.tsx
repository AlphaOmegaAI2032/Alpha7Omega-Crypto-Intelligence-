import { Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ALERTS,
  COMPARE,
  COMPARE_META,
  NEW_PRINTS,
  PLAN,
  alertStatus,
  bucketClass,
  bucketLabel,
  type AlertRule,
  type CompareRow,
} from "@/lib/market/compare";
import { pct, px } from "@/lib/market/format";

type Quote = { price: number; chg: number | null };

export function SuperMatrix({ quotes }: { quotes: Record<string, Quote> }) {
  const [tab, setTab] = useState<"compare" | "plan" | "alerts" | "new">("compare");
  const stats = useMemo(() => {
    const worked = COMPARE.filter((r) => r.bucket === "worked").length;
    const stopped = COMPARE.filter((r) => r.bucket === "stopped").length;
    const late = COMPARE.filter((r) => r.bucket === "late").length;
    const waiting = COMPARE.filter((r) => r.bucket === "waiting").length;
    return { n: COMPARE.length, worked, stopped, late, waiting };
  }, []);

  return (
    <div className="space-y-4">
      <section className="glass rounded-xl p-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-faint">
          Super matrix · {COMPARE_META.from.weekday} {COMPARE_META.from.stamp} → {COMPARE_META.to.weekday}{" "}
          {COMPARE_META.to.stamp}
        </p>
        <h2 className="mt-1 text-sm font-medium">Sunday book vs Wednesday tape · {COMPARE_META.hours}h</h2>
        <p className="mt-1 max-w-3xl text-sm leading-relaxed text-muted">{COMPARE_META.note}</p>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Stat k="Worked" v={String(stats.worked)} tone="up" />
          <Stat k="Stopped" v={String(stats.stopped)} tone="down" />
          <Stat k="Too late" v={String(stats.late)} tone="muted" />
          <Stat k="Still armed" v={String(stats.waiting)} tone="wait" />
        </div>
        <p className="mt-3 font-mono text-[11px] text-faint">
          Next 20 screenshots append as a new stamp. 09:50 is locked.
        </p>
      </section>

      <div className="flex flex-wrap gap-1">
        {(
          [
            ["compare", "Sun → Wed"],
            ["plan", "Action plan"],
            ["alerts", "Alerts"],
            ["new", "New prints"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`h-11 rounded-md px-3 font-mono text-xs ${
              tab === id ? "bg-accent text-accent-fg" : "bg-surface text-muted"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "compare" ? <CompareTable rows={COMPARE} quotes={quotes} /> : null}
      {tab === "plan" ? <PlanList /> : null}
      {tab === "alerts" ? <AlertList quotes={quotes} /> : null}
      {tab === "new" ? <CompareTable rows={NEW_PRINTS} quotes={quotes} fresh /> : null}
    </div>
  );
}

function Stat({ k, v, tone }: { k: string; v: string; tone: "up" | "down" | "wait" | "muted" }) {
  const cls =
    tone === "up" ? "text-up" : tone === "down" ? "text-down" : tone === "wait" ? "text-wait" : "text-muted";
  return (
    <div className="rounded-lg bg-surface px-3 py-2">
      <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{k}</p>
      <p className={`mt-0.5 font-mono text-lg tabular ${cls}`}>{v}</p>
    </div>
  );
}

function CompareTable({
  rows,
  quotes,
  fresh,
}: {
  rows: CompareRow[];
  quotes: Record<string, Quote>;
  fresh?: boolean;
}) {
  return (
    <div className="overflow-x-auto rounded-xl border border-line">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="bg-surface font-mono text-[10px] uppercase tracking-widest text-faint">
          <tr>
            <th className="px-3 py-2 font-medium">Name</th>
            <th className="px-3 py-2 font-medium">Sun 15:00</th>
            <th className="px-3 py-2 font-medium">Wed 09:36</th>
            <th className="px-3 py-2 font-medium">From Sun</th>
            <th className="px-3 py-2 font-medium">Live</th>
            <th className="px-3 py-2 font-medium">Call</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const q = quotes[r.sym.toUpperCase()] ?? quotes[norm(r.sym)];
            return (
              <tr key={r.id} className="border-t border-line">
                <td className="px-3 py-3 align-top">
                  <Link to="/ta" search={{ s: `${r.sym}USDT` }} className="font-mono font-semibold hover:underline">
                    {r.sym}
                  </Link>
                  <p className={`mt-0.5 font-mono text-[10px] uppercase ${bucketClass(r.bucket)}`}>
                    {bucketLabel(r.bucket)}
                  </p>
                </td>
                <td className="px-3 py-3 align-top font-mono text-xs tabular">
                  {fresh || !r.sunPx ? (
                    <span className="text-faint">off-board</span>
                  ) : (
                    <>
                      {px(r.sunPx)}
                      <span className={`ml-1 ${r.sunChg >= 0 ? "text-up" : "text-down"}`}>{pct(r.sunChg, 1)}</span>
                    </>
                  )}
                </td>
                <td className="px-3 py-3 align-top font-mono text-xs tabular">
                  {px(r.wedPx)}
                  <span className={`ml-1 ${r.wedChg >= 0 ? "text-up" : "text-down"}`}>{pct(r.wedChg, 1)}</span>
                </td>
                <td className={`px-3 py-3 align-top font-mono text-xs tabular ${r.fromSun >= 0 ? "text-up" : "text-down"}`}>
                  {fresh || !r.sunPx ? "—" : pct(r.fromSun, 1)}
                </td>
                <td className="px-3 py-3 align-top font-mono text-xs tabular">
                  {q ? (
                    <>
                      {px(q.price)}
                      <span className={`ml-1 ${(q.chg ?? 0) >= 0 ? "text-up" : "text-down"}`}>{pct(q.chg, 1)}</span>
                    </>
                  ) : (
                    <span className="text-faint">—</span>
                  )}
                </td>
                <td className="px-3 py-3 align-top">
                  <p className="text-xs">{r.nowCall}</p>
                  <p className="mt-1 max-w-sm text-[11px] leading-relaxed text-faint">{r.note}</p>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function PlanList() {
  return (
    <ol className="grid gap-3 lg:grid-cols-2">
      {PLAN.map((p) => (
        <li key={p.id} className="glass rounded-xl p-4">
          <div className="flex items-baseline justify-between gap-2">
            <p className="font-mono text-[10px] uppercase tracking-widest text-faint">Step {p.rank}</p>
            <p className="font-mono text-[10px] uppercase tracking-wide text-wait">{p.call}</p>
          </div>
          <h3 className="mt-1 text-sm font-medium">{p.title}</h3>
          <p className="mt-2 font-mono text-xs text-muted">{p.names}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">{p.why}</p>
          <p className="mt-2 font-mono text-[11px] text-faint">Size · {p.size}</p>
        </li>
      ))}
    </ol>
  );
}

function AlertList({ quotes }: { quotes: Record<string, Quote> }) {
  return (
    <ul className="grid gap-2">
      {ALERTS.map((a) => (
        <AlertCard key={a.id} rule={a} quote={quotes[a.sym.toUpperCase()]} />
      ))}
    </ul>
  );
}

function AlertCard({ rule, quote }: { rule: AlertRule; quote?: Quote }) {
  const last = quote?.price ?? null;
  const status = alertStatus(rule, last);
  const fired = status === "FIRED";
  const tone =
    rule.kind === "abort" || rule.kind === "cover"
      ? fired
        ? "text-down"
        : "text-muted"
      : rule.kind === "stalk"
        ? fired
          ? "text-up"
          : "text-wait"
        : rule.kind === "stand"
          ? "text-wait"
          : fired
            ? "text-down"
            : "text-wait";
  return (
    <li className="flex flex-col gap-2 rounded-xl border border-line bg-surface px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <div className="flex flex-wrap items-baseline gap-2">
          <span className="font-mono text-sm font-semibold">{rule.sym}</span>
          <span className={`font-mono text-[10px] uppercase tracking-wide ${tone}`}>{status}</span>
          <span className="font-mono text-[10px] uppercase tracking-widest text-faint">{rule.kind}</span>
        </div>
        <p className="mt-1 text-sm">{rule.label}</p>
        <p className="mt-1 text-[11px] leading-relaxed text-faint">{rule.why}</p>
      </div>
      <div className="shrink-0 text-right font-mono text-xs tabular">
        <p className="text-faint">
          {rule.dir === "below" ? "≤" : "≥"} {px(rule.level)}
        </p>
        <p className={last != null ? "" : "text-faint"}>{last != null ? px(last) : "—"}</p>
      </div>
    </li>
  );
}

function norm(s: string) {
  return s.replace(/[^\w]/g, "").toUpperCase();
}
