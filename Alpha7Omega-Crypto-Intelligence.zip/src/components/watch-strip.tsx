import { Badge } from "@/components/ui/badge";
import { fundingPct, pct, px, usd } from "@/lib/market/format";
import { verdictClass, verdictLabel } from "@/lib/market/labels";
import type { ScoredMover } from "@/lib/market/types";

export function WatchStrip({
  mars,
  useless,
  ff,
  onOpen,
}: {
  mars: ScoredMover | null;
  useless: ScoredMover | null;
  ff?: ScoredMover | null;
  onOpen: (item: ScoredMover) => void;
}) {
  return (
    <div className="mb-4 grid gap-2 lg:grid-cols-3">
      <WatchCard
        title="FF — SHORT NOW"
        note="Cleanest new fade. +23%, funding 0.052%. Loss of 0.145 then 0.132. Stop 0.152. Isolated, 1/3 of MARS."
        item={ff ?? null}
        onOpen={onOpen}
        tone="down"
      />
      <WatchCard
        title="USELESS — RE-FADE TRIGGER"
        note="1h stalled +1%. Funding 8.4 bps. Fire on loss of 0.320 then 0.312 AVL. Stop 0.337. Half Sunday size. Not revenge at 0.323."
        item={useless}
        onOpen={onOpen}
        tone="wait"
      />
      <WatchCard
        title="MARSCOIN — trail leftover"
        note="T1 0.150 hit @ 0.137. Do not add. Cover on reclaim 0.155 / 0.186."
        item={mars}
        onOpen={onOpen}
      />
    </div>
  );
}

function WatchCard({
  title,
  note,
  item,
  onOpen,
  tone,
}: {
  title: string;
  note: string;
  item: ScoredMover | null;
  onOpen: (item: ScoredMover) => void;
  tone?: "down" | "wait";
}) {
  const last = item?.perp?.last ?? item?.dex?.priceUsd ?? null;
  const chg1 = item?.dex?.changeH1;
  const chg5 = item?.dex?.changeM5;
  return (
    <button
      type="button"
      onClick={() => item && onOpen(item)}
      className={`rounded-lg border px-3 py-3 text-left hover:border-line-strong ${
        tone === "down" ? "border-down/40 bg-down/5" : tone === "wait" ? "border-wait/40 bg-wait/5" : "border-line bg-surface"
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div
          className={`font-mono text-[10px] uppercase tracking-widest ${
            tone === "down" ? "text-down" : tone === "wait" ? "text-wait" : "text-muted"
          }`}
        >
          {title}
        </div>
        {item ? <Badge className={verdictClass(item.verdict)}>{verdictLabel(item.verdict)}</Badge> : null}
      </div>
      {item ? (
        <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
          <K label="Mark" value={px(last)} />
          <K label="5m" value={pct(chg5)} tone={(chg5 ?? 0) >= 0 ? "up" : "down"} />
          <K label="1h" value={pct(chg1)} tone={(chg1 ?? 0) >= 0 ? "up" : "down"} />
          <K label="Pool" value={usd(item.dex?.liquidityUsd)} />
          <K label="Cliff" value={item.cliff ? `${item.cliff.toFixed(0)}×` : "—"} tone="down" />
          <K label="Fund" value={fundingPct(item.perp?.funding)} />
        </div>
      ) : (
        <div className="skel mt-3 h-12 rounded-md" />
      )}
      <p className="mt-2 text-[11px] leading-relaxed text-faint">{note}</p>
    </button>
  );
}

function K({ label, value, tone }: { label: string; value: string; tone?: "up" | "down" }) {
  return (
    <div>
      <div className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</div>
      <div
        className={`mt-0.5 font-mono text-sm tabular ${
          tone === "down" ? "text-down" : tone === "up" ? "text-up" : "text-fg"
        }`}
      >
        {value}
      </div>
    </div>
  );
}
