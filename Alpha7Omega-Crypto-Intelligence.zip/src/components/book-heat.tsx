import type { BtcBook } from "@/lib/market/book";
import { usd } from "@/lib/market/format";

export function BookHeat({ book }: { book: BtcBook }) {
  const max = Math.max(1, ...book.bids.map((l) => l.usd), ...book.asks.map((l) => l.usd));
  const rows = [
    ...[...book.asks].reverse().map((l) => ({ ...l, side: "ask" as const })),
    ...book.bids.map((l) => ({ ...l, side: "bid" as const })),
  ].slice(0, 56);

  if (!rows.length) {
    return (
      <p className="rounded-xl border border-dashed border-line px-4 py-10 text-center text-sm text-muted">
        Spot book not on the wire right now.
      </p>
    );
  }

  return (
    <div className="space-y-0.5">
      {rows.map((l) => {
        const w = Math.max(4, (l.usd / max) * 100);
        const near = Math.abs(l.price - book.mid) / book.mid < 0.0008;
        return (
          <div key={`${l.side}-${l.price}`} className="flex items-center gap-2">
            <span className={`w-20 shrink-0 font-mono text-[11px] tabular ${l.side === "bid" ? "text-up" : "text-down"}`}>
              {l.price.toFixed(1)}
            </span>
            <div className="h-3 flex-1 overflow-hidden rounded-sm bg-elevated">
              <div
                className={`h-full ${l.side === "bid" ? "bg-up/70" : "bg-down/70"} ${near ? "opacity-100" : "opacity-80"}`}
                style={{ width: `${w}%` }}
              />
            </div>
            <span className="w-16 shrink-0 text-right font-mono text-[10px] tabular text-faint">{usd(l.usd, 0)}</span>
          </div>
        );
      })}
    </div>
  );
}
