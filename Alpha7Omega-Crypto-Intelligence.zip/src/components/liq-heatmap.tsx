import { useLayoutEffect, useRef, useState, type PointerEvent } from "react";
import type { BtcBook, Candle } from "@/lib/market/book";
import { px, usd } from "@/lib/market/format";

export type HeatBand = 0.006 | 0.012 | 0.025 | 0.05 | "48h";

type Tip = { x: number; y: number; price: number; label: string };

function rangeFor(book: BtcBook, band: HeatBand) {
  const mid = book.mid || book.last;
  if (band === "48h" && book.candles.length > 4) {
    const hi = Math.max(...book.candles.map((c) => c.h), mid);
    const lo = Math.min(...book.candles.map((c) => c.l), mid);
    const pad = (hi - lo) * 0.06 || mid * 0.004;
    return { lo: lo - pad, hi: hi + pad, mid };
  }
  const b = typeof band === "number" ? band : 0.012;
  return { lo: mid * (1 - b), hi: mid * (1 + b), mid };
}

function buildProfile(candles: Candle[], lo: number, hi: number, rows: number) {
  const grid = Array.from({ length: candles.length }, () => new Float32Array(rows));
  const span = hi - lo || 1;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const top = Math.min(c.h, hi);
    const bot = Math.max(c.l, lo);
    if (top <= lo || bot >= hi) continue;
    const r0 = Math.max(0, Math.floor(((bot - lo) / span) * rows));
    const r1 = Math.min(rows - 1, Math.floor(((top - lo) / span) * rows));
    const closeRow = Math.max(0, Math.min(rows - 1, Math.floor(((c.c - lo) / span) * rows)));
    const n = Math.max(1, r1 - r0 + 1);
    for (let r = r0; r <= r1; r++) {
      const dist = Math.abs(r - closeRow);
      grid[i][r] += (c.v / n) * (0.4 + 0.6 / (1 + dist));
    }
  }
  return grid;
}

export function LiqHeatmap({ book, band }: { book: BtcBook; band: HeatBand }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tip, setTip] = useState<Tip | null>(null);

  useLayoutEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    let raf = 0;

    const draw = () => {
      const w = wrap.clientWidth;
      const h = Math.max(wrap.clientHeight, 320);
      if (w < 40) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const pw = Math.floor(w * dpr);
      const ph = Math.floor(h * dpr);
      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
        canvas.style.width = `${w}px`;
        canvas.style.height = `${h}px`;
      }
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = "#08080a";
      ctx.fillRect(0, 0, w, h);

      const { lo, hi, mid } = rangeFor(book, band);
      const span = hi - lo || 1;
      const rows = Math.max(40, Math.min(90, Math.round(h / 5)));
      const padL = 72;
      const railW = Math.max(72, Math.min(120, w * 0.2));
      const padR = railW + 52;
      const padT = 8;
      const padB = 20;
      const innerW = Math.max(40, w - padL - padR);
      const innerH = Math.max(40, h - padT - padB);
      const yOf = (price: number) => padT + ((hi - price) / span) * innerH;
      const candles = book.candles.length ? book.candles : [];
      const cols = Math.max(1, candles.length);
      const colW = innerW / cols;
      const rh = innerH / rows;

      ctx.strokeStyle = "#1c1c22";
      ctx.lineWidth = 1;
      for (let i = 1; i < 4; i++) {
        const yy = padT + (innerH * i) / 4;
        ctx.beginPath();
        ctx.moveTo(padL, yy);
        ctx.lineTo(padL + innerW, yy);
        ctx.stroke();
      }

      if (candles.length) {
        const profile = buildProfile(candles, lo, hi, rows);
        const volRow = new Float32Array(rows);
        let maxCell = 1;
        let maxVol = 1;
        for (const col of profile) {
          for (let r = 0; r < rows; r++) {
            if (col[r] > maxCell) maxCell = col[r];
            volRow[r] += col[r];
          }
        }
        for (let r = 0; r < rows; r++) if (volRow[r] > maxVol) maxVol = volRow[r];

        const leftW = padL - 8;
        for (let r = 0; r < rows; r++) {
          if (volRow[r] <= 0) continue;
          const t = Math.min(1, Math.sqrt(volRow[r] / maxVol));
          const price = lo + ((r + 0.5) / rows) * span;
          ctx.fillStyle = price >= mid ? `rgba(226,60,50,${0.35 + t * 0.65})` : `rgba(62,207,142,${0.35 + t * 0.65})`;
          const bw = Math.max(4, t * (leftW - 4));
          ctx.fillRect(4 + (leftW - 4 - bw), padT + (rows - 1 - r) * rh, bw, rh + 0.3);
        }

        for (let i = 0; i < profile.length; i++) {
          const x = padL + i * colW;
          let colMax = 1;
          for (let r = 0; r < rows; r++) if (profile[i][r] > colMax) colMax = profile[i][r];
          for (let r = 0; r < rows; r++) {
            const v = profile[i][r];
            if (v <= 0) continue;
            const t = Math.min(1, v / colMax);
            if (t < 0.08) continue;
            const price = lo + ((r + 0.5) / rows) * span;
            const a = 0.18 + t * 0.55;
            ctx.fillStyle = price >= mid ? `rgba(226,60,50,${a})` : `rgba(62,207,142,${a})`;
            ctx.fillRect(x, padT + (rows - 1 - r) * rh, Math.max(1.5, colW + 0.3), rh + 0.4);
          }
        }

        const liveBid = new Float32Array(rows);
        const liveAsk = new Float32Array(rows);
        const bucket = (price: number) => Math.max(0, Math.min(rows - 1, Math.floor(((price - lo) / span) * rows)));
        for (const l of book.bids) if (l.price >= lo && l.price <= hi) liveBid[bucket(l.price)] += l.usd;
        for (const l of book.asks) if (l.price >= lo && l.price <= hi) liveAsk[bucket(l.price)] += l.usd;
        let liveMax = 1;
        for (let r = 0; r < rows; r++) liveMax = Math.max(liveMax, liveBid[r], liveAsk[r]);

        const strip = Math.max(10, colW * 4);
        const nowX = padL + innerW - strip;
        for (let r = 0; r < rows; r++) {
          const ry = padT + (rows - 1 - r) * rh;
          if (liveBid[r] > 0) {
            const t = Math.min(1, Math.sqrt(liveBid[r] / liveMax));
            ctx.fillStyle = `rgba(62,207,142,${0.35 + t * 0.65})`;
            ctx.fillRect(nowX, ry, strip, rh + 0.3);
          }
          if (liveAsk[r] > 0) {
            const t = Math.min(1, Math.sqrt(liveAsk[r] / liveMax));
            ctx.fillStyle = `rgba(226,60,50,${0.35 + t * 0.65})`;
            ctx.fillRect(nowX, ry, strip, rh + 0.3);
          }
        }

        const bw = Math.max(2.2, colW * 0.7);
        for (let i = 0; i < candles.length; i++) {
          const c = candles[i];
          const x = padL + (i + 0.5) * colW;
          const up = c.c >= c.o;
          ctx.strokeStyle = up ? "#3ecf8e" : "#e23c32";
          ctx.fillStyle = up ? "#3ecf8e" : "#e23c32";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(x, yOf(c.h));
          ctx.lineTo(x, yOf(c.l));
          ctx.stroke();
          const top = yOf(Math.max(c.o, c.c));
          const bot = yOf(Math.min(c.o, c.c));
          ctx.fillRect(x - bw / 2, top, bw, Math.max(1.2, bot - top));
        }

        ctx.beginPath();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = "#eceae4";
        candles.forEach((c, i) => {
          const x = padL + (i + 0.5) * colW;
          const yy = yOf(c.c);
          if (i === 0) ctx.moveTo(x, yy);
          else ctx.lineTo(x, yy);
        });
        ctx.stroke();

        const railX = w - padR;
        ctx.fillStyle = "#111114";
        ctx.fillRect(railX, padT, railW, innerH);
        ctx.strokeStyle = "#26262b";
        ctx.strokeRect(railX + 0.5, padT + 0.5, railW - 1, innerH - 1);
        for (let r = 0; r < rows; r++) {
          const ry = padT + (rows - 1 - r) * rh;
          if (liveBid[r] > 0) {
            ctx.fillStyle = "#3ecf8e";
            ctx.fillRect(railX + 3, ry, Math.max(3, (liveBid[r] / liveMax) * (railW - 6)), Math.max(1.2, rh - 0.4));
          }
          if (liveAsk[r] > 0) {
            ctx.fillStyle = "#e23c32";
            ctx.fillRect(railX + 3, ry, Math.max(3, (liveAsk[r] / liveMax) * (railW - 6)), Math.max(1.2, rh - 0.4));
          }
        }

        (canvas as HTMLCanvasElement & { __layout?: Record<string, number> }).__layout = {
          lo, hi, padL, innerW, padT, innerH,
        };
      }

      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = "rgba(236,234,228,0.7)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(padL, yOf(mid));
      ctx.lineTo(w - 50, yOf(mid));
      ctx.stroke();
      ctx.setLineDash([]);

      for (const wall of book.walls.slice(0, 8)) {
        if (wall.price < lo || wall.price > hi) continue;
        ctx.fillStyle = wall.side === "bid" ? "rgba(62,207,142,0.85)" : "rgba(226,60,50,0.85)";
        ctx.fillRect(padL, yOf(wall.price) - 1, innerW, 2);
      }

      ctx.font = "10px IBM Plex Mono, ui-monospace, monospace";
      ctx.textBaseline = "middle";
      ctx.textAlign = "left";
      ctx.fillStyle = "#8c8b86";
      for (const p of [hi, (hi + mid) / 2, mid, (lo + mid) / 2, lo]) {
        ctx.fillText(p >= 100 ? p.toFixed(0) : p.toFixed(2), w - 48, yOf(p));
      }
      ctx.fillStyle = "#eceae4";
      ctx.fillText(mid.toFixed(1), w - 48, yOf(mid));

      ctx.textAlign = "center";
      ctx.fillStyle = "#8c8b86";
      if (candles.length) {
        const fmt = (t: number) =>
          new Date(t).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Africa/Johannesburg" });
        ctx.fillText(fmt(candles[0].t), padL + 22, h - 8);
        ctx.fillText("now", padL + innerW - 12, h - 8);
      }

      (canvas as HTMLCanvasElement & { __layout?: Record<string, number> }).__layout = {
        lo, hi, padL, innerW: innerW, padT, innerH,
      };
    };

    draw();
    const ro = new ResizeObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(draw);
    });
    ro.observe(wrap);
    return () => {
      ro.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [book, band]);

  function onMove(e: PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const layout = (canvas as HTMLCanvasElement & { __layout?: { lo: number; hi: number; padL: number; innerW: number; padT: number; innerH: number } }).__layout;
    if (!layout) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const { lo, hi, padL, innerW, padT, innerH } = layout;
    if (y < padT || y > padT + innerH || x < padL) {
      setTip(null);
      return;
    }
    const price = hi - ((y - padT) / innerH) * (hi - lo);
    const near = [...book.bids, ...book.asks].reduce<{ usd: number; size: number; side: string } | null>((acc, l) => {
      if (Math.abs(l.price - price) > (hi - lo) / 60) return acc;
      const side = book.asks.includes(l) ? "ask" : "bid";
      if (!acc || l.usd > acc.usd) return { usd: l.usd, size: l.size, side };
      return acc;
    }, null);
    setTip({
      x,
      y,
      price,
      label: near ? `${near.side} ${near.size.toFixed(2)} BTC · ${usd(near.usd, 0)}` : "No rest at this tick",
    });
  }

  const { lo, hi, mid } = rangeFor(book, band);
  const hasBody = book.candles.length > 4 || book.bids.length > 2;

  return (
    <div className="relative">
      <div
        ref={wrapRef}
        className="relative h-[min(56vh,560px)] min-h-[320px] w-full overflow-hidden rounded-md bg-bg"
      >
        {!hasBody ? (
          <p className="absolute inset-0 z-10 flex items-center justify-center text-sm text-muted">Waiting on the BTC book…</p>
        ) : null}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 h-full w-full touch-none"
          onPointerMove={onMove}
          onPointerLeave={() => setTip(null)}
          role="img"
          aria-label="BTC liquidity heatmap"
        />
        {tip ? (
          <div
            className="pointer-events-none absolute z-10 rounded-sm border border-line bg-surface px-2 py-1 font-mono text-[11px] text-fg"
            style={{
              left: Math.min(tip.x + 12, (wrapRef.current?.clientWidth || 300) - 168),
              top: Math.max(8, tip.y - 36),
            }}
          >
            <div>{px(tip.price)}</div>
            <div className="text-muted">{tip.label}</div>
          </div>
        ) : null}
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 font-mono text-[10px] uppercase tracking-widest text-faint">
        <span>
          {band === "48h" ? "48h range" : `±${((typeof band === "number" ? band : 0.012) * 100).toFixed(1)}% of mid`}
          {" · "}
          {px(lo)} – {px(hi)}
        </span>
        <span>mid {px(mid)} · green bids · red asks · candles over heat</span>
      </div>
    </div>
  );
}

export function DepthLadder({ book, band }: { book: BtcBook; band: HeatBand }) {
  const { lo, hi, mid } = rangeFor(book, band);
  const bids = book.bids.filter((l) => l.price >= lo);
  const askSet = new Set(book.asks.filter((l) => l.price <= hi));
  const asks = [...askSet].sort((a, b) => b.price - a.price);
  const max = Math.max(1, ...bids.map((l) => l.usd), ...asks.map((l) => l.usd));
  const rows = [...asks, ...bids].slice(0, 64);
  if (!rows.length) {
    return <p className="px-4 py-10 text-center text-sm text-muted">Spot book not on the wire.</p>;
  }
  return (
    <div className="max-h-[min(56vh,560px)] space-y-0.5 overflow-y-auto">
      {rows.map((l) => {
        const side = askSet.has(l) ? "ask" : "bid";
        const width = Math.max(6, (l.usd / max) * 100);
        const near = Math.abs(l.price - mid) / mid < 0.0008;
        return (
          <div key={`${side}-${l.price}`} className="flex items-center gap-2">
            <span className={`w-[4.5rem] shrink-0 font-mono text-[11px] tabular ${side === "bid" ? "text-up" : "text-down"}`}>
              {l.price.toFixed(0)}
            </span>
            <div className="h-3 flex-1 overflow-hidden rounded-sm bg-elevated">
              <div className={`h-full ${side === "bid" ? "bg-up/80" : "bg-down/80"} ${near ? "opacity-100" : "opacity-80"}`} style={{ width: `${width}%` }} />
            </div>
            <span className="w-14 shrink-0 text-right font-mono text-[10px] tabular text-faint">{l.size.toFixed(2)}</span>
            <span className="w-16 shrink-0 text-right font-mono text-[10px] tabular text-muted">{usd(l.usd, 0)}</span>
          </div>
        );
      })}
    </div>
  );
}

export function bandLabel(b: HeatBand) {
  if (b === "48h") return "48h";
  return `±${(b * 100).toFixed(1)}%`;
}

export function imbTone(imb: number) {
  if (imb >= 0.55) return "text-up";
  if (imb <= 0.45) return "text-down";
  return "text-fg";
}

export { rangeFor };
