import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  BookMarked,
  Brain,
  ChartCandlestick,
  Fingerprint,
  Globe,
  LayoutDashboard,
  Layers,
  Newspaper,
  Orbit,
  Radar,
  TrendingDown,
  Waves,
} from "lucide-react";
import { useEffect, useState } from "react";
import { BRAND } from "@/lib/brand";
import { pct, px, sastClock, utcClock } from "@/lib/market/format";
import { useBtcBook, useTerra } from "@/lib/market/hooks";

const NAV = [
  { to: "/", label: "Desk", icon: LayoutDashboard },
  { to: "/hunt", label: "Hunt", icon: Radar },
  { to: "/mint", label: "Mint", icon: Fingerprint },
  { to: "/flow", label: "Flow", icon: Layers },
  { to: "/map", label: "Map", icon: Globe },
  { to: "/shorts", label: "Shorts", icon: TrendingDown },
  { to: "/ta", label: "Chart", icon: ChartCandlestick },
  { to: "/intel", label: "Intel", icon: Newspaper },
  { to: "/godmode", label: "Godmode", icon: Brain },
  { to: "/ledger", label: "Ledger", icon: BookMarked },
  { to: "/btc", label: "BTC Liq", icon: Waves },
  { to: "/terra", label: "Terra", icon: Orbit },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [clock, setClock] = useState("--:--:--");
  const [utc, setUtc] = useState("--:--:--");
  const btc = useBtcBook();
  const terra = useTerra();
  const lunc = terra.data?.assets.find((a) => a.id === "lunc");

  useEffect(() => {
    const tick = () => {
      setClock(sastClock());
      setUtc(utcClock());
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const last = btc.data?.last;
  const chg = btc.data?.change24;

  return (
    <div className="flex min-h-dvh flex-col overflow-x-hidden">
      <header className="sticky top-0 z-40 glass-head">
        <div className="mx-auto flex w-full max-w-[1400px] min-w-0 items-center gap-3 px-4 py-2.5">
          <Link to="/" className="flex shrink-0 items-baseline gap-2">
            <span className="text-base font-medium tracking-tight text-fg">{BRAND.lockup}</span>
            <span className="hidden text-xs uppercase tracking-widest text-muted sm:inline">
              {BRAND.product}
            </span>
          </Link>
          {last ? (
            <Link
              to="/btc"
              className="min-w-0 truncate font-mono text-xs tabular text-muted hover:text-fg"
            >
              BTC {px(last)}{" "}
              <span className={chg != null && chg >= 0 ? "text-up" : "text-down"}>{pct(chg)}</span>
            </Link>
          ) : null}
          {lunc?.price ? (
            <Link
              to="/terra"
              className="hidden min-w-0 truncate font-mono text-xs tabular text-muted hover:text-fg sm:inline"
            >
              LUNC {px(lunc.price)}{" "}
              <span className={(lunc.chg24h ?? 0) >= 0 ? "text-up" : "text-down"}>{pct(lunc.chg24h)}</span>
            </Link>
          ) : null}
          <div className="ml-auto flex min-w-0 items-center gap-3 font-mono text-xs tabular text-muted">
            <span className="hidden sm:inline">
              Wire {clock} SAST
              <span className="text-faint"> · {utc} UTC</span>
            </span>
            <Link
              to="/watch"
              className="inline-flex h-8 shrink-0 items-center rounded-sm px-2.5 text-xs text-fg hover:bg-elevated"
            >
              Watch
            </Link>
          </div>
        </div>
        <nav className="mx-auto flex w-full max-w-[1400px] gap-1 overflow-x-auto px-3 pb-2">
          {NAV.map((n) => {
            const active = n.to === "/" ? pathname === "/" : pathname === n.to || pathname.startsWith(`${n.to}/`);
            const Icon = n.icon;
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`flex h-10 shrink-0 items-center gap-1.5 rounded-sm px-3 text-sm transition-colors duration-150 ${
                  active ? "bg-accent text-accent-fg" : "text-muted hover:bg-elevated hover:text-fg"
                }`}
              >
                <Icon className="size-3.5" />
                {n.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="mx-auto w-full min-w-0 max-w-[1400px] flex-1 px-4 py-5 pb-16">
        <Outlet />
      </main>
      <footer className="px-4 py-4 text-center text-xs text-faint">{BRAND.footer}</footer>
    </div>
  );
}
