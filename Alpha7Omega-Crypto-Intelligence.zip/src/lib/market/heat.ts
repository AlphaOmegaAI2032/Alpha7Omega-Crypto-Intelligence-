import type { Timeframe } from "./types";

function lerp(a: number, b: number, t: number) {
  return Math.round(a + (b - a) * t);
}

export function heatColor(pct: number, scale: number): string {
  const t = Math.max(-1, Math.min(1, pct / scale));
  const mid = [48, 48, 54];
  if (t >= 0) {
    const u = t === 0 ? 0 : Math.max(0.32, t);
    const r = lerp(mid[0], 62, u);
    const g = lerp(mid[1], 207, u);
    const b = lerp(mid[2], 142, u);
    return `rgb(${r},${g},${b})`;
  }
  const u = Math.max(0.32, -t);
  const r = lerp(mid[0], 226, u);
  const g = lerp(mid[1], 60, u);
  const b = lerp(mid[2], 50, u);
  return `rgb(${r},${g},${b})`;
}

export function heatScale(tf: Timeframe): number {
  switch (tf) {
    case "1h":
      return 4;
    case "24h":
      return 8;
    case "7d":
      return 18;
    case "30d":
      return 32;
    case "90d":
      return 48;
    case "1y":
      return 80;
  }
}

export type ChangeFields = {
  chg1h: number | null;
  chg24h: number | null;
  chg7d: number | null;
  chg30d: number | null;
  chg90d?: number | null;
  chg1y?: number | null;
};

export function changeOf(c: ChangeFields, tf: Timeframe): number | null {
  switch (tf) {
    case "1h":
      return c.chg1h;
    case "24h":
      return c.chg24h;
    case "7d":
      return c.chg7d;
    case "30d":
      return c.chg30d;
    case "90d":
      return c.chg90d ?? null;
    case "1y":
      return c.chg1y ?? null;
  }
}
