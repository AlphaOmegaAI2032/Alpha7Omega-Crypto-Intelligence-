import { dhFades, dhLongs, type DeepHeatRow } from "./deepheat";
import {
  loadGi,
  markToMarket,
  saveGi,
  utcDay,
  type GiMark,
} from "./client-store";

function makeMark(row: DeepHeatRow, side: "long" | "short"): GiMark {
  const entry = row.price;
  const target = side === "short" ? entry * 0.92 : entry * 1.12;
  const stop = side === "short" ? entry * 1.05 : entry * 0.95;
  const now = Date.now();
  return {
    id: `${row.symbol}:${side}:${now}`,
    day: utcDay(now),
    symbol: row.symbol,
    side,
    entry,
    target,
    stop,
    status: "open",
    pnl: 0,
    note: row.thesis,
    openedAt: now,
    closedAt: null,
  };
}

export function syncGiBook(rows: DeepHeatRow[], prices: Record<string, number>): GiMark[] {
  const existing = loadGi();
  const now = Date.now();
  const marked = existing.map((m) => {
    const px = prices[m.symbol.toUpperCase()];
    return px ? markToMarket(m, px, now) : m;
  });
  const openSymSide = new Set(
    marked.filter((m) => m.status === "open").map((m) => `${m.symbol}:${m.side}`),
  );
  const openSym = new Set(marked.filter((m) => m.status === "open").map((m) => m.symbol));
  const openCount = marked.filter((m) => m.status === "open").length;
  const add: GiMark[] = [];
  for (const row of dhFades(rows, 8)) {
    if (!row.price || openCount + add.length >= 14) continue;
    const key = `${row.symbol}:short`;
    if (openSymSide.has(key) || openSym.has(row.symbol)) continue;
    add.push(makeMark(row, "short"));
    openSymSide.add(key);
    openSym.add(row.symbol);
  }
  for (const row of dhLongs(rows, 6)) {
    if (!row.price || openCount + add.length >= 14) continue;
    const key = `${row.symbol}:long`;
    if (openSymSide.has(key) || openSym.has(row.symbol)) continue;
    add.push(makeMark(row, "long"));
    openSymSide.add(key);
    openSym.add(row.symbol);
  }
  const next = [...add, ...marked].slice(0, 120);
  saveGi(next);
  return next;
}

export function giStats(marks: GiMark[]) {
  const settled = marks.filter((m) => m.status !== "open");
  const targets = settled.filter((m) => m.status === "target").length;
  const stopped = settled.filter((m) => m.status === "stopped").length;
  const expired = settled.filter((m) => m.status === "expired").length;
  const pnls = settled.map((m) => m.pnl).filter((n): n is number => n != null);
  const avg = pnls.length ? pnls.reduce((a, b) => a + b, 0) / pnls.length : 0;
  const hit = settled.length ? targets / settled.length : 0;
  return {
    open: marks.filter((m) => m.status === "open").length,
    settled: settled.length,
    targets,
    stopped,
    expired,
    hit,
    avg,
  };
}
