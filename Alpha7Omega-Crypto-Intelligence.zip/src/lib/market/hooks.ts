import { useQuery } from "@tanstack/react-query";
import type { BreakoutResponse, TapeResponse, UniverseResponse } from "./types";
import type { BtcBook, KlineResponse } from "./book";
import type { FlowResponse } from "./flow";
import type { DailyDigest, IntelResponse } from "./intel";
import type { NewsItem } from "./news";
import type { TerraResponse } from "./terra";

async function json<T>(url: string): Promise<T> {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${r.status} ${url}`);
  return (await r.json()) as T;
}

export function useUniverse() {
  return useQuery({
    queryKey: ["bubbles"],
    queryFn: () => json<UniverseResponse>("/api/bubbles"),
    refetchInterval: 25_000,
  });
}

export function useTape(enabled = true) {
  return useQuery({
    queryKey: ["tape"],
    queryFn: () => json<TapeResponse>("/api/tape"),
    refetchInterval: 12_000,
    enabled,
  });
}

export function useBreakouts(enabled = true) {
  return useQuery({
    queryKey: ["breakouts"],
    queryFn: () => json<BreakoutResponse>("/api/breakouts"),
    refetchInterval: 20_000,
    enabled,
  });
}

export function useBtcBook() {
  return useQuery({
    queryKey: ["btc-book"],
    queryFn: () => json<BtcBook>("/api/book"),
    refetchInterval: 6_000,
  });
}

export function useFlow() {
  return useQuery({
    queryKey: ["flow"],
    queryFn: () => json<FlowResponse>("/api/flow"),
    refetchInterval: 90_000,
  });
}

export function useKlines(symbol: string, tf: string) {
  return useQuery({
    queryKey: ["klines", symbol, tf],
    queryFn: () => json<KlineResponse>(`/api/klines?s=${encodeURIComponent(symbol)}&tf=${encodeURIComponent(tf)}`),
    refetchInterval: 30_000,
    enabled: !!symbol,
  });
}

export function useNews() {
  return useQuery({
    queryKey: ["news"],
    queryFn: () => json<{ items: NewsItem[]; sourceNotes: string[]; updatedAt: number }>("/api/news"),
    refetchInterval: 180_000,
  });
}

export function useDaily() {
  return useQuery({
    queryKey: ["daily"],
    queryFn: () => json<DailyDigest>("/api/daily"),
    refetchInterval: 60_000,
  });
}

export function useIntel(symbol: string) {
  return useQuery({
    queryKey: ["intel", symbol],
    queryFn: () => json<IntelResponse>(`/api/intel?symbol=${encodeURIComponent(symbol)}`),
    refetchInterval: 25_000,
    enabled: !!symbol,
  });
}

export function useTerra() {
  return useQuery({
    queryKey: ["terra"],
    queryFn: () => json<TerraResponse>("/api/terra"),
    refetchInterval: 30_000,
  });
}
