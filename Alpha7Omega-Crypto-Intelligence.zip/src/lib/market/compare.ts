/** Sunday 6 Sep 15:00 SAST book vs Wednesday 9 Sep 09:36 SAST board. */

export type Bucket =
  | "worked"
  | "stopped"
  | "held"
  | "waiting"
  | "late"
  | "flipped"
  | "new-green"
  | "quality"
  | "tradfi";

export type CompareRow = {
  id: string;
  sym: string;
  sunPx: number;
  sunChg: number;
  wedPx: number;
  wedChg: number;
  fromSun: number;
  bucket: Bucket;
  thenCall: string;
  nowCall: string;
  note: string;
};

export type PlanRow = {
  id: string;
  rank: number;
  title: string;
  call: string;
  names: string;
  size: string;
  why: string;
};

export type AlertKind = "fire" | "abort" | "cover" | "stalk" | "stand";

export type AlertRule = {
  id: string;
  sym: string;
  kind: AlertKind;
  level: number;
  dir: "below" | "above";
  label: string;
  why: string;
};

export const COMPARE_META = {
  from: { date: "2026-09-06", weekday: "Sunday", stamp: "15:00–15:03 SAST" },
  to: { date: "2026-09-09", weekday: "Wednesday", stamp: "09:32–09:50 SAST" },
  hours: 66,
  ingest: "Binance USDT-M ranking + USELESS ticket. Isolated. Not financial advice.",
  note: "Weekend book vs Wednesday London open. Percent is a liar — sort by quote volume first.",
};

export const COMPARE: CompareRow[] = [
  {
    id: "mars",
    sym: "MARSCOIN",
    sunPx: 0.19112,
    sunChg: -23.07,
    wedPx: 0.13678,
    wedChg: -7.25,
    fromSun: -28.4,
    bucket: "worked",
    thenCall: "trail-short",
    nowCall: "target hit · trail leftover",
    note: "High 0.270 → 0.137. T1 0.150 printed. Do not add. Cover on reclaim 0.155 then 0.186.",
  },
  {
    id: "useless",
    sym: "USELESS",
    sunPx: 0.22396,
    sunChg: -6.85,
    wedPx: 0.32577,
    wedChg: 40.88,
    fromSun: 45.5,
    bucket: "stopped",
    thenCall: "trail-short",
    nowCall: "STOPPED · re-fade on 0.320/0.312",
    note: "Sep 7 low 0.190 then squeeze to 0.337. GI stop 0.32 tagged. 09:50 1h stalled +1%, funding 8.4 bps. NEW ticket fires on loss of 0.320 then 0.312. Abort if 0.337 holds.",
  },
  {
    id: "xan",
    sym: "XAN",
    sunPx: 0.017063,
    sunChg: 22.35,
    wedPx: 0.01163,
    wedChg: -9.58,
    fromSun: -31.8,
    bucket: "worked",
    thenCall: "next-mars fade",
    nowCall: "fade worked · do not add",
    note: "Sunday +22% leftover is now −32% from stamp. Funding already negative. Late short is the inverse knife.",
  },
  {
    id: "flock",
    sym: "FLOCK",
    sunPx: 0.07382,
    sunChg: 35.52,
    wedPx: 0.06212,
    wedChg: 1.75,
    fromSun: -15.8,
    bucket: "worked",
    thenCall: "isolated fade",
    nowCall: "mean-reverted · skip",
    note: "+36% leftover gave the 16% back. Not a dump-to-zero. Stand down.",
  },
  {
    id: "bulla",
    sym: "BULLA",
    sunPx: 0.076604,
    sunChg: 20.06,
    wedPx: 0.077655,
    wedChg: -3.71,
    fromSun: 1.4,
    bucket: "waiting",
    thenCall: "fade on loss of 0.070",
    nowCall: "trigger not printed",
    note: "Flat from Sunday. 24h red off the 0.092 high. Funding still fat. Isolated dust only if 0.070 goes. Stop 0.093.",
  },
  {
    id: "ray",
    sym: "RAY",
    sunPx: 1.3542,
    sunChg: 61.2,
    wedPx: 1.3376,
    wedChg: 23.28,
    fromSun: -1.2,
    bucket: "held",
    thenCall: "do not fade as P&D",
    nowCall: "held $1.33 · funding now negative",
    note: "StonkFun/LaunchLab bid still on. Shorts paying. Any RAY short from $1.28 is at the stop. Peel, do not press.",
  },
  {
    id: "zec",
    sym: "ZEC",
    sunPx: 1169.46,
    sunChg: 15.32,
    wedPx: 1239.01,
    wedChg: 9.99,
    fromSun: 5.9,
    bucket: "quality",
    thenCall: "privacy leader · do not fade",
    nowCall: "higher high · hold / pullback buy",
    note: "$238M quote vol. This is the sleeve. Pullbacks that hold $1,000. Daily close < $980 kills it.",
  },
  {
    id: "collect",
    sym: "COLLECT",
    sunPx: 0.04376,
    sunChg: -45.43,
    wedPx: 0.02582,
    wedChg: -20.72,
    fromSun: -41.0,
    bucket: "late",
    thenCall: "do not short late",
    nowCall: "still dumping · still ignore",
    note: "0.044 → 0.026. The move is done. Late short is how the morning's win dies.",
  },
  {
    id: "hemi",
    sym: "HEMI",
    sunPx: 0.011273,
    sunChg: -18.12,
    wedPx: 0.007575,
    wedChg: -10.04,
    fromSun: -32.8,
    bucket: "late",
    thenCall: "do not short late",
    nowCall: "funding −0.11% · shorts crowded",
    note: "0.011 → 0.0076. Negative funding = the late shorts already live here. Do not add.",
  },
  {
    id: "ake",
    sym: "AKE",
    sunPx: 0.013583,
    sunChg: -29.37,
    wedPx: 0.016316,
    wedChg: -11.31,
    fromSun: 20.1,
    bucket: "late",
    thenCall: "do not short late",
    nowCall: "bounced off Sunday low · still ignore",
    note: "$23M vol on the red. Funding −0.17%. Crowded short, not a fresh idea.",
  },
  {
    id: "soph",
    sym: "SOPH",
    sunPx: 0.00418,
    sunChg: -11.65,
    wedPx: 0.005405,
    wedChg: -48.3,
    fromSun: 29.3,
    bucket: "late",
    thenCall: "loser tape",
    nowCall: "pumped then −48% · do not short the corpse",
    note: "Price is UP from Sunday and the 24h is −48%. That is a spike-and-crash. $42M vol already printed. Bounce +25% from 0.0054 is the next short, not this print.",
  },
  {
    id: "form",
    sym: "FORM",
    sunPx: 0.2655,
    sunChg: -14.55,
    wedPx: 0.3075,
    wedChg: -16.62,
    fromSun: 15.8,
    bucket: "late",
    thenCall: "do not short late",
    nowCall: "still ignore",
    note: "Bounced then dumped from a higher high. Same rule as Sunday.",
  },
  {
    id: "hajimi",
    sym: "HAJIMI",
    sunPx: 0.06108,
    sunChg: -12.34,
    wedPx: 0.04219,
    wedChg: -11.74,
    fromSun: -30.9,
    bucket: "late",
    thenCall: "loser tape",
    nowCall: "continuing · do not add",
    note: "Chinese meme still leaking. Residual, not a new short.",
  },
  {
    id: "dood",
    sym: "DOOD",
    sunPx: 0.00163,
    sunChg: 14.39,
    wedPx: 0.001762,
    wedChg: 4.51,
    fromSun: 8.1,
    bucket: "waiting",
    thenCall: "next-mars still green",
    nowCall: "bid fading · skip",
    note: "Still green vs Sunday, 24h cooling. Not a fresh fade.",
  },
  {
    id: "epic",
    sym: "EPIC",
    sunPx: 0.4412,
    sunChg: 18.35,
    wedPx: 0.3952,
    wedChg: 6.93,
    fromSun: -10.4,
    bucket: "worked",
    thenCall: "do not long the 15m",
    nowCall: "gave 10% back · skip",
    note: "High-octane leftover did the mean-revert. Leave it.",
  },
  {
    id: "solv",
    sym: "SOLV",
    sunPx: 0.00363,
    sunChg: 11.32,
    wedPx: 0.004402,
    wedChg: -6.95,
    fromSun: 21.3,
    bucket: "flipped",
    thenCall: "do not long the 15m",
    nowCall: "spiked then 24h red",
    note: "Price still up from Sunday. 24h is the unwind of a higher spike. Not a new short.",
  },
  {
    id: "uai",
    sym: "UAI",
    sunPx: 0.5474,
    sunChg: 13.22,
    wedPx: 0.6717,
    wedChg: -6.92,
    fromSun: 22.7,
    bucket: "flipped",
    thenCall: "AI leak · not a P&D",
    nowCall: "price up, 24h red off a higher high",
    note: "Named AI. Do not fade as MARSCOIN. Funding still fat — wait, don't hero.",
  },
  {
    id: "uni",
    sym: "UNI",
    sunPx: 7.017,
    sunChg: 12.47,
    wedPx: 6.785,
    wedChg: -4.19,
    fromSun: -3.3,
    bucket: "quality",
    thenCall: "do not short as a meme",
    nowCall: "mean-revert · still quality",
    note: "$24M vol. This is DeFi beta, not a pool cliff.",
  },
  {
    id: "dot",
    sym: "DOT",
    sunPx: 0.9715,
    sunChg: 5.85,
    wedPx: 1.1735,
    wedChg: 10.32,
    fromSun: 20.8,
    bucket: "quality",
    thenCall: "L1 beta",
    nowCall: "extending · do not fade",
    note: "$49M vol. Real L1 bid with ATOM. Not a meme.",
  },
  {
    id: "atom",
    sym: "ATOM",
    sunPx: 1.65,
    sunChg: 0,
    wedPx: 1.861,
    wedChg: 12.65,
    fromSun: 12.8,
    bucket: "quality",
    thenCall: "off-board Sunday",
    nowCall: "L1 bid with DOT",
    note: "Cosmos beta on the same flow as DOT. Size as L1, not a cliff.",
  },
  {
    id: "render",
    sym: "RENDER",
    sunPx: 1.52,
    sunChg: 3.4,
    wedPx: 1.523,
    wedChg: 0.53,
    fromSun: 0.2,
    bucket: "waiting",
    thenCall: "stalk close > $1.55",
    nowCall: "still coiled",
    note: "AI equity perps (OPENAI, ANTHROPIC, CRWV, AMD, INTC, IREN) are leaking onto this board. RENDER is still the cleaner swing. Trigger unchanged.",
  },
  {
    id: "iost",
    sym: "IOST",
    sunPx: 0.000717,
    sunChg: 15.5,
    wedPx: 0.001163,
    wedChg: 19.64,
    fromSun: 62.2,
    bucket: "new-green",
    thenCall: "gainer leftover",
    nowCall: "still ripping from Sunday",
    note: "Old L1, violent extension. Do not chase. Isolated fade only on a red 1h, not market-short green.",
  },
  {
    id: "br",
    sym: "BR",
    sunPx: 0.24493,
    sunChg: -14.92,
    wedPx: 0.29993,
    wedChg: 17.12,
    fromSun: 22.5,
    bucket: "flipped",
    thenCall: "rank-loser",
    nowCall: "violent bounce · do not short the bounce",
    note: "Sunday −15% is Wednesday +17%. Shorting a dead-cat bounce is a different trade and a worse one.",
  },
  {
    id: "btr",
    sym: "BTR",
    sunPx: 0.0469,
    sunChg: -7.39,
    wedPx: 0.05324,
    wedChg: 11.17,
    fromSun: 13.5,
    bucket: "flipped",
    thenCall: "loser tape",
    nowCall: "bounce · skip",
    note: "Same DNA as BR. Don't short the repair.",
  },
  {
    id: "skr",
    sym: "SKR",
    sunPx: 0.020611,
    sunChg: -9.76,
    wedPx: 0.022508,
    wedChg: 5.32,
    fromSun: 9.2,
    bucket: "flipped",
    thenCall: "loser tape",
    nowCall: "bounce · skip",
    note: "Sunday −10% repairing. Not a fade.",
  },
  {
    id: "magma",
    sym: "MAGMA",
    sunPx: 0.24234,
    sunChg: 4.69,
    wedPx: 0.27025,
    wedChg: 14.33,
    fromSun: 11.5,
    bucket: "quality",
    thenCall: "beta bid",
    nowCall: "extending with L1s",
    note: "Named project on the 15:03 beta sheet, still bid. Not a 4-hour mint.",
  },
  {
    id: "near",
    sym: "NEAR",
    sunPx: 2.344,
    sunChg: 5.11,
    wedPx: 2.426,
    wedChg: 5.16,
    fromSun: 3.5,
    bucket: "quality",
    thenCall: "AI / L1 leak",
    nowCall: "holding",
    note: "Supports the RENDER stalk more than it supports longing leftover memes.",
  },
  {
    id: "chill",
    sym: "CHILLGUY",
    sunPx: 0.01485,
    sunChg: 12.11,
    wedPx: 0.013788,
    wedChg: -2.95,
    fromSun: -7.1,
    bucket: "worked",
    thenCall: "dead-cat · skip",
    nowCall: "off the board · skip",
    note: "Monthly corpse did what corpses do.",
  },
  {
    id: "apr",
    sym: "APR",
    sunPx: 0.2467,
    sunChg: 6.24,
    wedPx: 0.1809,
    wedChg: -4.74,
    fromSun: -26.7,
    bucket: "worked",
    thenCall: "beta bid",
    nowCall: "rolled over",
    note: "Sunday +6% is −27% from stamp. Don't pick it up.",
  },
  {
    id: "jct",
    sym: "JCT",
    sunPx: 0.001938,
    sunChg: 11.96,
    wedPx: 0.001798,
    wedChg: -3.39,
    fromSun: -7.2,
    bucket: "worked",
    thenCall: "do not long",
    nowCall: "faded",
    note: "High-octane 15:02 name did the 1h red.",
  },
  {
    id: "wld",
    sym: "WLD",
    sunPx: 0.4213,
    sunChg: 4.64,
    wedPx: 0.4564,
    wedChg: -4.04,
    fromSun: 8.3,
    bucket: "flipped",
    thenCall: "beta bid",
    nowCall: "price up, 24h red",
    note: "$34M vol. Named, not a cliff. Skip both sides.",
  },
  {
    id: "pendle",
    sym: "PENDLE",
    sunPx: 2.0697,
    sunChg: 5.86,
    wedPx: 2.1261,
    wedChg: -3.83,
    fromSun: 2.7,
    bucket: "held",
    thenCall: "DeFi beta",
    nowCall: "quiet roll",
    note: "Not a trade today.",
  },
];

export const NEW_PRINTS: CompareRow[] = [
  {
    id: "vvv",
    sym: "VVV",
    sunPx: 0,
    sunChg: 0,
    wedPx: 28.856,
    wedChg: 63.69,
    fromSun: 0,
    bucket: "quality",
    thenCall: "off-board",
    nowCall: "DO NOT SHORT as a meme",
    note: "Venice AI. ~$1.2B mcap, $100M ARR, emission cut + burn. $36M Gate vol, ~$180M combined OI. ATH extension. Same class as RAY — pullback risk, not a $900k-pool rug.",
  },
  {
    id: "ff",
    sym: "FF",
    sunPx: 0,
    sunChg: 0,
    wedPx: 0.14721,
    wedChg: 22.74,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "SHORT NOW isolated",
    note: "$15.5M vol, funding 0.052%. 09:50 1h stalled. Loss of 0.145 then 0.132. Stop 0.152. Isolated, 1/3 of MARS.",
  },
  {
    id: "niulai",
    sym: "牛来",
    sunPx: 0,
    sunChg: 0,
    wedPx: 0.10851,
    wedChg: 16.44,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "Chinese meme · WAIT",
    note: "$13M vol, tiny OI, funding already negative. Shorts are in. Do not chase a short into a crowded book.",
  },
  {
    id: "pons",
    sym: "PONS",
    sunPx: 0,
    sunChg: 0,
    wedPx: 0.8027,
    wedChg: 8.74,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "real volume · not a cliff",
    note: "$24M vol. Size as a named print, not MARSCOIN. No late hero fade.",
  },
  {
    id: "pie",
    sym: "PIEVERSE",
    sunPx: 0,
    sunChg: 0,
    wedPx: 1.3338,
    wedChg: 12.53,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "elevated funding · isolated",
    note: "Funding 0.045%. Thin vs VVV. Fade watch on 1h red only.",
  },
  {
    id: "kat",
    sym: "KAT",
    sunPx: 0,
    sunChg: 0,
    wedPx: 0.005452,
    wedChg: 14.68,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "smaller book · skip or dust",
    note: "$1.5M vol. Percent liar. Notional is the tell.",
  },
  {
    id: "truth",
    sym: "TRUTH",
    sunPx: 0,
    sunChg: 0,
    wedPx: 0.01388,
    wedChg: 12.03,
    fromSun: 0,
    bucket: "new-green",
    thenCall: "—",
    nowCall: "THIN TRAP",
    note: "~$99k Gate vol. A 12% print on dust. Do not touch.",
  },
  {
    id: "openai",
    sym: "OPENAI",
    sunPx: 0,
    sunChg: 0,
    wedPx: 1579.79,
    wedChg: 7.83,
    fromSun: 0,
    bucket: "tradfi",
    thenCall: "—",
    nowCall: "AI equity perp leakage",
    note: "$27M vol with ANTHROPIC +8.4%, CRWV +10.8%, AMD, INTC, IREN, HPE. Supports RENDER stalk. Does not support longing leftover memes.",
  },
];

export const PLAN: PlanRow[] = [
  {
    id: "1",
    rank: 1,
    title: "Short FF now",
    call: "SHORT NOW · ISOLATED",
    names: "FF 0.147 +23% · funding 0.052% · $15.5M vol",
    size: "Isolated. 1/3 of what MARS was. Never 38x.",
    why: "09:50 take at 0.147. Live pressed toward 0.152 abort. If in: no add, stop is 0.152. If not in: wait for loss of 0.145. Isolated, 1/3 of MARS. Never 38x.",
  },
  {
    id: "2",
    rank: 2,
    title: "USELESS re-fade on the trigger",
    call: "FIRE 0.320 / 0.312",
    names: "USELESS 0.323 +38% · 1h +1% stalled · funding 8.4 bps · high 0.337",
    size: "Isolated, HALF of Sunday. Not revenge, not 38x.",
    why: "Sunday short is stopped (0.190 → 0.337). This is a NEW window. Do not market-short 0.323. Fire on loss of 0.320 then 0.312 AVL. Abort if 0.337 holds on a closing basis.",
  },
  {
    id: "3",
    rank: 3,
    title: "Isolated IOST",
    call: "FADE · RED 15m",
    names: "IOST 0.00118 +23% · +65% from Sunday 0.000717",
    size: "Dust. Smaller than FF.",
    why: "Old L1, violent. Not SHORT HARD. Red 15m / loss of 0.00116. Stop 0.00125.",
  },
  {
    id: "4",
    rank: 4,
    title: "Do not short VVV / RAY / ATOM / ZEC",
    call: "NOT A P&D",
    names: "VVV (Venice) 28.32 +60% · RAY 1.33 +23% funding negative · ATOM +14% · ZEC 1242 +11% $2.59B vol",
    size: "No short. Peel leftover RAY. Hold ZEC > $1,000.",
    why: "Venice is $1.2B / $100M ARR. RAY LaunchLab buybacks. ATOM is L1 beta. ZEC is the privacy sleeve. Percent is a liar.",
  },
  {
    id: "5",
    rank: 5,
    title: "Do not short the already-dead",
    call: "IGNORE",
    names: "SOPH −44%, FORM −26% (accelerating), COLLECT −22%, CYS −17%, STAR −17%, AKE −13%, XAN −11%, HEMI −10%, GPRO −19%",
    size: "Zero.",
    why: "Move is done. SOPH pumped then crashed — price is UP from Sunday. FORM dumped another 9 points in two minutes. HEMI/AKE funding already deeply negative. Late short is the inverse knife.",
  },
  {
    id: "6",
    rank: 6,
    title: "Trail MARSCOIN leftover only",
    call: "HOLD TRAIL · DO NOT ADD",
    names: "MARSCOIN 0.137 · −28% from Sunday 0.191 · −49% from 0.270 high",
    size: "Trail. Peel into 0.12 air. No add.",
    why: "Thesis printed. T1 0.150 hit. Cover on reclaim 0.155, hard cover 0.186. Same machine, later in the move.",
  },
  {
    id: "7",
    rank: 7,
    title: "BULLA still waiting · skip 牛来 / TRUTH / KAT",
    call: "ARMED / SKIP DUST",
    names: "BULLA 0.078 trigger 0.070 · 牛来 +19% funding already negative · TRUTH $99k vol · KAT $1.5M",
    size: "BULLA isolated dust. Others zero.",
    why: "Sunday BULLA fade did not trigger. 牛来 shorts are in. TRUTH/KAT notional is the tell.",
  },
  {
    id: "8",
    rank: 8,
    title: "Quality longs — privacy + coiled AI",
    call: "HOLD / STALK",
    names: "ZEC 1242 +11% hold > $1,000 · RENDER close > $1.55 · DOT/ATOM L1 bid · RAIL/ZAMA off-board",
    size: "Swing, not perp-lotto. Smaller than a meme short.",
    why: "ZEC higher high on $2.59B vol with BTC +1%. OPENAI/ANTHROPIC/CRWV leaking tradfi AI onto this board. RENDER still coiled under $1.55. Do not fade ZEC like BULLA.",
  },
];

export const ALERTS: AlertRule[] = [
  {
    id: "useless-fade",
    sym: "USELESS",
    kind: "fire",
    level: 0.32,
    dir: "below",
    label: "USELESS loss of 0.320",
    why: "Opens the 09:50 re-fade. Next pocket 0.312 AVL then 0.280. Do not market-short 0.323.",
  },
  {
    id: "useless-avl",
    sym: "USELESS",
    kind: "fire",
    level: 0.312,
    dir: "below",
    label: "USELESS loss of 0.312 AVL",
    why: "Full re-fade in play. Next pocket 0.280. Half Sunday size.",
  },
  {
    id: "useless-abort",
    sym: "USELESS",
    kind: "abort",
    level: 0.337,
    dir: "above",
    label: "USELESS hold / reclaim 0.337",
    why: "Squeeze not done. Stand down any re-short.",
  },
  {
    id: "mars-peel",
    sym: "MARSCOIN",
    kind: "cover",
    level: 0.155,
    dir: "above",
    label: "MARSCOIN reclaim 0.155",
    why: "Peel the trail. Thesis late.",
  },
  {
    id: "mars-cover",
    sym: "MARSCOIN",
    kind: "abort",
    level: 0.186,
    dir: "above",
    label: "MARSCOIN reclaim 0.186",
    why: "Hard cover. Invalidation of leftover trail.",
  },
  {
    id: "bulla-fire",
    sym: "BULLA",
    kind: "fire",
    level: 0.07,
    dir: "below",
    label: "BULLA loss of 0.070",
    why: "Sunday fade finally in play. Isolated. Targets 0.054 / 0.035.",
  },
  {
    id: "bulla-abort",
    sym: "BULLA",
    kind: "abort",
    level: 0.093,
    dir: "above",
    label: "BULLA reclaim 0.093",
    why: "Squeeze extension. Abort.",
  },
  {
    id: "ray-stop",
    sym: "RAY",
    kind: "cover",
    level: 1.35,
    dir: "above",
    label: "RAY tag 1.35 GI stop",
    why: "Peel. Funding negative. Do not press.",
  },
  {
    id: "vvv-watch",
    sym: "VVV",
    kind: "stand",
    level: 25.96,
    dir: "below",
    label: "VVV back through 25.96 (08:10 BJ print)",
    why: "Pullback watch, still not a P&D short. Venice is a $1.2B AI name.",
  },
  {
    id: "render-long",
    sym: "RENDER",
    kind: "stalk",
    level: 1.55,
    dir: "above",
    label: "RENDER daily close > $1.55",
    why: "Fire the stalk. Stop $1.439. T1 $1.70. Invalidation daily close < $1.38.",
  },
  {
    id: "zec-kill",
    sym: "ZEC",
    kind: "abort",
    level: 980,
    dir: "below",
    label: "ZEC daily close < $980",
    why: "Kills the privacy swing. Pullback buys only if $1,000 holds.",
  },
  {
    id: "soph-bounce",
    sym: "SOPH",
    kind: "fire",
    level: 0.00675,
    dir: "above",
    label: "SOPH bounce +25% from 0.0054",
    why: "The next short is the bounce, not the −48% corpse. Isolated if it rips.",
  },
  {
    id: "ff-now",
    sym: "FF",
    kind: "fire",
    level: 0.145,
    dir: "below",
    label: "FF loss of 0.145",
    why: "09:50 SHORT NOW. Isolated. Next pocket 0.132. Stop 0.152.",
  },
  {
    id: "ff-fund",
    sym: "FF",
    kind: "fire",
    level: 0.132,
    dir: "below",
    label: "FF loss of 0.132",
    why: "Full isolated fade in play. 1/3 of MARS size.",
  },
  {
    id: "ff-abort",
    sym: "FF",
    kind: "abort",
    level: 0.152,
    dir: "above",
    label: "FF reclaim 0.152",
    why: "Above 09:50 high. Abort the isolated short.",
  },
  {
    id: "iost-fire",
    sym: "IOST",
    kind: "fire",
    level: 0.00116,
    dir: "below",
    label: "IOST loss of 0.00116",
    why: "Isolated dust fade. Stop 0.00125. Smaller than FF.",
  },
];

export function alertStatus(
  rule: AlertRule,
  last: number | null | undefined,
): "ARMED" | "FIRED" | "—" {
  if (last == null || !Number.isFinite(last)) return "—";
  if (rule.dir === "below") return last <= rule.level ? "FIRED" : "ARMED";
  return last >= rule.level ? "FIRED" : "ARMED";
}

export function bucketLabel(b: Bucket): string {
  switch (b) {
    case "worked":
      return "Worked";
    case "stopped":
      return "Stopped";
    case "held":
      return "Held";
    case "waiting":
      return "Waiting";
    case "late":
      return "Too late";
    case "flipped":
      return "Flipped";
    case "new-green":
      return "New green";
    case "quality":
      return "Quality";
    case "tradfi":
      return "Tradfi leak";
  }
}

export function bucketClass(b: Bucket): string {
  switch (b) {
    case "worked":
      return "text-up";
    case "stopped":
      return "text-down";
    case "held":
      return "text-wait";
    case "waiting":
      return "text-wait";
    case "late":
      return "text-muted";
    case "flipped":
      return "text-wait";
    case "new-green":
      return "text-fg";
    case "quality":
      return "text-up";
    case "tradfi":
      return "text-muted";
  }
}
