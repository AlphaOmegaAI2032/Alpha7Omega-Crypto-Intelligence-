import type { BreakoutHit, DexSnapshot, Kind, PerpSnapshot, ScoredMover, Verdict } from "./types";

function n(v: number | null | undefined): number {
  return typeof v === "number" && Number.isFinite(v) ? v : 0;
}

export function cliffRatio(oiUsd: number, dexLiq: number): number | null {
  if (dexLiq <= 0 || oiUsd <= 0) return null;
  return oiUsd / dexLiq;
}

export function poolPctFdv(liq: number, fdv: number | null): number | null {
  if (!fdv || fdv <= 0 || liq <= 0) return null;
  return (liq / fdv) * 100;
}

export function fromHighPct(last: number, high: number): number | null {
  if (!high || high <= 0 || !last) return null;
  return ((last - high) / high) * 100;
}

export function fdvCliff(liq: number, fdv: number | null): number | null {
  if (!fdv || fdv <= 0 || liq <= 0) return null;
  return fdv / liq;
}

function defaultInvalidation(kind: Kind, flags: string[], custom?: string): string {
  if (custom) return custom;
  if (kind === "tradfi") {
    return "Not a dump-to-zero. Chip / Korea / 2x ETF directional bet. Funding near zero.";
  }
  if (kind === "privacy") {
    return "Privacy-coin bid. Invalidation is BTC risk-off, not a DEX cliff.";
  }
  if (kind === "project") {
    return "Named project. Can correct 10–20%. Do not treat as USELESS / MARSCOIN.";
  }
  if (flags.includes("tax-proxy")) {
    return "Invalidation: DEX LP > $5M with tax actually buying the advertised vault on-chain, plus funding flipping negative.";
  }
  if (flags.includes("kol-bags")) {
    return "Invalidation: top KOL bags adding, not distributing, and main pool > $5M with funding flipping negative.";
  }
  return "Invalidation: clean break of session high on volume, or the main DEX pool 5× overnight with organic makers.";
}

export function scoreFade(opts: {
  symbol: string;
  kind: Kind;
  flags: string[];
  note: string;
  invalidation?: string;
  perp: PerpSnapshot | null;
  dex: DexSnapshot | null;
}): Omit<ScoredMover, "id" | "name" | "watchlist"> {
  const { symbol, kind, flags, note, perp, dex } = opts;
  const reasons: string[] = [];
  let score = 0;
  let verdict: Verdict = "NEUTRAL";
  const invalidation = defaultInvalidation(kind, flags, opts.invalidation);

  const chg = perp?.change24h ?? dex?.changeH24 ?? 0;
  const h1 = dex?.changeH1 ?? null;
  const m5 = dex?.changeM5 ?? null;
  const funding = perp?.funding ?? 0;
  const fundingPct = funding * 100;
  const liq = dex?.liquidityUsd ?? 0;
  const fdv = dex?.fdv ?? dex?.marketCap ?? null;
  const oi = perp?.oiUsd ?? 0;
  const volDex = dex?.volumeH24 ?? 0;
  const volPerp = perp?.volumeQuote ?? 0;
  const cliff = cliffRatio(oi, liq);
  const poolPct = poolPctFdv(liq, fdv);
  const offHigh = perp ? fromHighPct(perp.last, perp.high24h) : null;
  const buys = (dex?.buysH1 ?? 0) + (dex?.buysM5 ?? 0);
  const sells = (dex?.sellsH1 ?? 0) + (dex?.sellsM5 ?? 0);
  const sellPressure = sells > 0 && buys > 0 ? sells / Math.max(1, buys) : 0;

  if (kind === "tradfi") {
    reasons.push("Equity / leveraged ETF / chip name — directional, not a dump-to-zero meme");
    verdict = "AVOID";
    score = 12;
    return pack();
  }
  if (kind === "privacy") {
    reasons.push("Privacy-coin bid on a risk-on tape — different animal");
    verdict = "AVOID";
    score = 15;
    return pack();
  }
  if (kind === "project") {
    reasons.push("Named project (AI / app). Can correct, but not a P&D fade");
    verdict = "AVOID";
    score = 18;
    if (chg > 35) {
      reasons.push(`Extended +${chg.toFixed(0)}% — tactical mean-reversion only, small size`);
      score = 32;
      verdict = "WAIT";
    }
    return pack();
  }

  if (kind === "meme") {
    score += 18;
    reasons.push("Meme / no-product ticker");
  }

  if (flags.includes("tax-proxy") || flags.includes("blacklist")) {
    score += 14;
    reasons.push("Contract has owner levers (tax or blacklist)");
  }
  if (flags.includes("kol-bags") || flags.includes("scammer-dev") || flags.includes("no-community")) {
    score += 10;
    reasons.push("Concentrated / hostile holder set");
  }
  if (flags.includes("listing-pop")) {
    score += 8;
    reasons.push("Fresh CEX listing pop");
  }
  if (flags.includes("recycled-narrative")) {
    score += 6;
    reasons.push("Recycled narrative — prior cycle already dumped ~90%");
  }

  if (chg >= 50) {
    score += 22;
    reasons.push(`Parabolic +${chg.toFixed(0)}% / 24h`);
  } else if (chg >= 25) {
    score += 14;
    reasons.push(`Hot +${chg.toFixed(0)}% / 24h`);
  } else if (chg >= 12) {
    score += 6;
  }

  if (fundingPct >= 0.04) {
    score += 16;
    reasons.push(`Crowded longs paying ${fundingPct.toFixed(3)}% funding`);
  } else if (fundingPct >= 0.02) {
    score += 10;
    reasons.push(`Positive funding ${fundingPct.toFixed(3)}% — shorts get paid`);
  } else if (fundingPct > 0 && fundingPct < 0.01) {
    score += 2;
    reasons.push("Funding flattened — edge is weaker, now a directional short");
  }

  if (poolPct !== null && poolPct < 0.6) {
    score += 18;
    reasons.push(`DEX pool is ${poolPct.toFixed(2)}% of FDV — fake inventory`);
  } else if (poolPct !== null && poolPct < 1.5) {
    score += 10;
    reasons.push(`Thin pool ${poolPct.toFixed(2)}% of FDV`);
  }

  if (liq > 0 && liq < 1_000_000 && (fdv ?? 0) > 50_000_000) {
    score += 12;
    reasons.push(`$${fmt(liq)} DEX inventory under $${fmt(fdv ?? 0)} FDV`);
  }

  if (cliff && cliff > 10) {
    score += 12;
    reasons.push(`Perp OI is ${cliff.toFixed(0)}× DEX liquidity`);
  } else if (cliff && cliff > 4) {
    score += 6;
    reasons.push(`OI / pool ${cliff.toFixed(1)}×`);
  }

  if (volPerp > 0 && volDex > 0 && volPerp > volDex * 8) {
    score += 8;
    reasons.push("Perp volume dwarfs spot — sentiment contract, not a market");
  }

  const stillVertical = (h1 !== null && h1 >= 8) || (m5 !== null && m5 >= 4);
  const rolling = (h1 !== null && h1 <= -4) || (offHigh !== null && offHigh <= -6);
  const stalling = h1 !== null && Math.abs(h1) < 2 && (m5 === null || m5 <= 0);

  if (stillVertical) {
    score -= 18;
    reasons.push(
      `Still vertical (1h ${h1?.toFixed(1)}%). Shorting here is catching the squeeze — WAIT`,
    );
  } else if (rolling) {
    score += 14;
    reasons.push(
      `Already rolling over (1h ${h1?.toFixed(1) ?? "n/a"}%${offHigh !== null ? `, ${offHigh.toFixed(1)}% off high` : ""})`,
    );
  } else if (stalling && chg >= 20) {
    score += 8;
    reasons.push("First stall after a large print — distribution window");
  } else if (h1 !== null && h1 >= 3 && h1 < 8) {
    score -= 6;
    reasons.push("1h still green — squeeze risk, size down");
  }

  if (sellPressure >= 1.15) {
    score += 8;
    reasons.push("DEX sells > buys on the last hour");
  }

  score = Math.max(0, Math.min(100, score));

  if (kind !== "meme" && kind !== "unknown") {
    verdict = "AVOID";
  } else if (stillVertical && score >= 40) {
    verdict = "WAIT";
  } else if (score >= 72) {
    verdict = "SHORT_HARD";
  } else if (score >= 52) {
    verdict = "FADE";
  } else if (score >= 36) {
    verdict = "WAIT";
  } else {
    verdict = "NEUTRAL";
  }

  return pack();

  function pack() {
    return {
      symbol,
      kind,
      flags,
      note,
      verdict,
      score,
      reasons,
      invalidation,
      perp,
      dex,
      cliff,
      poolPctFdv: poolPct,
      fromHighPct: offHigh,
    };
  }
}

export function scoreBreakout(
  dex: DexSnapshot,
  source: BreakoutHit["source"],
  boost = 0,
): {
  verdict: Verdict;
  score: number;
  reasons: string[];
  fdvCliff: number | null;
} {
  const reasons: string[] = [];
  let score = 0;
  const liq = dex.liquidityUsd;
  const volH1 = dex.volumeH1;
  const volM5 = dex.volumeM5;
  const chgH1 = n(dex.changeH1);
  const chgM5 = n(dex.changeM5);
  const ageMs = dex.pairCreatedAt ? Date.now() - dex.pairCreatedAt : null;
  const ageH = ageMs ? ageMs / 3_600_000 : null;
  const buys = dex.buysH1 || dex.buysM5;
  const sells = dex.sellsH1 || dex.sellsM5;
  const buyRatio = buys + sells > 0 ? buys / (buys + sells) : 0.5;
  const volLiq = liq > 0 ? volH1 / liq : 0;
  const cliff = fdvCliff(liq, dex.fdv ?? dex.marketCap);

  if (liq >= 12_000 && liq <= 1_500_000) {
    score += 12;
  } else if (liq < 8_000) {
    reasons.push("Liquidity too thin — skip or micro size");
    return { verdict: "NEUTRAL", score: 8, reasons, fdvCliff: cliff };
  } else if (liq > 4_000_000) {
    reasons.push("Already large — not a first-print breakout");
    score += 4;
  }

  if (ageH !== null && ageH >= 0.08 && ageH <= 8) {
    score += 18;
    reasons.push(`Fresh pair ${ageH < 1 ? `${Math.round(ageH * 60)}m` : `${ageH.toFixed(1)}h`} old`);
  } else if (ageH !== null && ageH <= 36) {
    score += 8;
    reasons.push(`Pair age ${ageH.toFixed(0)}h`);
  } else if (ageH !== null && ageH > 90) {
    score -= 8;
  }

  if (volLiq >= 5) {
    score += 30;
    reasons.push(`1h volume is ${volLiq.toFixed(1)}× the pool`);
  } else if (volLiq >= 3) {
    score += 22;
    reasons.push(`1h volume is ${volLiq.toFixed(1)}× the pool`);
  } else if (volLiq >= 1) {
    score += 12;
    reasons.push(`1h volume ${volLiq.toFixed(1)}× pool`);
  } else if (volH1 > 25_000) {
    score += 6;
  }

  if (chgH1 >= 40) {
    score += 16;
    reasons.push(`+${chgH1.toFixed(0)}% / 1h`);
  } else if (chgH1 >= 15) {
    score += 10;
    reasons.push(`+${chgH1.toFixed(0)}% / 1h`);
  } else if (chgH1 >= 8) {
    score += 6;
  } else if (chgH1 < -20) {
    score -= 14;
    reasons.push("Already dumping on the 1h");
  }

  if (chgM5 >= 8) {
    score += 8;
    reasons.push(`Hot 5m +${chgM5.toFixed(1)}%`);
  }

  if (buyRatio >= 0.58) {
    score += 10;
    reasons.push(`Buy-side flow ${(buyRatio * 100).toFixed(0)}%`);
  } else if (buyRatio <= 0.42) {
    score -= 10;
    reasons.push("Sellers in control");
  }

  if (volM5 > 0 && volH1 > 0 && volM5 * 12 > volH1 * 1.4) {
    score += 8;
    reasons.push("Volume accelerating vs the last hour");
  }

  if (liq >= 20_000 && liq <= 400_000) {
    score += 8;
    reasons.push("Liquidity in the first-print sweet spot");
  }

  const fdv = dex.fdv ?? dex.marketCap ?? 0;
  if (fdv > 0 && fdv < 2_000_000) {
    score += 8;
    reasons.push("Sub-$2M FDV");
  }

  if (boost >= 50) {
    score += 8;
    reasons.push(`DexScreener boost ${boost}× — paid visibility, often distribution`);
  } else if (boost > 0) {
    score += 3;
    reasons.push(`Boosted ${boost}×`);
  }

  if (source === "pump" || source === "live") {
    score += 4;
    reasons.push("Pump.fun first-print tape");
  }
  if (source === "trending") score += 3;
  if (source === "new") score += 4;
  if (source === "cto") {
    score += 4;
    reasons.push("Community-takeover stamp — often a bag-distribution ad");
  }

  if (ageH !== null && ageH <= 1 && volM5 > liq * 0.5 && liq >= 8_000) {
    score += 16;
  }

  if (cliff && cliff > 80 && chgH1 < 0) {
    reasons.push(`FDV/pool ${cliff.toFixed(0)}× and 1h red — inventory cliff`);
  }

  score = Math.max(0, Math.min(100, score));

  let verdict: Verdict = "NEUTRAL";
  if (cliff && cliff > 80 && chgH1 < 0 && volH1 > 0) {
    verdict = "SHORT_HARD";
  } else if (cliff && cliff > 40 && chgH1 < 3 && volLiq > 1) {
    verdict = "FADE";
  } else if (chgH1 > 25 && liq < 15_000) {
    verdict = "TRAP";
    reasons.push("Thin trap — huge % on a toy pool. Cannot exit size.");
  } else if (ageH !== null && ageH <= 1 && volM5 > liq * 0.5 && liq >= 8_000) {
    verdict = "BREAKOUT";
    reasons.push("NEW HEAT — first hour, 5m vol already half the pool");
  } else if (volLiq > 4 && chgH1 > 8 && liq >= 20_000 && fdv < 8_000_000 && (ageH === null || ageH <= 36)) {
    verdict = "BREAKOUT";
  } else if (score >= 62) {
    verdict = "BREAKOUT";
  } else if (score >= 40) {
    verdict = "WAIT";
  }

  if (!reasons.length) reasons.push("No clear expansion yet");
  return { verdict, score, reasons, fdvCliff: cliff };
}

function fmt(v: number): string {
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(1)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(0)}k`;
  return v.toFixed(0);
}
