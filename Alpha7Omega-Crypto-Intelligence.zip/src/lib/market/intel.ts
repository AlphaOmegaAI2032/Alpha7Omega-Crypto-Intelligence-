import { dexByToken, fetchTape } from "./fetchers";
import { holdersFor } from "./holders";
import { findKnown, KNOWN } from "./known";
import { fetchUniverse } from "./universe";
import type { HolderProfile } from "./types";

const UA = "Alpha7Omega-CryptoIntelligence/2.0";
const GT = "https://api.geckoterminal.com/api/v2";
const BSC_RPC = "https://bsc-dataseed.binance.org/";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn().then((value) => {
    cache.set(key, { at: Date.now(), value });
    return value;
  });
}

async function getJson<T>(url: string, timeoutMs = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

export type TaxBrief = {
  symbol: string;
  name: string;
  contract: string | null;
  chain: string;
  pattern: string;
  buyTax: string;
  sellTax: string;
  proxy: boolean;
  scannerLie: string;
  bullets: string[];
  perpGap: string;
  invalidation: string;
};

export type WhaleWallet = {
  label: string;
  address: string;
  tokens: number | null;
  lastKnown: number | null;
  delta: number | null;
  usd: number | null;
  pctSupply: number | null;
  status: "drip" | "silent" | "cex" | "lp" | "kol";
  verdict: "HOLD" | "DRIP" | "DUMPING" | "MIGRATING" | "WATCH";
  dest: string;
  note: string;
};

export type FlowPrint = {
  side: "buy" | "sell";
  usd: number;
  tokens: number;
  wallet: string;
  hash: string;
  at: number;
};

export type IntelResponse = {
  updatedAt: number;
  symbol: string;
  priceUsd: number | null;
  fdv: number | null;
  liq: number | null;
  tax: TaxBrief;
  whales: WhaleWallet[];
  holders: HolderProfile | null;
  flows: FlowPrint[];
  flowSummary: { buys: number; sells: number; buyUsd: number; sellUsd: number; window: string };
  topTakers: { wallet: string; sellUsd: number; buyUsd: number }[];
  dripLive: boolean;
  sourceNotes: string[];
};

export type DailyDigest = {
  generatedAt: number;
  headline: string;
  fng: number | null;
  fngLabel: string | null;
  btcDom: number;
  shorts: Array<{ symbol: string; score: number; chg24h: number | null; cliff: number | null; reason: string }>;
  heat: Array<{ symbol: string; chg24h: number | null; mcap: number; sector: string }>;
  whaleAlerts: string[];
  taxWatch: string[];
  thesis: string[];
  sourceNotes: string[];
};

const WATCH: Record<
  string,
  Array<{
    label: string;
    address: string;
    status: WhaleWallet["status"];
    lastKnown: number | null;
    note: string;
  }>
> = {
  MARSCOIN: [
    {
      label: "Confirmed drip seller",
      address: "0x6d8ac75d911bf7339fcf414ea79ae1edde18dabc",
      status: "drip",
      lastKnown: 9_660_000,
      note: "Path 13.48M → 10.44M → 9.97M → 9.66M. Cost ~$0.00133. Flag any out >100k.",
    },
    {
      label: "Silent 2.50% · Unipcs-sized",
      address: "0x0a6ebed0155edb4b21d92ad02897a626cd90119e",
      status: "silent",
      lastKnown: 24_960_000,
      note: "Lookonchain: Unipcs holds 24.95M MARS. This bag matches. First transfer is the next shoe.",
    },
    {
      label: "Silent 2.26%",
      address: "0xcc0c581613dfd4ace7c8686668427236f8bd5cc5",
      status: "silent",
      lastKnown: 22_570_000,
      note: "Flat through the listing pop. Flag first move to pair / Binance / Gate.",
    },
    {
      label: "Silent 1.70% round lot",
      address: "0xde52c75041371b5e08d8a50b82c63734850628c1",
      status: "silent",
      lastKnown: 17_000_000,
      note: "17.00M even. Allocation fingerprint.",
    },
    {
      label: "Binance Alpha router",
      address: "0x73d8bd54f7cf5fab43fe4ef40a62d390644946db",
      status: "cex",
      lastKnown: 184_600_000,
      note: "Was 169–193M pre-spot. Alpha→Spot unwrap. Withdrawals 15:00 SAST 5 Sep.",
    },
    {
      label: "Pancake MARS/USDT (4a4b)",
      address: "0x4a4bea953813c118c260be9a26b2321e57aa62e5",
      status: "lp",
      lastKnown: 1_970_000,
      note: "User-canonical USDT pool. Cliff = FDV / this liq.",
    },
    {
      label: "Pancake MARS/USDT (14ca)",
      address: "0x14ca9d552ed2cf0d5dfd1f89bc6793a464e2ed16",
      status: "lp",
      lastKnown: 1_510_000,
      note: "Second USDT pool. Higher 24h volume. Combined sink still sub-$2M.",
    },
  ],
  USELESS: [
    {
      label: "Unipcs / Bonk Guy bag",
      address: "",
      status: "kol",
      lastKnown: 15_900_000,
      note: "15.9M still intact per Lookonchain. Small airdrops ($500–$1k) are marketing, not the dump.",
    },
  ],
};

function whaleVerdict(
  status: WhaleWallet["status"],
  tokens: number | null,
  lastKnown: number | null,
): { verdict: WhaleWallet["verdict"]; dest: string } {
  if (tokens == null || lastKnown == null) return { verdict: "WATCH", dest: "—" };
  const delta = tokens - lastKnown;
  if (status === "lp") return { verdict: "WATCH", dest: "pool" };
  if (status === "cex") {
    if (delta < -5_000_000) return { verdict: "MIGRATING", dest: "Alpha → Spot / unknown" };
    return { verdict: "HOLD", dest: "CEX float" };
  }
  if (delta < -500_000) return { verdict: "DUMPING", dest: "clips / unknown" };
  if (delta < -100_000) return { verdict: "DRIP", dest: "clips" };
  return { verdict: "HOLD", dest: "—" };
}

function taxFor(symbol: string): TaxBrief {
  const k = findKnown(symbol);
  const flags = k?.flags || [];
  if (flags.includes("tax-proxy") || symbol.toUpperCase() === "MARSCOIN") {
    return {
      symbol: k?.symbol || symbol,
      name: "FlapTaxTokenV3 (upgradeable proxy)",
      contract: k?.address || null,
      chain: k?.chain || "bsc",
      pattern: "FlapTaxTokenV3",
      buyTax: "Marketing copy 3% — live setting can be 0%",
      sellTax: "Marketing copy 3% into an SPCXB vault — owner-set",
      proxy: true,
      scannerLie:
        "Some scanners print 0% tax. That is a setting, not a guarantee. Owner can turn fees back on through the proxy.",
      bullets: [
        "This is a tax-token factory contract, not a vanilla BEP-20. Fees are a lever.",
        "Copy: 3% buy + 3% sell routed into a ‘SPCXB vault’ (tokenized SpaceX story). Rewards require ≥10k tokens.",
        "The tax IS the product. When DEX volume dies, the yield dies, and holders become sellers. Already did ~400x then ~90% before this futures listing.",
        "This BSC ticker is not the 2014 Marscoin PoW chain (USPTO trademark). It glued ‘Elon said MarsCoin’ onto a Flap launch.",
        "Upgradeable proxy = admin can change implementation. Rug lever even if fees are off today.",
      ],
      perpGap:
        "Perps do not pay the tax. Spot sells on Pancake do. When CEX longs unwind, makers hedge into an $865k-class pool that also takes a cut — waterfall, not a correction.",
      invalidation: k?.invalidation || "LP > $5M and tax actually buying visible SPCXB on-chain, funding flipping negative.",
    };
  }
  if (flags.includes("blacklist")) {
    return {
      symbol: k?.symbol || symbol,
      name: "CTO token with blacklist",
      contract: k?.address || null,
      chain: k?.chain || "bsc",
      pattern: "Blacklist / owner brick",
      buyTax: "Factory default — treat as variable",
      sellTax: "Factory default — treat as variable",
      proxy: false,
      scannerLie: "A ‘0% tax’ read does not mean you can exit. Owner can brick wallets via blacklist.",
      bullets: [
        "CTO tag on DexScreener: no community.",
        "Blacklist function is a confiscation switch. Do not size as if exits are guaranteed.",
        "CEX premium vs a thin WBNB pool is inventory fiction.",
      ],
      perpGap: "Short the perp. You cannot sell size on the DEX without eating the book and possibly a blacklist.",
      invalidation: k?.invalidation || "Main pool 5× overnight with organic makers.",
    };
  }
  if (symbol.toUpperCase() === "USELESS") {
    return {
      symbol: "USELESS",
      name: "SPL Token · mint/freeze revoked",
      contract: k?.address || "Dz9mQ9NzkBcCsuGPFJ3r1bS4wgqKMHBPiVuniW8Mbonk",
      chain: "solana",
      pattern: "Classic SPL — no Token-2022 tax",
      buyTax: "None on mint",
      sellTax: "None on mint",
      proxy: false,
      scannerLie:
        "Metadata is clean. That is not a bull case. Dump risk is the 15.9M Unipcs bag and perps, not an admin key.",
      bullets: [
        "Mint authority null. Freeze authority null. Metadata immutable. Highest-trust contract config for a meme.",
        "Launchpad LetsBONK.fun → Raydium, first mint 10 May 2025. Reject any CA that does not end in …Mbonk.",
        "Lookalike site useless-coin.vercel.app prints HdnLwx7…pump — different token.",
        "LP is not the mint. A $4.7–4.9M Raydium pool is still thin vs $250M FDV and vs 15.9M KOL inventory.",
        "Unipcs is still shilling and airdropping $500–$1k clips. That is marketing, not distribution of the 15.9M.",
      ],
      perpGap:
        "Cannot rug you with an admin function. Can still unwind when the 15.9M hits Orca/Jupiter or a CEX. Do not short that flow until the bag moves.",
      invalidation: k?.invalidation || "Unipcs 15.9M sending to pool or CEX.",
    };
  }
  return {
    symbol: k?.symbol || symbol,
    name: k?.kind === "meme" ? "Meme / no-tax or unknown tax" : "Standard token",
    contract: k?.address || null,
    chain: k?.chain || "unknown",
    pattern: flags.includes("cto") ? "CTO meme" : "Vanilla or unknown",
    buyTax: "None advertised",
    sellTax: "None advertised",
    proxy: false,
    scannerLie: "Still check freeze/mint authority and owner. Clean tax does not mean clean inventory.",
    bullets: k?.note ? [k.note] : ["No tax factory flagged. Concentration and pool depth still set the tape."],
    perpGap: "Same CLIFF mechanic if OI >> DEX pool: the perp is a sentiment contract, the pool is the inventory.",
    invalidation: k?.invalidation || "Pool 5× with organic flow.",
  };
}

async function bscBalance(token: string, wallet: string): Promise<number | null> {
  const data = `0x70a08231${wallet.replace(/^0x/, "").toLowerCase().padStart(64, "0")}`;
  try {
    const res = await fetch(BSC_RPC, {
      method: "POST",
      headers: { "Content-Type": "application/json", "User-Agent": UA },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_call",
        params: [{ to: token, data }, "latest"],
      }),
    });
    const j = (await res.json()) as { result?: string };
    if (!j.result || j.result === "0x") return null;
    return Number(BigInt(j.result)) / 1e18;
  } catch {
    return null;
  }
}

type GtTrade = {
  attributes?: {
    kind?: string;
    volume_in_usd?: string;
    from_token_amount?: string;
    to_token_amount?: string;
    tx_from_address?: string;
    tx_hash?: string;
    block_timestamp?: string;
    from_token_address?: string;
  };
};

type GtToken = {
  data?: { attributes?: { price_usd?: string; fdv_usd?: string; market_cap_usd?: string; total_reserve_in_usd?: string } };
};

export async function fetchIntel(symbolRaw = "MARSCOIN"): Promise<IntelResponse> {
  return cached(`intel2:${symbolRaw.toUpperCase()}`, 20_000, async () => {
    const symbol = symbolRaw.toUpperCase() === "4USDT" ? "4" : symbolRaw;
    const known = findKnown(symbol) || KNOWN.find((k) => k.symbol.toUpperCase() === symbol.toUpperCase());
    const notes: string[] = [];
    const tax = taxFor(known?.symbol || symbol);
    const holders = holdersFor(known?.symbol || symbol);
    const pair = known?.pair;
    const chain = known?.chain === "solana" ? "solana" : known?.chain === "bsc" ? "bsc" : null;
    const priceHint: { price: number | null; fdv: number | null; liq: number | null } = {
      price: null,
      fdv: null,
      liq: null,
    };

    const trades: FlowPrint[] = [];
    const pairsToHit = [pair, ...(symbol.toUpperCase() === "MARSCOIN"
      ? ["0x4a4bea953813c118c260be9a26b2321e57aa62e5", "0x14ca9d552eD2CF0D5dFD1f89Bc6793a464e2ed16"]
      : [])].filter((p, i, a): p is string => !!p && a.indexOf(p) === i);
    if (pairsToHit.length && chain) {
      try {
        const tokP = known?.address
          ? getJson<GtToken>(`${GT}/networks/${chain}/tokens/${known.address.toLowerCase()}`)
          : Promise.resolve(null);
        const tradePs = pairsToHit.map((p) =>
          getJson<{ data?: GtTrade[] }>(`${GT}/networks/${chain}/pools/${p}/trades`).catch(() => ({ data: [] })),
        );
        const [tok, ...tradeSets] = await Promise.all([tokP, ...tradePs]);
        for (const gt of tradeSets) {
          const rows = gt.data || [];
          notes.push(`GeckoTerminal ${rows.length} pool prints`);
          for (const row of rows) {
            const a = row.attributes || {};
            const side = a.kind === "buy" ? "buy" : "sell";
            const usd = num(a.volume_in_usd);
            const tokens = side === "sell" ? num(a.from_token_amount) : num(a.to_token_amount);
            const at = a.block_timestamp ? Date.parse(a.block_timestamp) : Date.now();
            trades.push({
              side,
              usd,
              tokens,
              wallet: a.tx_from_address || "",
              hash: a.tx_hash || "",
              at,
            });
          }
        }
        if (tok?.data?.attributes) {
          priceHint.price = num(tok.data.attributes.price_usd) || null;
          priceHint.fdv = num(tok.data.attributes.fdv_usd || tok.data.attributes.market_cap_usd) || null;
          priceHint.liq = num(tok.data.attributes.total_reserve_in_usd) || null;
        }
      } catch (e) {
        notes.push(`Trades delayed: ${e instanceof Error ? e.message : "gt"}`);
      }
    } else {
      notes.push("No pair mapped — mechanics only");
    }

    if (!priceHint.price && known?.address) {
      try {
        const snap = await dexByToken(known.address, known.symbol);
        if (snap) {
          priceHint.price = snap.priceUsd;
          priceHint.fdv = snap.fdv ?? snap.marketCap;
          priceHint.liq = snap.liquidityUsd || null;
          notes.push("DexScreener mark");
        }
      } catch {
        notes.push("Mark delayed");
      }
    }

    const buys = trades.filter((t) => t.side === "buy");
    const sells = trades.filter((t) => t.side === "sell");
    const buyUsd = buys.reduce((s, t) => s + t.usd, 0);
    const sellUsd = sells.reduce((s, t) => s + t.usd, 0);

    const byWallet = new Map<string, { sellUsd: number; buyUsd: number }>();
    for (const t of trades) {
      const w = t.wallet.toLowerCase();
      if (!w) continue;
      const cur = byWallet.get(w) || { sellUsd: 0, buyUsd: 0 };
      if (t.side === "sell") cur.sellUsd += t.usd;
      else cur.buyUsd += t.usd;
      byWallet.set(w, cur);
    }
    const topTakers = [...byWallet.entries()]
      .map(([wallet, v]) => ({ wallet, ...v }))
      .sort((a, b) => b.sellUsd - a.sellUsd)
      .slice(0, 8);

    const watch = WATCH[known?.symbol || symbol] || WATCH[symbol.toUpperCase()] || [];
    const whales: WhaleWallet[] = [];
    for (const w of watch) {
      let tokens: number | null = null;
      if (w.address && known?.chain === "bsc" && known.address) {
        tokens = await bscBalance(known.address, w.address);
      }
      const usd = tokens != null && priceHint.price ? tokens * priceHint.price : null;
      const pctSupply = tokens != null ? (tokens / 1_000_000_000) * 100 : null;
      const { verdict, dest } = whaleVerdict(w.status, tokens, w.lastKnown);
      const delta = tokens != null && w.lastKnown != null ? tokens - w.lastKnown : null;
      whales.push({
        label: w.label,
        address: w.address,
        tokens,
        lastKnown: w.lastKnown,
        delta,
        usd,
        pctSupply,
        status: w.status,
        verdict,
        dest,
        note: w.note,
      });
    }

    const dripAddr = watch.find((w) => w.status === "drip")?.address.toLowerCase();
    const dripLive = dripAddr ? trades.some((t) => t.side === "sell" && t.wallet.toLowerCase() === dripAddr) : false;
    if (dripLive) notes.push("Drip seller printed in this trade window");

    const large = trades
      .filter((t) => t.usd >= 2000)
      .sort((a, b) => b.usd - a.usd)
      .slice(0, 18);

    return {
      updatedAt: Date.now(),
      symbol: known?.symbol || symbol,
      priceUsd: priceHint.price,
      fdv: priceHint.fdv,
      liq: priceHint.liq,
      tax,
      whales,
      holders,
      flows: large,
      flowSummary: {
        buys: buys.length,
        sells: sells.length,
        buyUsd,
        sellUsd,
        window: "last ~300 pool prints",
      },
      topTakers,
      dripLive,
      sourceNotes: notes,
    };
  });
}

export async function fetchDaily(): Promise<DailyDigest> {
  return cached("daily", 25_000, async () => {
    const [uni, tape, intel] = await Promise.all([
      fetchUniverse(),
      fetchTape(),
      fetchIntel("MARSCOIN"),
    ]);
    const shorts = tape.movers
      .filter((m) => m.verdict === "SHORT_HARD" || m.verdict === "FADE")
      .slice(0, 8)
      .map((m) => ({
        symbol: m.symbol,
        score: m.score,
        chg24h: m.perp?.change24h ?? m.dex?.changeH24 ?? null,
        cliff: m.cliff,
        reason: m.reasons[0] || m.note,
      }));
    const heat = [...uni.coins]
      .filter((c) => c.sector !== "stable")
      .sort((a, b) => Math.abs(b.chg24h ?? 0) - Math.abs(a.chg24h ?? 0))
      .slice(0, 8)
      .map((c) => ({
        symbol: c.symbol,
        chg24h: c.chg24h,
        mcap: c.mcap,
        sector: c.sector,
      }));
    const whaleAlerts: string[] = [];
    if (intel.dripLive) whaleAlerts.push("MARSCOIN drip seller is still hitting the Pancake pool in the live window.");
    for (const w of intel.whales) {
      const bag = w.tokens != null ? `${(w.tokens / 1_000_000).toFixed(2)}M` : "n/a";
      const dlt =
        w.delta != null
          ? ` Δ ${(w.delta / 1_000_000).toFixed(2)}M vs last known`
          : "";
      whaleAlerts.push(`${w.verdict} · ${w.label} ${bag}${dlt}${w.dest !== "—" ? ` → ${w.dest}` : ""}.`);
    }
    const taxWatch = [
      `${intel.tax.pattern}: ${intel.tax.scannerLie}`,
      intel.tax.perpGap,
    ];
    const hard = shorts[0];
    const headline = hard
      ? `${hard.symbol} still leads the fade desk${hard.cliff ? ` · cliff ${hard.cliff.toFixed(0)}×` : ""}`
      : "No hard fade cleared the filter — watch inventory, not the green print.";
    const thesis = [
      "Size the short off OI and funding, not the gainer tab.",
      "Isolated margin. The squeeze before the dump is the fee for being early.",
      "Boosts are paid visibility — often the distribution advertisement.",
    ];
    return {
      generatedAt: Date.now(),
      headline,
      fng: uni.pulse?.fng ?? null,
      fngLabel: uni.pulse?.fngLabel ?? null,
      btcDom: uni.pulse?.btcDom ?? 0,
      shorts,
      heat,
      whaleAlerts: whaleAlerts.length ? whaleAlerts : ["No live drip print in this window. Silent 2% bags remain the next shoe."],
      taxWatch,
      thesis,
      sourceNotes: [...(uni.sourceNotes || []), ...intel.sourceNotes],
    };
  });
}

export const INTEL_UNIVERSE = ["MARSCOIN", "USELESS", "龙虾", "4", "我踏马来了"];
