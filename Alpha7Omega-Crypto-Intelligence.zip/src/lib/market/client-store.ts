import { STORAGE } from "@/lib/brand";

export type WatchBias = "watch" | "long" | "short";

export type WatchItem = {
  symbol: string;
  bias: WatchBias;
  addedAt: number;
};

export type GiSide = "long" | "short";
export type GiStatus = "open" | "target" | "stopped" | "expired";

export type GiMark = {
  id: string;
  day: string;
  symbol: string;
  side: GiSide;
  entry: number;
  target: number;
  stop: number;
  status: GiStatus;
  pnl: number | null;
  note: string;
  openedAt: number;
  closedAt: number | null;
};

function read<T>(key: string, fallback: T, legacy?: string): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key) || (legacy ? localStorage.getItem(legacy) : null);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

const SEED_WATCH: Array<{ symbol: string; bias: WatchBias }> = [
  { symbol: "MARSCOIN", bias: "short" },
  { symbol: "USELESS", bias: "short" },
  { symbol: "FF", bias: "short" },
  { symbol: "IOST", bias: "short" },
  { symbol: "VVV", bias: "watch" },
  { symbol: "BULLA", bias: "short" },
  { symbol: "RAY", bias: "watch" },
  { symbol: "RENDER", bias: "long" },
  { symbol: "ZEC", bias: "long" },
];

const SEED_GI: GiMark[] = [
  {
    id: "seed:MARSCOIN:short:2026-09-04",
    day: "2026-09-04",
    symbol: "MARSCOIN",
    side: "short",
    entry: 0.201,
    target: 0.15,
    stop: 0.215,
    status: "open",
    pnl: 0,
    note: "SHORT HARD. Cliff ~220x. Drip seller 0x6d8a. Isolated. Hard stop above 0.215. Wed 09:36: T1 0.150 HIT @ 0.137. Trail leftover only.",
    openedAt: Date.parse("2026-09-04T20:10:00+02:00"),
    closedAt: null,
  },
  {
    id: "seed:USELESS:short:2026-09-04",
    day: "2026-09-04",
    symbol: "USELESS",
    side: "short",
    entry: 0.25,
    target: 0.18,
    stop: 0.32,
    status: "open",
    pnl: 0,
    note: "Fade, don't chase. Metadata pass. Unipcs 15.9M still sitting. Wait 1h roll. Wed 09:32: STOPPED — squeezed from 0.190 to 0.337. Do not revenge-short.",
    openedAt: Date.parse("2026-09-04T21:00:00+02:00"),
    closedAt: null,
  },
  {
    id: "seed:RAY:short:2026-09-06",
    day: "2026-09-06",
    symbol: "RAY",
    side: "short",
    entry: 1.276,
    target: 1.1,
    stop: 1.35,
    status: "open",
    pnl: 0,
    note: "Fade the extension off $1.44, not a P&D. Peel into $1.15 / $1.10. Do not press 38x. Wed 09:35: funding negative, GI stop 1.35 is here. PEEL.",
    openedAt: Date.parse("2026-09-06T03:27:00+02:00"),
    closedAt: null,
  },
  {
    id: "seed:BULLA:short:2026-09-06",
    day: "2026-09-06",
    symbol: "BULLA",
    side: "short",
    entry: 0.07,
    target: 0.054,
    stop: 0.093,
    status: "open",
    pnl: 0,
    note: "$1 was the level, not the clock. Fade on loss of 0.070. Isolated.",
    openedAt: Date.parse("2026-09-06T15:02:00+02:00"),
    closedAt: null,
  },
  {
    id: "seed:RENDER:long:2026-09-06",
    day: "2026-09-06",
    symbol: "RENDER",
    side: "long",
    entry: 1.55,
    target: 1.7,
    stop: 1.439,
    status: "open",
    pnl: 0,
    note: "Stalk. Trigger daily close > $1.55. Invalidation daily close < $1.38.",
    openedAt: Date.parse("2026-09-06T15:03:00+02:00"),
    closedAt: null,
  },
];


export function loadPins(): string[] {
  return read<string[]>(STORAGE.pins, [], "alphab7bblez_pins");
}

export function savePins(pins: string[]) {
  write(STORAGE.pins, pins);
}

export function loadWatch(): WatchItem[] {
  const next = read<WatchItem[]>(STORAGE.watch, []);
  if (next.length) return next;
  const legacy = read<string[]>("alphab7bblez_watch", []);
  if (legacy.length) return legacy.map((symbol) => ({ symbol, bias: "watch" as const, addedAt: Date.now() }));
  const seeded = SEED_WATCH.map((w) => ({ ...w, addedAt: Date.now() }));
  write(STORAGE.watch, seeded);
  return seeded;
}

export function saveWatch(items: WatchItem[]) {
  write(STORAGE.watch, items);
}

export function loadGi(): GiMark[] {
  const existing = read<GiMark[]>(STORAGE.gi, []);
  if (!existing.length) {
    const seeded = SEED_GI.map((m) => ({ ...m }));
    write(STORAGE.gi, seeded);
    return seeded;
  }
  const have = new Set(existing.map((m) => m.id));
  const missing = SEED_GI.filter((m) => !have.has(m.id));
  if (!missing.length) return existing;
  const next = [...missing, ...existing];
  write(STORAGE.gi, next);
  return next;
}

export function saveGi(marks: GiMark[]) {
  write(STORAGE.gi, marks);
}

export function utcDay(ts = Date.now()) {
  return new Date(ts).toISOString().slice(0, 10);
}

export function markToMarket(mark: GiMark, last: number, now = Date.now()): GiMark {
  if (mark.status !== "open" || !last) return mark;
  const age = now - mark.openedAt;
  let status: GiStatus = "open";
  if (mark.side === "short") {
    if (last <= mark.target) status = "target";
    else if (last >= mark.stop) status = "stopped";
  } else {
    if (last >= mark.target) status = "target";
    else if (last <= mark.stop) status = "stopped";
  }
  if (status === "open" && age >= 24 * 3_600_000) status = "expired";
  if (status === "open") {
    const pnl = mark.side === "short" ? (mark.entry - last) / mark.entry : (last - mark.entry) / mark.entry;
    return { ...mark, pnl };
  }
  const exit =
    status === "target" ? mark.target : status === "stopped" ? mark.stop : last;
  const pnl = mark.side === "short" ? (mark.entry - exit) / mark.entry : (exit - mark.entry) / mark.entry;
  return { ...mark, status, pnl, closedAt: now };
}
