export type Sector =
  | "btc"
  | "l1"
  | "l2"
  | "defi"
  | "ai"
  | "meme"
  | "privacy"
  | "tradfi"
  | "stable"
  | "other";

export type Kind = "meme" | "project" | "tradfi" | "privacy" | "unknown";

export type Verdict =
  | "SHORT_HARD"
  | "FADE"
  | "WAIT"
  | "AVOID"
  | "BREAKOUT"
  | "TRAP"
  | "NEUTRAL";

export type Timeframe = "1h" | "24h" | "7d" | "30d" | "90d" | "1y";

export type SignalKind =
  | "CLIFF"
  | "CROWDED"
  | "EXPLODE"
  | "DIVERGE"
  | "RELATIVE"
  | "TRENDING"
  | "QUIET"
  | "NONE";

export type Weather = "risk-on" | "mixed" | "risk-off";

export type CategoryPulse = {
  id: string;
  name: string;
  change24: number;
  mcap: number;
};

export type KnownToken = {
  symbol: string;
  aliases?: string[];
  gate: string | null;
  binance?: string | null;
  chain: string;
  address: string | null;
  pair?: string | null;
  kind: Kind;
  flags: string[];
  note: string;
  invalidation?: string;
};

export type DexSnapshot = {
  chain: string;
  dex: string;
  pairAddress: string;
  tokenAddress: string;
  name: string;
  symbol: string;
  priceUsd: number | null;
  priceNative: number | null;
  changeM5: number | null;
  changeH1: number | null;
  changeH6: number | null;
  changeH24: number | null;
  volumeM5: number;
  volumeH1: number;
  volumeH6: number;
  volumeH24: number;
  liquidityUsd: number;
  fdv: number | null;
  marketCap: number | null;
  buysM5: number;
  sellsM5: number;
  buysH1: number;
  sellsH1: number;
  buysH24: number;
  sellsH24: number;
  pairCreatedAt: number | null;
  url: string;
  imageUrl: string | null;
};

export type PerpSnapshot = {
  venue: string;
  contract: string;
  last: number;
  mark: number;
  index: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volumeQuote: number;
  funding: number;
  oiUsd: number;
  trades?: number;
  nextFunding?: number | null;
};

export type ScoredMover = {
  id: string;
  symbol: string;
  name: string;
  kind: Kind;
  flags: string[];
  note: string;
  verdict: Verdict;
  score: number;
  reasons: string[];
  invalidation: string;
  perp: PerpSnapshot | null;
  dex: DexSnapshot | null;
  cliff: number | null;
  poolPctFdv: number | null;
  fromHighPct: number | null;
  watchlist: boolean;
};

export type BreakoutHit = {
  id: string;
  source: "pump" | "trending" | "boost" | "new" | "live" | "search" | "cto";
  symbol: string;
  name: string;
  chain: string;
  address: string;
  verdict: Verdict;
  score: number;
  reasons: string[];
  dex: DexSnapshot | null;
  createdAt: number | null;
  pumpMc: number | null;
  imageUrl: string | null;
  boost: number | null;
  fdvCliff: number | null;
};

export type TapeResponse = {
  updatedAt: number;
  movers: ScoredMover[];
  sourceNotes: string[];
};

export type BreakoutResponse = {
  updatedAt: number;
  hits: BreakoutHit[];
  sourceNotes: string[];
};

export type HolderSlice = {
  label: string;
  pct: number;
  tokens: string;
  note: string;
};

export type HolderProfile = {
  top100Pct: number;
  top10Pct: number;
  holders: number;
  inventoryToPool: string;
  dripSeller: string | null;
  slices: HolderSlice[];
};

export type BubbleCoin = {
  id: string;
  symbol: string;
  name: string;
  image: string | null;
  price: number;
  mcap: number;
  volume: number;
  rank: number | null;
  chg1h: number | null;
  chg24h: number | null;
  chg7d: number | null;
  chg30d: number | null;
  chg90d: number | null;
  chg1y: number | null;
  sector: Sector;
  kind: Kind;
  verdict: Verdict;
  score: number;
  reasons: string[];
  funding: number | null;
  oiUsd: number | null;
  dexLiq: number | null;
  cliff: number | null;
  poolPctFdv: number | null;
  fromHighPct: number | null;
  volMcap: number | null;
  flags: string[];
  note: string;
  dexUrl: string | null;
  holders: HolderProfile | null;
  trending?: boolean;
  turnover?: number | null;
  spark: number[] | null;
  athChg: number | null;
  volChg: number | null;
  tvl: number | null;
  hlOi: number | null;
  signal: SignalKind;
  heatScore: number;
  tags: string[];
  why: string;
};

export type MarketPulse = {
  totalMcap: number;
  btcDom: number;
  ethDom: number;
  volume24: number;
  marketChange24: number;
  fng: number | null;
  fngLabel: string | null;
  activeCoins: number;
  trending: string[];
  breadthPct: number;
  altseason: number | null;
  weather: Weather;
  mempoolSat: number | null;
  hashrateEh: number | null;
  addrActive: number | null;
  diffProgress: number | null;
  totalTvl: number | null;
  derivVol: number | null;
  btcDomChg: number | null;
  defiMcap: number | null;
  deskNote: string;
  categories: CategoryPulse[];
};

export type UniverseResponse = {
  updatedAt: number;
  coins: BubbleCoin[];
  pulse: MarketPulse | null;
  sourceNotes: string[];
};
