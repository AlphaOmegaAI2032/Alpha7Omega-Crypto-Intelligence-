import type { BubbleCoin, Kind, ScoredMover, Sector, Verdict } from "./types";

export const DH_VERSION = "DH-1.4";

export type DhWindow = "break" | "fade" | "climax" | "heat" | "none";
export type DhSide = "long" | "short" | "none";

export type DeepHeatRow = {
  symbol: string;
  name: string;
  sector: Sector;
  kind: Kind;
  price: number;
  chg24: number;
  chg1h: number | null;
  volume: number;
  volX: number;
  funding: number | null;
  fromHigh: number | null;
  cliff: number | null;
  poolPctFdv: number | null;
  dh: number;
  longScore: number;
  fadeScore: number;
  side: DhSide;
  window: DhWindow;
  thesis: string;
  verdict: Verdict;
  reasons: string[];
};

function median(xs: number[]): number {
  const s = xs.filter((n) => n > 0).sort((a, b) => a - b);
  if (!s.length) return 1;
  return s[Math.floor(s.length / 2)] || 1;
}

function clamp(n: number, a = 0, b = 100) {
  return Math.max(a, Math.min(b, n));
}

export function scoreDeepHeat(coins: BubbleCoin[], movers: ScoredMover[] = []): DeepHeatRow[] {
  const bySym = new Map<string, ScoredMover>();
  for (const m of movers) bySym.set(m.symbol.toUpperCase(), m);
  const med = median(coins.map((c) => c.volume));

  const rows: DeepHeatRow[] = [];
  for (const c of coins) {
    if (c.sector === "stable") continue;
    const chg24 = c.chg24h ?? 0;
    if (Math.abs(chg24) < 2.5 && (c.heatScore || 0) < 20) continue;
    const m = bySym.get(c.symbol.toUpperCase());
    const price = m?.perp?.last || m?.dex?.priceUsd || c.price;
    const funding = m?.perp?.funding ?? c.funding;
    const fromHigh = m?.fromHighPct ?? c.fromHighPct;
    const cliff = m?.cliff ?? c.cliff;
    const volX = med > 0 ? c.volume / med : 1;
    const h1 = c.chg1h ?? m?.dex?.changeH1 ?? null;
    const glued = fromHigh != null && fromHigh > -1.5;
    const stillVertical = h1 != null && h1 >= 8;

    const breakWin = chg24 >= 8 && chg24 <= 22 && volX >= 0.8 && !glued;
    const superGain = chg24 >= 40;
    const fadeWin = chg24 >= 28 || (glued && chg24 >= 12 && volX >= 1.1) || (funding != null && funding > 0.0005);
    const climax = glued && chg24 >= 12;

    let longScore = 0;
    if (breakWin) longScore += 42;
    else if (chg24 >= 6 && chg24 < 8 && volX >= 1) longScore += 18;
    longScore += Math.min(22, Math.log10(Math.max(volX, 0.2)) * 18 + 8);
    if ((c.volMcap ?? 0) > 0.4 || volX >= 4) longScore += 12;
    if (!fadeWin && !climax) longScore += 14;
    if (c.trending || c.sector === "meme") longScore += 8;
    if (stillVertical && chg24 > 22) longScore -= 20;
    if ((cliff ?? 0) > 8) longScore -= 16;
    if (c.kind === "tradfi") longScore -= 30;

    let fadeScore = 0;
    if (fadeWin) fadeScore += 50;
    if (chg24 >= 18) fadeScore += Math.min(22, (chg24 - 18) * 0.7);
    if (funding != null && funding > 0.0002) fadeScore += Math.min(16, funding * 20_000);
    if (climax) fadeScore += 14;
    if (superGain) fadeScore += 18;
    if ((cliff ?? 0) > 4) fadeScore += Math.min(14, (cliff ?? 0) * 1.2);
    if ((c.poolPctFdv ?? 100) < 1) fadeScore += 10;
    if (c.kind === "tradfi" || c.kind === "privacy") fadeScore -= 24;
    if (c.kind === "project") fadeScore -= 16;
    if (stillVertical) fadeScore -= 18;
    if (m?.verdict === "SHORT_HARD") fadeScore += 12;
    else if (m?.verdict === "FADE") fadeScore += 6;

    longScore = clamp(longScore);
    fadeScore = clamp(fadeScore);

    let window: DhWindow = "none";
    let side: DhSide = "none";
    let thesis = "Heat without a window.";
    if (breakWin && longScore >= fadeScore) {
      window = "break";
      side = "long";
      thesis = `Break window ${chg24.toFixed(1)}% · vol ${volX.toFixed(1)}× median · ${c.sector === "meme" ? "Meme season" : "Unclassified"}.`;
    } else if (climax && fadeScore >= 48) {
      window = "climax";
      side = "short";
      thesis = `Climax print ${chg24.toFixed(1)}% at the high of day — 24h fade.`;
    } else if (superGain || (fadeWin && fadeScore >= 55 && !stillVertical)) {
      window = "fade";
      side = "short";
      thesis = `Parabolic ${chg24.toFixed(1)}%${funding && funding > 0.0002 ? " with stretched funding" : ""}. Mean-revert short.`;
    } else if (fadeScore >= 40 || longScore >= 40) {
      window = "heat";
      side = fadeScore >= longScore ? "short" : "long";
      thesis = `Heat ${Math.round(Math.max(fadeScore, longScore))} / fade ${Math.round(fadeScore)} — no edge until a window opens.`;
    }

    const dh = Math.round(Math.max(longScore, fadeScore));
    if (dh < 32 && window === "none") continue;

    rows.push({
      symbol: c.symbol,
      name: c.name,
      sector: c.sector,
      kind: c.kind,
      price,
      chg24,
      chg1h: h1,
      volume: c.volume,
      volX,
      funding,
      fromHigh,
      cliff,
      poolPctFdv: m?.poolPctFdv ?? c.poolPctFdv,
      dh,
      longScore: Math.round(longScore),
      fadeScore: Math.round(fadeScore),
      side,
      window,
      thesis,
      verdict: m?.verdict ?? c.verdict,
      reasons: m?.reasons?.length ? m.reasons : c.reasons,
    });
  }

  rows.sort((a, b) => b.dh - a.dh || Math.abs(b.chg24) - Math.abs(a.chg24));
  return rows;
}

export function dhLongs(rows: DeepHeatRow[], n = 6) {
  return rows.filter((r) => r.side === "long" && (r.window === "break" || r.dh >= 70)).slice(0, n);
}

export function dhFades(rows: DeepHeatRow[], n = 6) {
  return rows
    .filter((r) => r.side === "short" && (r.window === "fade" || r.window === "climax" || r.dh >= 48))
    .slice(0, n);
}

export function rotationBuckets(rows: DeepHeatRow[]) {
  const by: Record<string, { n: number; s: number }> = {};
  for (const r of rows) {
    if (r.chg24 < 8) continue;
    const k = r.sector;
    const g = by[k] || { n: 0, s: 0 };
    g.n += 1;
    g.s += r.chg24;
    by[k] = g;
  }
  return Object.entries(by)
    .map(([k, v]) => ({ sector: k, n: v.n, avg: v.s / v.n }))
    .sort((a, b) => b.avg - a.avg);
}
