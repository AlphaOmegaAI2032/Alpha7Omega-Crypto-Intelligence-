export const CANON_MINT = "Dz9mQ9NzkBcCsuGPFJ3r1bS4wgqKMHBPiVuniW8Mbonk";
export const SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
export const TOKEN_2022_PROGRAM = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb";

/** Unipcs / Bonk Guy bag the fade desk is watching. 15.9M at last marked read. */
export const UNIPCS_OWNER = "2heJbC32Tpfcb3nbUb5ER61K11FGZVfVGtVnDm6LDogF";
export const UNIPCS_BASELINE = 15_900_000;

export const CANON = {
  name: "USELESS COIN",
  symbol: "USELESS",
  decimals: 6,
  maxSupply: 1_000_000_000,
  firstMintAt: "2025-05-10T14:20:53.000Z",
  poolAt: "2025-05-10T14:23:16.000Z",
  launchpad: "LetsBONK.fun → Raydium LaunchLab",
  creator: "ArfVe1K5gt5zsxzRCWSQeWc1rJSJjZzuuYxmvRh71mMQ",
  updatePda: "WLHv2UAZm6z4KyaaELi5pjdbJh6RESMva1Rnn8pJVVh",
  website: "https://theuselesscoin.com",
  twitter: "https://x.com/theuselesscoin",
  ctoNote: "DexScreener community claim 2 Aug 2025. Social takeover, not an on-chain logo change.",
} as const;

export const FAKE_MINTS: { prefix: string; note: string }[] = [
  {
    prefix: "HdnLwx7",
    note: "useless-coin.vercel.app prints a …pump mint. Different token. Do not send size.",
  },
];

export const BLIND_SPOTS = [
  {
    title: "LP is not the mint",
    body: "Authorities can be null and the pool can still be pulled if LP tokens sit in a wallet. Low LP-provider count is a tell even when mint/freeze are revoked.",
  },
  {
    title: "CTO is social, not on-chain",
    body: "With immutable metadata they cannot change the on-chain name or image. They change the DexScreener card. Treat logo updates as marketing.",
  },
  {
    title: "Same-name fakes exist",
    body: "Null mint+freeze is copied by clones. Identify by this mint, volume, and pair age (May 2025), not by the word USELESS.",
  },
  {
    title: "Perps are the other pool",
    body: "A clean SPL mint cannot rug you with an admin function. It can still unwind because a 15.9M bag has not sold and CEX perps are a multiple of the Raydium book.",
  },
] as const;

export const COMPARE = [
  { field: "Standard", useless: "SPL, no extensions", mars: "Upgradeable FlapTaxTokenV3 proxy" },
  { field: "Mint", useless: "Revoked", mars: "Factory can still be dangerous via owner" },
  { field: "Freeze / blacklist", useless: "Revoked", mars: "Blacklist-class risk lives on other BSC names; tax can be toggled" },
  { field: "Metadata", useless: "Immutable", mars: "Name on BscScan is just a string" },
  { field: "Hidden fee", useless: "None on mint", mars: "0–3% tax switch" },
  { field: "Dump vector", useless: "Wallets + perps", mars: "Wallets + tax proxy + thin pool" },
] as const;

export const VERIFY_STEPS = [
  { label: "Solscan", hint: "Token Extensions = False, first mint 10 May 2025", href: (m: string) => `https://solscan.io/token/${m}` },
  { label: "Rugcheck", hint: "Mint / freeze / update should read revoked / immutable", href: (m: string) => `https://rugcheck.xyz/tokens/${m}` },
  { label: "Solsniffer", hint: "LP unlocked share and provider count, not just authorities", href: (m: string) => `https://solsniffer.com/scanner/${m}` },
] as const;

export function isCanon(mint: string): boolean {
  return mint.trim() === CANON_MINT;
}

export function fakeHit(mint: string): string | null {
  const m = mint.trim();
  for (const f of FAKE_MINTS) {
    if (m.startsWith(f.prefix) || m.toLowerCase().startsWith(f.prefix.toLowerCase())) return f.note;
  }
  return null;
}

export function looksLikeUselessClone(mint: string, symbol: string, name: string): boolean {
  if (isCanon(mint)) return false;
  const blob = `${symbol} ${name}`.toUpperCase();
  return blob.includes("USELESS");
}
