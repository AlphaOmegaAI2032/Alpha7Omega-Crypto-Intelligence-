import { BRAND } from "@/lib/brand";

export type NewsBucket =
  | "all"
  | "clarity"
  | "fed"
  | "orange"
  | "tweet"
  | "xai"
  | "listings";

export type NewsItem = {
  id: string;
  title: string;
  url: string;
  source: string;
  at: number;
  bucket: NewsBucket;
};

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn()
    .then((value) => {
      cache.set(key, { at: Date.now(), value });
      return value;
    })
    .catch((err) => {
      if (hit) return hit.value as T;
      throw err;
    });
}

function tag(title: string): NewsBucket {
  const t = title.toLowerCase();
  if (
    /\b(clarity|genius act|cftc|sec\b|regulator|etf approval|mica|miCA|fsca|sarb|ifwg|esma|fit21|sab 121|stablecoin bill|policy|sanctions|ofac|congress|senate)\b/.test(
      t,
    )
  )
    return "clarity";
  if (/\b(fed\b|fomc|powell|rate cut|dot plot|dxy|cpi|jobs|treasury)\b/.test(t)) return "fed";
  if (/\b(xai|grok|elon|spacex|tesla ai)\b/.test(t)) return "xai";
  if (/\b(list|listing|tge|airdrop|launch|binance alpha)\b/.test(t)) return "listings";
  if (/\b(tweet|posted on x\b|truth social)\b/.test(t)) return "tweet";
  if (/\b(bitcoin|btc\b|orange)\b/.test(t)) return "orange";
  return "all";
}

function xmlItems(xml: string, source: string): NewsItem[] {
  const blocks = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 24);
  const out: NewsItem[] = [];
  for (const b of blocks) {
    const body = b[1];
    const title = decode(pick(body, "title"));
    const url = pick(body, "link") || pick(body, "guid");
    if (!title || !url) continue;
    const at = Date.parse(pick(body, "pubDate")) || Date.now();
    out.push({
      id: `${source}:${url}`,
      title,
      url,
      source,
      at,
      bucket: tag(title),
    });
  }
  return out;
}

function pick(xml: string, name: string) {
  const m =
    xml.match(new RegExp(`<${name}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></${name}>`, "i")) ||
    xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, "i"));
  return (m?.[1] || "").replace(/<[^>]+>/g, "").trim();
}

function decode(s: string) {
  return s
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'");
}

async function rss(url: string, source: string): Promise<NewsItem[]> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 10_000);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/rss+xml, application/xml, text/xml", "User-Agent": BRAND.ua },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(String(res.status));
    return xmlItems(await res.text(), source);
  } finally {
    clearTimeout(t);
  }
}

export async function fetchNews(): Promise<{ items: NewsItem[]; sourceNotes: string[]; updatedAt: number }> {
  return cached("news", 180_000, async () => {
    const notes: string[] = [];
    const settled = await Promise.allSettled([
      rss("https://www.coindesk.com/arc/outboundfeeds/rss/", "CoinDesk"),
      rss("https://cointelegraph.com/rss", "Cointelegraph"),
      rss("https://www.theblock.co/rss.xml", "The Block"),
      rss("https://decrypt.co/feed", "Decrypt"),
    ]);
    const items: NewsItem[] = [];
    for (const s of settled) {
      if (s.status === "fulfilled") {
        items.push(...s.value);
        if (s.value[0]) notes.push(s.value[0].source);
      }
    }
    items.sort((a, b) => b.at - a.at);
    const seen = new Set<string>();
    const uniq = items.filter((i) => {
      const k = i.title.toLowerCase().slice(0, 80);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    return { items: uniq.slice(0, 48), sourceNotes: notes, updatedAt: Date.now() };
  });
}
