import { fetchTape } from "./fetchers";
import { holdersFor } from "./holders";
import { classifySymbol, findKnown } from "./known";
import { isStable, sectorFromTags } from "./sectors";
import { scoreFade } from "./score";
import { altseasonIndex, annotate, breadthOf, deskNote, weatherOf } from "./signals";
import type {
  BubbleCoin,
  CategoryPulse,
  Kind,
  MarketPulse,
  ScoredMover,
  UniverseResponse,
} from "./types";

const UA = "Alpha7Omega-CryptoIntelligence/2.0";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn()
    .then((value) => {
      cache.set(key, { at: Date.now(), value });
      return value;
    })
    .catch((err) => {
      if (hit) return hit.value as T;
      throw err;
    });
}

async function getJson<T>(url: string, timeoutMs = 14_000, ua = UA): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": ua },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

async function postJson<T>(url: string, body: unknown, timeoutMs = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json", "User-Agent": UA },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function numOrNull(v: unknown): number | null {
  if (v == null || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function downSpark(arr: number[] | undefined, n = 42): number[] | null {
  if (!arr || arr.length < 8) return null;
  const clean = arr.filter((x) => Number.isFinite(x));
  if (clean.length < 8) return null;
  if (clean.length <= n) return clean;
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    out.push(clean[Math.floor((i * (clean.length - 1)) / (n - 1))]);
  }
  return out;
}

type GeckoMarket = {
  id: string;
  symbol: string;
  name: string;
  image?: string;
  current_price?: number;
  market_cap?: number;
  market_cap_rank?: number;
  total_volume?: number;
  ath_change_percentage?: number;
  price_change_percentage_1h_in_currency?: number;
  price_change_percentage_24h?: number;
  price_change_percentage_7d_in_currency?: number;
  price_change_percentage_30d_in_currency?: number;
  price_change_percentage_1y_in_currency?: number;
  sparkline_in_7d?: { price?: number[] };
};

type GateTicker = {
  contract: string;
  last: string;
  mark_price: string;
  index_price: string;
  change_percentage: string;
  high_24h: string;
  low_24h: string;
  volume_24h_quote: string;
  funding_rate: string;
  total_size: string;
  quanto_multiplier: string;
};

type CmcQuote = {
  name: string;
  price: number;
  volume24h: number;
  volumePercentChange: number;
  marketCap: number;
  percentChange1h: number;
  percentChange24h: number;
  percentChange7d: number;
  percentChange30d: number;
  percentChange90d: number;
  percentChange1y: number;
  ytdPriceChangePercentage: number;
  turnover: number;
  dominance: number;
};

type CmcCoin = {
  name: string;
  symbol: string;
  slug: string;
  tags?: string[];
  cmcRank?: number;
  quotes?: CmcQuote[];
};

function gatePerp(t: GateTicker) {
  const last = num(t.last);
  const mark = num(t.mark_price) || last;
  const quanto = num(t.quanto_multiplier) || 1;
  return {
    last,
    mark,
    change24h: num(t.change_percentage),
    high24h: num(t.high_24h),
    volumeQuote: num(t.volume_24h_quote),
    funding: num(t.funding_rate),
    oiUsd: num(t.total_size) * mark * quanto,
  };
}

function emptyCoin(partial: Partial<BubbleCoin> & Pick<BubbleCoin, "id" | "symbol" | "name">): BubbleCoin {
  return {
    price: 0,
    mcap: 0,
    volume: 0,
    rank: null,
    chg1h: null,
    chg24h: null,
    chg7d: null,
    chg30d: null,
    chg90d: null,
    chg1y: null,
    sector: "other",
    kind: "unknown",
    verdict: "NEUTRAL",
    score: 0,
    reasons: [],
    funding: null,
    oiUsd: null,
    dexLiq: null,
    cliff: null,
    poolPctFdv: null,
    fromHighPct: null,
    volMcap: null,
    flags: [],
    note: "",
    dexUrl: null,
    holders: null,
    spark: null,
    athChg: null,
    volChg: null,
    tvl: null,
    hlOi: null,
    signal: "NONE",
    heatScore: 0,
    tags: [],
    why: "",
    image: null,
    ...partial,
  };
}

const CAT_SKIP = /stablecoin|portfolio|alleged|made in|hodler|launchpad|launchpool|index coop/i;

export async function fetchUniverse(): Promise<UniverseResponse> {
  return cached("universe", 25_000, async () => {
    const notes: string[] = [];
    const geckoUrl =
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=true&price_change_percentage=1h,24h,7d,30d,1y";

    const [
      geckoRes,
      gateRes,
      loreRes,
      tapeRes,
      globalRes,
      fngRes,
      trendRes,
      catRes,
      cmcRes,
      cmcGlobalRes,
      llamaRes,
      feeRes,
      diffRes,
      cmRes,
      hlRes,
    ] = await Promise.allSettled([
      cached("gecko:mkts", 25_000, () => getJson<GeckoMarket[]>(geckoUrl)),
      cached("gate:tick", 15_000, () => getJson<GateTicker[]>("https://api.gateio.ws/api/v4/futures/usdt/tickers")),
      cached("lore:100", 60_000, () =>
        getJson<{ data?: Array<Record<string, string | number>> }>("https://api.coinlore.net/api/tickers/?start=0&limit=100"),
      ),
      fetchTape(),
      cached("gecko:global", 120_000, () =>
        getJson<{
          data?: {
            active_cryptocurrencies?: number;
            total_market_cap?: { usd?: number };
            total_volume?: { usd?: number };
            market_cap_percentage?: { btc?: number; eth?: number };
            market_cap_change_percentage_24h_usd?: number;
          };
        }>("https://api.coingecko.com/api/v3/global"),
      ),
      cached("fng", 180_000, () =>
        getJson<{ data?: Array<{ value?: string; value_classification?: string }> }>(
          "https://api.alternative.me/fng/?limit=1",
        ),
      ),
      cached("gecko:trend", 60_000, () =>
        getJson<{ coins?: Array<{ item?: { symbol?: string } }> }>("https://api.coingecko.com/api/v3/search/trending"),
      ),
      cached("gecko:cats", 180_000, () =>
        getJson<Array<{ id?: string; name?: string; market_cap?: number; market_cap_change_24h?: number }>>(
          "https://api.coingecko.com/api/v3/coins/categories?order=market_cap_change_24h_desc",
        ),
      ),
      cached("cmc:list", 40_000, () =>
        getJson<{ data?: { cryptoCurrencyList?: CmcCoin[] } }>(
          "https://api.coinmarketcap.com/data-api/v3/cryptocurrency/listing?start=1&limit=200&sortBy=market_cap&sortType=desc&convert=USD&cryptoType=all&tagType=all",
          14_000,
          "Mozilla/5.0",
        ),
      ),
      cached("cmc:global", 120_000, () =>
        getJson<{
          data?: {
            btcDominance?: number;
            ethDominance?: number;
            activeCryptoCurrencies?: number;
            btcDominance24hPercentageChange?: number;
            derivativesVolume24h?: number;
            defiMarketCap?: number;
            quotes?: Array<{ totalMarketCap?: number; totalVolume24h?: number }>;
          };
        }>("https://api.coinmarketcap.com/data-api/v3/global-metrics/quotes/latest", 12_000, "Mozilla/5.0"),
      ),
      cached("llama:chains", 300_000, () =>
        getJson<Array<{ tvl?: number; tokenSymbol?: string; gecko_id?: string; name?: string }>>(
          "https://api.llama.fi/v2/chains",
        ),
      ),
      cached("mempool:fees", 30_000, () =>
        getJson<{ fastestFee?: number }>("https://mempool.space/api/v1/fees/recommended"),
      ),
      cached("mempool:diff", 60_000, () =>
        getJson<{ progressPercent?: number }>("https://mempool.space/api/v1/difficulty-adjustment"),
      ),
      cached("cm:btc", 300_000, () =>
        getJson<{ data?: Array<{ HashRate?: string; AdrActCnt?: string }> }>(
          "https://community-api.coinmetrics.io/v4/timeseries/asset-metrics?assets=btc&metrics=HashRate,AdrActCnt&frequency=1d&page_size=2",
        ),
      ),
      cached("hl:ctx", 20_000, () =>
        postJson<[{ universe: Array<{ name: string; isDelisted?: boolean }> }, Array<{
          funding: string;
          openInterest: string;
          markPx: string;
          dayNtlVlm: string;
          prevDayPx: string;
        }>]>("https://api.hyperliquid.xyz/info", { type: "metaAndAssetCtxs" }),
      ),
    ]);

    const gecko = geckoRes.status === "fulfilled" ? geckoRes.value : [];
    if (geckoRes.status === "rejected") notes.push("CoinGecko delayed — CoinMarketCap + CoinLore");
    else notes.push(`CoinGecko ${gecko.length} markets + 7d spark`);

    const gate = gateRes.status === "fulfilled" ? gateRes.value : [];
    if (gateRes.status === "fulfilled") notes.push(`Gate ${gate.length} perps`);

    const lore = loreRes.status === "fulfilled" ? loreRes.value.data || [] : [];
    if (lore.length) notes.push(`CoinLore ${lore.length}`);

    const cmcList = cmcRes.status === "fulfilled" ? cmcRes.value.data?.cryptoCurrencyList || [] : [];
    if (cmcList.length) notes.push(`CoinMarketCap ${cmcList.length}`);

    const trending = new Set<string>();
    if (trendRes.status === "fulfilled") {
      for (const c of trendRes.value.coins || []) {
        const s = (c.item?.symbol || "").toUpperCase();
        if (s) trending.add(s);
      }
      if (trending.size) notes.push(`Trending ${trending.size}`);
    }

    const categories: CategoryPulse[] = [];
    if (catRes.status === "fulfilled" && Array.isArray(catRes.value)) {
      const rows = catRes.value
        .filter((c) => (c.market_cap || 0) > 3_000_000_000 && c.name && !CAT_SKIP.test(c.name))
        .map((c) => ({
          id: c.id || c.name || "",
          name: c.name || "",
          change24: num(c.market_cap_change_24h),
          mcap: num(c.market_cap),
        }));
      rows.sort((a, b) => Math.abs(b.change24) - Math.abs(a.change24));
      categories.push(...rows.slice(0, 10));
      notes.push(`Gecko ${catRes.value.length} categories`);
    }

    const tvlBySym = new Map<string, number>();
    let totalTvl = 0;
    if (llamaRes.status === "fulfilled") {
      for (const row of llamaRes.value) {
        totalTvl += num(row.tvl);
        const sym = (row.tokenSymbol || "").toUpperCase();
        if (!sym) continue;
        tvlBySym.set(sym, Math.max(tvlBySym.get(sym) || 0, num(row.tvl)));
      }
      notes.push(`DeFiLlama TVL ${Math.round(totalTvl / 1e9)}B`);
    }

    const hlBySym = new Map<string, { oi: number; funding: number; mark: number; chg: number; vol: number }>();
    if (hlRes.status === "fulfilled") {
      const [meta, ctxs] = hlRes.value;
      const uni = meta.universe || [];
      for (let i = 0; i < uni.length; i++) {
        const u = uni[i];
        const ctx = ctxs[i];
        if (!u?.name || u.isDelisted || !ctx) continue;
        const mark = num(ctx.markPx);
        const prev = num(ctx.prevDayPx);
        hlBySym.set(u.name.toUpperCase(), {
          oi: num(ctx.openInterest) * mark,
          funding: num(ctx.funding),
          mark,
          chg: prev > 0 ? ((mark - prev) / prev) * 100 : 0,
          vol: num(ctx.dayNtlVlm),
        });
      }
      notes.push(`Hyperliquid ${hlBySym.size} perps`);
    }

    let mempoolSat: number | null = null;
    let diffProgress: number | null = null;
    let hashrateEh: number | null = null;
    let addrActive: number | null = null;
    if (feeRes.status === "fulfilled") mempoolSat = numOrNull(feeRes.value.fastestFee);
    if (diffRes.status === "fulfilled") diffProgress = numOrNull(diffRes.value.progressPercent);
    if (cmRes.status === "fulfilled") {
      const row = (cmRes.value.data || []).at(-1);
      if (row?.HashRate) {
        const gh = num(row.HashRate);
        hashrateEh = gh / 1_000_000;
      }
      if (row?.AdrActCnt) addrActive = num(row.AdrActCnt);
      notes.push("Coin Metrics BTC on-chain");
    }
    if (mempoolSat != null) notes.push(`Mempool ${mempoolSat} sat/vB`);

    const fng = fngRes.status === "fulfilled" ? fngRes.value.data?.[0] : undefined;
    const geckoGlobal = globalRes.status === "fulfilled" ? globalRes.value.data || {} : {};
    const cmcGlobal = cmcGlobalRes.status === "fulfilled" ? cmcGlobalRes.value.data || {} : {};
    const cmcQuote = cmcGlobal.quotes?.[0];

    const pulse: MarketPulse = {
      totalMcap: num(geckoGlobal.total_market_cap?.usd) || num(cmcQuote?.totalMarketCap),
      btcDom: num(geckoGlobal.market_cap_percentage?.btc) || num(cmcGlobal.btcDominance),
      ethDom: num(geckoGlobal.market_cap_percentage?.eth) || num(cmcGlobal.ethDominance),
      volume24: num(geckoGlobal.total_volume?.usd) || num(cmcQuote?.totalVolume24h),
      marketChange24: num(geckoGlobal.market_cap_change_percentage_24h_usd),
      fng: fng?.value != null ? num(fng.value) : null,
      fngLabel: fng?.value_classification || null,
      activeCoins: num(geckoGlobal.active_cryptocurrencies) || num(cmcGlobal.activeCryptoCurrencies),
      trending: [...trending],
      breadthPct: 0,
      altseason: null,
      weather: "mixed",
      mempoolSat,
      hashrateEh,
      addrActive,
      diffProgress,
      totalTvl: totalTvl || null,
      derivVol: numOrNull(cmcGlobal.derivativesVolume24h),
      btcDomChg: numOrNull(cmcGlobal.btcDominance24hPercentageChange),
      defiMcap: numOrNull(cmcGlobal.defiMarketCap),
      deskNote: "",
      categories,
    };
    if (pulse.fng != null) notes.push("Fear & Greed live");
    if (cmcGlobalRes.status === "fulfilled") notes.push("CMC global");

    const gateBySym = new Map<string, ReturnType<typeof gatePerp>>();
    for (const t of gate) {
      if (!t.contract.endsWith("_USDT")) continue;
      gateBySym.set(t.contract.replace(/_USDT$/, "").toUpperCase(), gatePerp(t));
    }

    const loreBySym = new Map<
      string,
      { price: number; mcap: number; vol: number; chg1h: number; chg24h: number; chg7d: number; name: string }
    >();
    for (const row of lore) {
      const sym = String(row.symbol || "").toUpperCase();
      loreBySym.set(sym, {
        price: num(row.price_usd),
        mcap: num(row.market_cap_usd),
        vol: num(row.volume24),
        chg1h: num(row.percent_change_1h),
        chg24h: num(row.percent_change_24h),
        chg7d: num(row.percent_change_7d),
        name: String(row.name || sym),
      });
    }

    const cmcBySym = new Map<string, CmcCoin>();
    for (const row of cmcList) {
      const sym = (row.symbol || "").toUpperCase();
      if (sym) cmcBySym.set(sym, row);
    }

    const coins: BubbleCoin[] = [];
    const seen = new Set<string>();

    const pushCoin = (c: BubbleCoin) => {
      const key = c.symbol.toUpperCase();
      if (seen.has(key)) return;
      seen.add(key);
      coins.push(c);
    };

    const scoreFor = (symbol: string, kind: Kind, flags: string[], note: string, perp: ReturnType<typeof gatePerp> | undefined) =>
      scoreFade({
        symbol,
        kind,
        flags,
        note,
        perp: perp
          ? {
              venue: "gate",
              contract: `${symbol}_USDT`,
              last: perp.last,
              mark: perp.mark,
              index: perp.mark,
              change24h: perp.change24h,
              high24h: perp.high24h,
              low24h: 0,
              volumeQuote: perp.volumeQuote,
              funding: perp.funding,
              oiUsd: perp.oiUsd,
            }
          : null,
        dex: null,
      });

    for (const g of gecko) {
      const symbol = (g.symbol || "").toUpperCase();
      if (!symbol) continue;
      const known = findKnown(symbol);
      const cmc = cmcBySym.get(symbol);
      const tags = cmc?.tags || [];
      const kind: Kind = classifySymbol(symbol, known);
      const perp =
        gateBySym.get(symbol) ||
        (known?.gate ? gateBySym.get(known.gate.replace(/_USDT$/, "").toUpperCase()) : undefined);
      const hl = hlBySym.get(symbol);
      const scored = scoreFor(symbol, kind, known?.flags || [], known?.note || "", perp);
      const q = cmc?.quotes?.[0];
      const mcap = num(g.market_cap) || num(q?.marketCap);
      const vol = num(g.total_volume) || num(q?.volume24h);
      pushCoin(
        emptyCoin({
          id: g.id || symbol,
          symbol,
          name: g.name,
          image: g.image || null,
          price: num(g.current_price) || num(q?.price),
          mcap,
          volume: vol,
          rank: g.market_cap_rank ?? cmc?.cmcRank ?? null,
          chg1h: numOrNull(g.price_change_percentage_1h_in_currency) ?? numOrNull(q?.percentChange1h),
          chg24h: numOrNull(g.price_change_percentage_24h) ?? numOrNull(q?.percentChange24h),
          chg7d: numOrNull(g.price_change_percentage_7d_in_currency) ?? numOrNull(q?.percentChange7d),
          chg30d: numOrNull(g.price_change_percentage_30d_in_currency) ?? numOrNull(q?.percentChange30d),
          chg90d: numOrNull(q?.percentChange90d),
          chg1y: numOrNull(g.price_change_percentage_1y_in_currency) ?? numOrNull(q?.percentChange1y),
          sector: sectorFromTags(symbol, kind, tags),
          kind,
          verdict: scored.verdict,
          score: scored.score,
          reasons: scored.reasons,
          funding: perp?.funding ?? hl?.funding ?? null,
          oiUsd: perp?.oiUsd ?? hl?.oi ?? null,
          fromHighPct: scored.fromHighPct,
          cliff: scored.cliff,
          poolPctFdv: scored.poolPctFdv,
          volMcap: mcap > 0 ? vol / mcap : numOrNull(q?.turnover),
          flags: known?.flags || [],
          note: known?.note || "",
          holders: holdersFor(symbol),
          trending: trending.has(symbol),
          turnover: mcap > 0 ? vol / mcap : numOrNull(q?.turnover),
          spark: downSpark(g.sparkline_in_7d?.price),
          athChg: numOrNull(g.ath_change_percentage),
          volChg: numOrNull(q?.volumePercentChange),
          tvl: tvlBySym.get(symbol) || null,
          hlOi: hl?.oi ?? null,
          tags,
        }),
      );
    }

    if (!gecko.length) {
      for (const [sym, row] of loreBySym) {
        const known = findKnown(sym);
        const cmc = cmcBySym.get(sym);
        const q = cmc?.quotes?.[0];
        const kind: Kind = classifySymbol(sym, known);
        const perp = gateBySym.get(sym);
        const hl = hlBySym.get(sym);
        pushCoin(
          emptyCoin({
            id: `lore-${sym}`,
            symbol: known?.symbol || sym,
            name: row.name,
            price: row.price || num(q?.price),
            mcap: row.mcap || num(q?.marketCap),
            volume: row.vol || num(q?.volume24h),
            rank: cmc?.cmcRank ?? null,
            chg1h: row.chg1h || numOrNull(q?.percentChange1h),
            chg24h: row.chg24h || numOrNull(q?.percentChange24h),
            chg7d: row.chg7d || numOrNull(q?.percentChange7d),
            chg30d: numOrNull(q?.percentChange30d),
            chg90d: numOrNull(q?.percentChange90d),
            chg1y: numOrNull(q?.percentChange1y),
            sector: sectorFromTags(sym, kind, cmc?.tags),
            kind,
            funding: perp?.funding ?? hl?.funding ?? null,
            oiUsd: perp?.oiUsd ?? hl?.oi ?? null,
            fromHighPct: perp ? ((perp.last - perp.high24h) / perp.high24h) * 100 : null,
            volMcap: row.mcap > 0 ? row.vol / row.mcap : null,
            flags: known?.flags || [],
            note: known?.note || "",
            holders: holdersFor(sym),
            trending: trending.has(sym),
            turnover: row.mcap > 0 ? row.vol / row.mcap : null,
            volChg: numOrNull(q?.volumePercentChange),
            tvl: tvlBySym.get(sym) || null,
            hlOi: hl?.oi ?? null,
            tags: cmc?.tags || [],
          }),
        );
      }
    }

    for (const [sym, row] of cmcBySym) {
      if (seen.has(sym)) continue;
      const q = row.quotes?.[0];
      if (!q || q.marketCap < 25_000_000) continue;
      const known = findKnown(sym);
      const kind: Kind = classifySymbol(sym, known);
      const perp = gateBySym.get(sym);
      const hl = hlBySym.get(sym);
      const lore = loreBySym.get(sym);
      pushCoin(
        emptyCoin({
          id: `cmc-${row.slug || sym}`,
          symbol: known?.symbol || sym,
          name: row.name,
          price: q.price || lore?.price || 0,
          mcap: q.marketCap,
          volume: q.volume24h,
          rank: row.cmcRank ?? null,
          chg1h: numOrNull(q.percentChange1h),
          chg24h: numOrNull(q.percentChange24h),
          chg7d: numOrNull(q.percentChange7d),
          chg30d: numOrNull(q.percentChange30d),
          chg90d: numOrNull(q.percentChange90d),
          chg1y: numOrNull(q.percentChange1y),
          sector: sectorFromTags(sym, kind, row.tags),
          kind,
          funding: perp?.funding ?? hl?.funding ?? null,
          oiUsd: perp?.oiUsd ?? hl?.oi ?? null,
          volMcap: q.turnover,
          flags: known?.flags || [],
          note: known?.note || "",
          holders: holdersFor(known?.symbol || sym),
          trending: trending.has(sym),
          turnover: q.turnover,
          volChg: numOrNull(q.volumePercentChange),
          tvl: tvlBySym.get(sym) || null,
          hlOi: hl?.oi ?? null,
          tags: row.tags || [],
        }),
      );
    }

    for (const [sym, perp] of gateBySym) {
      if (seen.has(sym)) continue;
      const known = findKnown(sym);
      const lore = loreBySym.get(sym);
      const hl = hlBySym.get(sym);
      const hot = Math.abs(perp.change24h) >= 12 || known?.kind === "meme" || trending.has(sym);
      if (!hot && !known) continue;
      const kind: Kind = classifySymbol(sym, known);
      const scored = scoreFor(known?.symbol || sym, kind, known?.flags || [], known?.note || "", perp);
      const price = perp.last || lore?.price || 0;
      const mcap = lore?.mcap || Math.max(perp.oiUsd * 8, 1);
      pushCoin(
        emptyCoin({
          id: `gate-${sym}`,
          symbol: known?.symbol || sym,
          name: known?.symbol || lore?.name || sym,
          price,
          mcap,
          volume: perp.volumeQuote || lore?.vol || 0,
          chg1h: lore?.chg1h ?? null,
          chg24h: perp.change24h,
          chg7d: lore?.chg7d ?? null,
          sector: sectorFromTags(sym, kind),
          kind,
          verdict: scored.verdict,
          score: scored.score,
          reasons: scored.reasons,
          funding: perp.funding,
          oiUsd: perp.oiUsd,
          cliff: scored.cliff,
          poolPctFdv: scored.poolPctFdv,
          fromHighPct: scored.fromHighPct,
          volMcap: mcap > 0 ? (perp.volumeQuote || 0) / mcap : null,
          flags: known?.flags || [],
          note: known?.note || "",
          holders: holdersFor(known?.symbol || sym),
          trending: trending.has(sym),
          turnover: mcap > 0 ? (perp.volumeQuote || 0) / mcap : null,
          hlOi: hl?.oi ?? null,
        }),
      );
    }

    if (tapeRes.status === "fulfilled") {
      const movers: ScoredMover[] = tapeRes.value.movers;
      const bySym = new Map(movers.map((m) => [m.symbol.toUpperCase(), m]));
      for (const c of coins) {
        const m = bySym.get(c.symbol.toUpperCase());
        if (!m) continue;
        if (m.dex) {
          c.dexLiq = m.dex.liquidityUsd;
          c.dexUrl = m.dex.url;
          if (m.dex.changeH1 != null) c.chg1h = m.dex.changeH1;
          if (m.dex.imageUrl) c.image = m.dex.imageUrl;
          if (m.dex.marketCap && c.mcap < 1_000) c.mcap = m.dex.marketCap;
        }
        c.cliff = m.cliff;
        c.poolPctFdv = m.poolPctFdv;
        c.fromHighPct = m.fromHighPct;
        c.verdict = m.verdict;
        c.score = m.score;
        c.reasons = m.reasons;
        if (m.perp) {
          c.funding = m.perp.funding;
          c.oiUsd = m.perp.oiUsd;
        }
        if (m.note) c.note = m.note;
      }
      for (const m of movers) {
        const sym = m.symbol.toUpperCase();
        if (seen.has(sym)) continue;
        const hl = hlBySym.get(sym);
        pushCoin(
          emptyCoin({
            id: m.id,
            symbol: m.symbol,
            name: m.name,
            price: m.perp?.last ?? m.dex?.priceUsd ?? 0,
            mcap: m.dex?.marketCap ?? m.dex?.fdv ?? (m.perp ? m.perp.oiUsd * 8 : 0),
            volume: m.dex?.volumeH24 ?? m.perp?.volumeQuote ?? 0,
            chg1h: m.dex?.changeH1 ?? null,
            chg24h: m.perp?.change24h ?? m.dex?.changeH24 ?? null,
            sector: sectorFromTags(sym, m.kind),
            kind: m.kind,
            verdict: m.verdict,
            score: m.score,
            reasons: m.reasons,
            funding: m.perp?.funding ?? hl?.funding ?? null,
            oiUsd: m.perp?.oiUsd ?? hl?.oi ?? null,
            dexLiq: m.dex?.liquidityUsd ?? null,
            cliff: m.cliff,
            poolPctFdv: m.poolPctFdv,
            fromHighPct: m.fromHighPct,
            flags: m.flags,
            note: m.note,
            dexUrl: m.dex?.url ?? null,
            holders: holdersFor(m.symbol),
            image: m.dex?.imageUrl ?? null,
            hlOi: hl?.oi ?? null,
          }),
        );
      }
    }

    for (const c of coins) {
      const oi = Math.max(c.oiUsd || 0, c.hlOi || 0);
      c.oiUsd = oi > 0 ? oi : c.oiUsd;
      if (c.funding == null) {
        const hl = hlBySym.get(c.symbol);
        if (hl) c.funding = hl.funding;
      }
    }

    annotate(coins);

    const br = breadthOf(coins);
    pulse.breadthPct = br.pct;
    pulse.altseason = altseasonIndex(coins);
    const btc = coins.find((c) => c.symbol === "BTC");
    pulse.weather = weatherOf(pulse.fng, btc?.chg24h ?? null, br.pct);
    if (pulse.totalMcap <= 0) {
      pulse.totalMcap = coins.reduce((s, c) => s + (c.mcap || 0), 0);
      pulse.volume24 = coins.reduce((s, c) => s + (c.volume || 0), 0);
    }
    if (pulse.totalMcap > 0 && pulse.btcDom <= 0 && btc) {
      pulse.btcDom = (btc.mcap / pulse.totalMcap) * 100;
      const eth = coins.find((c) => c.symbol === "ETH");
      if (eth) pulse.ethDom = (eth.mcap / pulse.totalMcap) * 100;
    }
    pulse.deskNote = deskNote(coins, pulse);

    notes.push("Heat-sized so alts print. Stables hidden. Glassnode-style on-chain via Coin Metrics + mempool.");
    return { updatedAt: Date.now(), coins, pulse, sourceNotes: notes };
  });
}

export { isStable };
