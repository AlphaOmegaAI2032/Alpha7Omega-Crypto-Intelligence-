import { changeOf } from "./heat";
import { SECTOR_LABEL } from "./sectors";
import type { BubbleCoin, MarketPulse, Sector, SignalKind, Timeframe, Weather } from "./types";

export function classifySignal(c: BubbleCoin, btcChg: number): { signal: SignalKind; why: string } {
  const chg = c.chg24h ?? 0;
  const h1 = c.chg1h ?? 0;
  const fund = c.funding ?? 0;
  const oi = c.oiUsd ?? c.hlOi ?? 0;

  if (c.verdict === "SHORT_HARD") {
    return { signal: "CLIFF", why: "Perp crowding on thin inventory — dump structure" };
  }
  if (fund > 0.00045 && oi > 4_000_000 && chg > 10) {
    return { signal: "CROWDED", why: `Longs paying ${(fund * 100).toFixed(3)}% with OI still open` };
  }
  if (Math.abs(h1) >= 6 && Math.abs(chg) >= 12) {
    return { signal: "EXPLODE", why: `Vertical ${h1 >= 0 ? "bid" : "dump"} — 1h ${h1.toFixed(1)}%` };
  }
  if ((h1 > 2.2 && chg < -6) || (h1 < -2.2 && chg > 10)) {
    return { signal: "DIVERGE", why: "1h tape fighting the 24h print" };
  }
  if (Math.abs(chg - btcChg) >= 8 && Math.abs(chg) >= 3.5) {
    return { signal: "RELATIVE", why: chg > btcChg ? "Outrunning Bitcoin" : "Underperforming Bitcoin" };
  }
  if (c.trending) return { signal: "TRENDING", why: "CoinGecko trending search" };
  if ((c.volChg ?? 0) > 45 && Math.abs(chg) < 3.5) {
    return { signal: "QUIET", why: "Volume expanding while price sleeps" };
  }
  return { signal: "NONE", why: "" };
}

export function interestingScore(c: BubbleCoin, tf: Timeframe, btcChg: number): number {
  const chg = changeOf(c, tf) ?? 0;
  const a = Math.abs(chg);
  const vol = Math.log10(Math.max(c.volume, 10));
  let s = a * vol;
  const h1 = Math.abs(c.chg1h ?? 0);
  if (h1 >= 4) s += h1 * 10;
  if (c.trending) s += 50;
  if (c.verdict === "SHORT_HARD") s += 90;
  else if (c.verdict === "FADE") s += 45;
  else if (c.verdict === "WAIT") s += 20;
  const fund = c.funding ?? 0;
  if (fund > 0.0004) s += 30;
  if ((c.turnover ?? 0) > 0.25) s += 18;
  if ((c.volChg ?? 0) > 60) s += 22;
  if (c.athChg != null && c.athChg > -12) s += 16;
  s += Math.abs(chg - btcChg) * 1.4;
  if (c.signal === "DIVERGE") s += 20;
  if (c.signal === "EXPLODE") s += 25;
  if (c.signal === "CLIFF") s += 40;
  return s;
}

export function breadthOf(coins: BubbleCoin[]) {
  const xs = coins.filter((c) => c.sector !== "stable" && c.chg24h != null);
  const green = xs.filter((c) => (c.chg24h ?? 0) > 0.25).length;
  const red = xs.filter((c) => (c.chg24h ?? 0) < -0.25).length;
  return {
    green,
    red,
    flat: xs.length - green - red,
    pct: xs.length ? (green / xs.length) * 100 : 0,
    n: xs.length,
  };
}

export function altseasonIndex(coins: BubbleCoin[]): number | null {
  const btc = coins.find((c) => c.symbol === "BTC");
  const btc30 = btc?.chg30d;
  if (btc30 == null) return null;
  const alts = coins.filter(
    (c) =>
      c.symbol !== "BTC" &&
      c.sector !== "stable" &&
      c.rank != null &&
      c.rank <= 50 &&
      c.chg30d != null,
  );
  if (alts.length < 10) return null;
  const beat = alts.filter((c) => (c.chg30d ?? 0) > btc30).length;
  return Math.round((beat / alts.length) * 100);
}

export function weatherOf(fng: number | null, btcChg: number | null, pctGreen: number): Weather {
  const f = fng ?? 50;
  const b = btcChg ?? 0;
  if (f >= 62 && b > 0.8 && pctGreen > 58) return "risk-on";
  if (f <= 35 || (b < -2.2 && pctGreen < 38)) return "risk-off";
  return "mixed";
}

export function deskNote(
  coins: BubbleCoin[],
  pulse: Pick<MarketPulse, "btcDom" | "fng" | "weather" | "altseason" | "breadthPct">,
): string {
  const by: Record<string, { n: number; s: number }> = {};
  for (const c of coins) {
    if (c.sector === "stable" || c.chg24h == null) continue;
    const g = by[c.sector] || { n: 0, s: 0 };
    g.n += 1;
    g.s += c.chg24h;
    by[c.sector] = g;
  }
  const ranked = Object.entries(by)
    .map(([k, v]) => ({ k: k as Sector, avg: v.s / Math.max(1, v.n) }))
    .sort((a, b) => b.avg - a.avg);
  const best = ranked[0];
  const worst = ranked[ranked.length - 1];
  const cliffs = coins
    .filter((c) => c.verdict === "SHORT_HARD")
    .slice(0, 3)
    .map((c) => c.symbol);
  const parts: string[] = [];
  if (pulse.weather === "risk-off") parts.push("Risk-off tape.");
  else if (pulse.weather === "risk-on") parts.push("Risk-on breadth.");
  else parts.push("Mixed session.");
  if (pulse.fng != null && pulse.fng >= 60 && pulse.breadthPct < 42) {
    parts.push("Greed with thin breadth — the bid is narrow.");
  }
  if (best) {
    const sign = best.avg >= 0 ? "+" : "";
    parts.push(`${SECTOR_LABEL[best.k]} leads (${sign}${best.avg.toFixed(1)}%).`);
  }
  if (worst && worst.k !== best?.k) parts.push(`${SECTOR_LABEL[worst.k]} lags.`);
  if (pulse.btcDom) parts.push(`BTC.D ${pulse.btcDom.toFixed(1)}%.`);
  if (pulse.altseason != null) parts.push(`Altseason ${pulse.altseason}.`);
  if (cliffs.length) parts.push(`CLIFF: ${cliffs.join(", ")}.`);
  return parts.join(" ");
}

export function topInteresting(coins: BubbleCoin[], tf: Timeframe, n = 8): BubbleCoin[] {
  const btc = coins.find((c) => c.symbol === "BTC");
  const btcChg = btc ? (changeOf(btc, tf) ?? 0) : 0;
  return [...coins]
    .filter((c) => c.sector !== "stable")
    .sort((a, b) => interestingScore(b, tf, btcChg) - interestingScore(a, tf, btcChg))
    .slice(0, n);
}

export function annotate(coins: BubbleCoin[]): void {
  const btc = coins.find((c) => c.symbol === "BTC");
  const btcChg = btc?.chg24h ?? 0;
  for (const c of coins) {
    const hit = classifySignal(c, btcChg);
    c.signal = hit.signal;
    c.why = hit.why;
    c.heatScore = interestingScore(c, "24h", btcChg);
  }
  coins.sort((a, b) => (a.rank ?? 9999) - (b.rank ?? 9999));
}
