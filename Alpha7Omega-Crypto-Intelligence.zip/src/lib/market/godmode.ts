export const GODMODE_DESKS = [
  {
    id: "hunter",
    name: "Hunter",
    role: "Meme breakout desk",
    brief: "Hunts 8–22% DeepHeat break windows on USDT-M and DEX. Names the next 24h longs with invalidation.",
  },
  {
    id: "fade",
    name: "Fade",
    role: "24h short specialist",
    brief: "Mean-reversion shorts. Parabolic prints, stretched funding, thin books. Not a trend short.",
  },
  {
    id: "whale",
    name: "Whale",
    role: "DEX + flow prints",
    brief: "Pool sells vs buys, drip wallets, KOL bags, inventory leaving the cliff.",
  },
  {
    id: "chartist",
    name: "Chartist",
    role: "Pattern desk",
    brief: "AI-augmented pattern book. Structure, invalidation, next 12–24h path.",
  },
  {
    id: "macro",
    name: "Macro",
    role: "Fed · dots · DXY",
    brief: "Rates, dollar, ETF flows, risk-on/off. How BTC seats the alt tape.",
  },
  {
    id: "scribe",
    name: "Scribe",
    role: "Fundamentals diary",
    brief: "Dated buckets: Clarity, Orange Wire, listings, xAI. What actually moved.",
  },
  {
    id: "sentinel",
    name: "Sentinel",
    role: "BTC liquidity seat",
    brief: "Spot book ±1.2%. Walls, air pockets, what alts inherit if BTC rips or dumps.",
  },
  {
    id: "assayer",
    name: "Assayer",
    role: "Mint / CA desk",
    brief: "Reads mint, freeze, metadata, Unipcs bag, perps vs pool. Rejects clones. Fade is not a bid.",
  },
] as const;

export type GodmodeDeskId = (typeof GODMODE_DESKS)[number]["id"];
