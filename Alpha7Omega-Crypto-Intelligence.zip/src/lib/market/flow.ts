import { BRAND } from "@/lib/brand";

const UA = BRAND.ua;
const LLAMA = "https://api.llama.fi";
const YIELDS = "https://yields.llama.fi";
const GECKO = "https://api.coingecko.com/api/v3";
const DS = "https://api.dexscreener.com";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn()
    .then((value) => {
      cache.set(key, { at: Date.now(), value });
      return value;
    })
    .catch((err) => {
      if (hit) return hit.value as T;
      throw err;
    });
}

async function getJson<T>(url: string, timeoutMs = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

function num(v: unknown) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

export type ChainTvl = { name: string; tvl: number; token: string | null };
export type ProtocolRow = {
  name: string;
  category: string;
  tvl: number;
  change1d: number | null;
  change7d: number | null;
  chains: string[];
};
export type YieldRow = {
  chain: string;
  project: string;
  symbol: string;
  tvl: number;
  apy: number;
  stable: boolean;
};
export type DexVenue = { name: string; vol24: number; change1d: number | null };
export type CexVenue = { name: string; volBtc: number; country: string; id: string };
export type TrendCoin = {
  id: string;
  name: string;
  symbol: string;
  rank: number | null;
  chg24: number | null;
  score: number;
};
export type BoostRow = {
  chain: string;
  address: string;
  amount: number;
  url: string;
  description: string;
};

export type FlowResponse = {
  tvl: number;
  tvlChange1d: number | null;
  chains: ChainTvl[];
  protocols: ProtocolRow[];
  yields: YieldRow[];
  dexTotal24: number;
  dexChange1d: number | null;
  dexes: DexVenue[];
  cexes: CexVenue[];
  cexVolBtc: number;
  trending: TrendCoin[];
  boosts: BoostRow[];
  notes: string[];
  updatedAt: number;
};

export async function fetchFlow(): Promise<FlowResponse> {
  return cached("flow", 90_000, async () => {
    const notes: string[] = [];
    const [chainsS, protoS, dexS, yieldS, cexS, trendS, boostS] = await Promise.allSettled([
      getJson<Array<{ name?: string; tvl?: number; tokenSymbol?: string }>>(`${LLAMA}/v2/chains`),
      getJson<Array<{ name?: string; category?: string; tvl?: number; change_1d?: number; change_7d?: number; chains?: string[] }>>(
        `${LLAMA}/protocols`,
      ),
      getJson<{
        total24h?: number;
        change_1d?: number;
        protocols?: Array<{ name?: string; displayName?: string; total24h?: number; change_1d?: number }>;
      }>(`${LLAMA}/overview/dexs?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true`),
      getJson<{ data?: Array<{ chain?: string; project?: string; symbol?: string; tvlUsd?: number; apy?: number; stablecoin?: boolean; ilRisk?: string }> }>(
        `${YIELDS}/pools`,
      ),
      getJson<Array<{ id?: string; name?: string; trade_volume_24h_btc?: number; country?: string }>>(
        `${GECKO}/exchanges?per_page=20`,
      ),
      getJson<{ coins?: Array<{ item?: { id?: string; name?: string; symbol?: string; market_cap_rank?: number; score?: number; data?: { price_change_percentage_24h?: { usd?: number } } } }> }>(
        `${GECKO}/search/trending`,
      ),
      getJson<Array<{ chainId?: string; tokenAddress?: string; amount?: number; url?: string; description?: string }>>(
        `${DS}/token-boosts/top/v1`,
      ),
    ]);

    const chainsRaw = chainsS.status === "fulfilled" ? chainsS.value : [];
    if (chainsS.status === "fulfilled") notes.push(`Llama ${chainsRaw.length} chains`);
    const chains = [...chainsRaw]
      .map((c) => ({ name: c.name || "", tvl: num(c.tvl), token: c.tokenSymbol || null }))
      .filter((c) => c.tvl > 0 && c.name)
      .sort((a, b) => b.tvl - a.tvl)
      .slice(0, 18);
    const tvl = chains.reduce((s, c) => s + c.tvl, 0);

    const protoRaw = protoS.status === "fulfilled" ? protoS.value : [];
    if (protoS.status === "fulfilled") notes.push(`Llama ${protoRaw.length} protocols`);
    const protocols = [...protoRaw]
      .map((p) => ({
        name: p.name || "",
        category: p.category || "other",
        tvl: num(p.tvl),
        change1d: p.change_1d != null ? num(p.change_1d) : null,
        change7d: p.change_7d != null ? num(p.change_7d) : null,
        chains: (p.chains || []).slice(0, 4),
      }))
      .filter((p) => p.tvl > 0 && p.name)
      .sort((a, b) => b.tvl - a.tvl)
      .slice(0, 28);

    const tvlChange1d =
      protocols.filter((p) => p.change1d != null).length > 4
        ? protocols.slice(0, 12).reduce((s, p) => s + (p.change1d || 0), 0) / 12
        : null;

    const dexRaw = dexS.status === "fulfilled" ? dexS.value : null;
    if (dexRaw) notes.push("Llama DEX volume");
    const dexes = [...(dexRaw?.protocols || [])]
      .map((d) => ({
        name: d.displayName || d.name || "",
        vol24: num(d.total24h),
        change1d: d.change_1d != null ? num(d.change_1d) : null,
      }))
      .filter((d) => d.vol24 > 0 && d.name)
      .sort((a, b) => b.vol24 - a.vol24)
      .slice(0, 18);

    const yieldRaw = yieldS.status === "fulfilled" ? yieldS.value.data || [] : [];
    if (yieldS.status === "fulfilled") notes.push("Llama yields");
    const yields = [...yieldRaw]
      .filter((y) => num(y.tvlUsd) >= 8_000_000 && num(y.apy) >= 2 && num(y.apy) <= 55)
      .sort((a, b) => num(b.tvlUsd) - num(a.tvlUsd))
      .slice(0, 18)
      .map((y) => ({
        chain: y.chain || "",
        project: y.project || "",
        symbol: y.symbol || "",
        tvl: num(y.tvlUsd),
        apy: num(y.apy),
        stable: !!y.stablecoin,
      }));

    const cexRaw = cexS.status === "fulfilled" ? cexS.value : [];
    if (cexS.status === "fulfilled") notes.push(`Gecko ${cexRaw.length} CEX`);
    const cexes = [...cexRaw]
      .map((c) => ({
        id: c.id || "",
        name: c.name || "",
        volBtc: num(c.trade_volume_24h_btc),
        country: c.country || "",
      }))
      .filter((c) => c.volBtc > 0 && c.name)
      .sort((a, b) => b.volBtc - a.volBtc)
      .slice(0, 16);
    const cexVolBtc = cexes.reduce((s, c) => s + c.volBtc, 0);

    const trendRaw = trendS.status === "fulfilled" ? trendS.value.coins || [] : [];
    if (trendS.status === "fulfilled") notes.push("Gecko trending");
    const trending = trendRaw.slice(0, 12).map((row, i) => {
      const it = row.item || {};
      return {
        id: it.id || String(i),
        name: it.name || "",
        symbol: (it.symbol || "").toUpperCase(),
        rank: it.market_cap_rank ?? null,
        chg24: it.data?.price_change_percentage_24h?.usd ?? null,
        score: num(it.score),
      };
    });

    const boostRaw = boostS.status === "fulfilled" ? boostS.value : [];
    if (boostS.status === "fulfilled") notes.push("DexScreener boosts");
    const boosts = boostRaw.slice(0, 14).map((b) => ({
      chain: b.chainId || "",
      address: b.tokenAddress || "",
      amount: num(b.amount),
      url: b.url || "",
      description: (b.description || "").slice(0, 140),
    }));

    return {
      tvl,
      tvlChange1d,
      chains,
      protocols,
      yields,
      dexTotal24: num(dexRaw?.total24h),
      dexChange1d: dexRaw?.change_1d != null ? num(dexRaw.change_1d) : null,
      dexes,
      cexes,
      cexVolBtc,
      trending,
      boosts,
      notes,
      updatedAt: Date.now(),
    };
  });
}

export function flowSnapshot(flow: FlowResponse): string {
  const lines: string[] = [];
  lines.push(`TVL ${flow.tvl.toFixed(0)} 1d ${flow.tvlChange1d ?? "—"}`);
  lines.push(`DEX 24h vol ${flow.dexTotal24.toFixed(0)} chg ${flow.dexChange1d ?? "—"}`);
  lines.push(`CEX 24h vol ${flow.cexVolBtc.toFixed(0)} BTC (self-reported)`);
  lines.push("CHAINS");
  for (const c of flow.chains.slice(0, 8)) lines.push(`${c.name} ${c.tvl.toFixed(0)}`);
  lines.push("PROTOCOLS");
  for (const p of flow.protocols.slice(0, 8)) lines.push(`${p.name} ${p.category} ${p.tvl.toFixed(0)} 1d ${p.change1d ?? "—"}`);
  lines.push("DEX VENUES");
  for (const d of flow.dexes.slice(0, 8)) lines.push(`${d.name} ${d.vol24.toFixed(0)} 1d ${d.change1d ?? "—"}`);
  lines.push("CEX");
  for (const c of flow.cexes.slice(0, 8)) lines.push(`${c.name} ${c.volBtc.toFixed(0)} BTC ${c.country}`);
  lines.push("TRENDING");
  for (const t of flow.trending.slice(0, 8)) lines.push(`${t.symbol} ${t.name} rank ${t.rank ?? "—"} 24h ${t.chg24 ?? "—"}`);
  lines.push("YIELDS");
  for (const y of flow.yields.slice(0, 6)) lines.push(`${y.project} ${y.symbol} ${y.chain} APY ${y.apy.toFixed(1)} TVL ${y.tvl.toFixed(0)}`);
  return lines.join("\n");
}
