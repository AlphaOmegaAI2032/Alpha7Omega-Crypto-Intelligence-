import type { Sector } from "./types";

const SETS: Record<Exclude<Sector, "other">, string[]> = {
  btc: ["BTC", "WBTC", "CBBTC", "TBTC"],
  l1: [
    "ETH", "SOL", "BNB", "XRP", "ADA", "AVAX", "TON", "SUI", "APT", "NEAR", "SEI", "INJ",
    "TIA", "HBAR", "ATOM", "DOT", "TRX", "LTC", "BCH", "XLM", "ALGO", "FTM", "S", "HYPE",
    "KAS", "MONAD", "KAVA", "EGLD", "FLOW", "MINA", "ROSE", "CFX", "CORE", "IP", "BERA",
  ],
  l2: ["MATIC", "POL", "ARB", "OP", "STRK", "ZK", "IMX", "MANTA", "BLAST", "SCROLL", "LINEA", "STARK"],
  defi: [
    "UNI", "AAVE", "MKR", "SKY", "LDO", "ONDO", "PENDLE", "JUP", "RAY", "CAKE", "CRV", "CVX",
    "COMP", "SNX", "DYDX", "GMX", "ENA", "ETHFI", "EIGEN", "MORPHO", "SYRUP", "JTO", "PYTH",
    "LINK", "W", "DRIFT", "HYPE",
  ],
  ai: [
    "TAO", "FET", "RENDER", "RNDR", "WLD", "FLOCK", "UAI", "AGIX", "OCEAN", "ARKM", "AIOZ",
    "VIRTUAL", "AIXBT", "GRT", "NMR", "AI", "CGPT", "COOKIE", "AIA", "AKT",
  ],
  meme: [
    "DOGE", "SHIB", "PEPE", "BONK", "WIF", "FLOKI", "BRETT", "MEW", "POPCAT", "NEIRO",
    "MARSCOIN", "USELESS", "TRUMP", "MELANIA", "PNUT", "GOAT", "MOG", "TURBO", "MEME",
    "SPX", "MOODENG", "GIGA", "FARTCOIN", "TOSHI", "BROCCOLI", "BROCCOLI714",
    "BULLA", "CHILLGUY", "DOOD", "XAN",
  ],
  privacy: ["ZEC", "DASH", "XMR", "FIRO", "BEAM", "ROSE", "SCRT", "DCR", "RAIL", "ZAMA", "NYM", "ARRR"],
  tradfi: [
    "GPRO", "SOXL", "KORU", "SNDK", "SKHY", "KLAC", "SNXX", "SKUU", "MVLL", "TSLA", "NVDA",
    "AAPL", "AMZN", "META", "GOOGL", "MSFT", "SPY", "QQQ", "MSTR", "COIN", "HOOD",
  ],
  stable: [
    "USDT", "USDC", "DAI", "USDE", "USD1", "BUSD", "TUSD", "USDS", "USDD", "PYUSD", "RLUSD",
    "FDUSD", "FRAX", "CRVUSD", "GUSD", "USDP", "LUSD", "GHO", "USDJ",
  ],
};

const LOOKUP = new Map<string, Sector>();
for (const [sector, list] of Object.entries(SETS) as [Sector, string[]][]) {
  for (const s of list) LOOKUP.set(s.toUpperCase(), sector);
}

export function sectorOf(symbol: string, kind?: string): Sector {
  const raw = symbol.replace(/^\$/, "").toUpperCase();
  const hit = LOOKUP.get(raw);
  if (hit) return hit;
  const s = raw.replace(/_USDT$/i, "").replace(/-USDT$/i, "");
  if (s && s !== raw) {
    const hit2 = LOOKUP.get(s);
    if (hit2) return hit2;
  }
  if (kind === "meme") return "meme";
  if (kind === "tradfi") return "tradfi";
  if (kind === "privacy") return "privacy";
  return "other";
}

export function sectorFromTags(symbol: string, kind?: string, tags?: string[]): Sector {
  const base = sectorOf(symbol, kind);
  if (base !== "other") return base;
  if (!tags?.length) return base;
  const t = tags.map((x) => x.toLowerCase());
  if (t.some((x) => x.includes("stablecoin") || x === "usd-stablecoin")) return "stable";
  if (t.some((x) => x.includes("meme"))) return "meme";
  if (t.some((x) => x.includes("ai-") || x.includes("artificial-intelligence") || x === "ai-big-data")) return "ai";
  if (t.some((x) => x === "privacy" || x.includes("privacy"))) return "privacy";
  if (t.some((x) => x.includes("layer-2") || x === "rollups")) return "l2";
  if (t.some((x) => x.includes("defi") || x === "decentralized-exchange" || x === "yield-farming")) return "defi";
  if (t.some((x) => x.includes("layer-1"))) return "l1";
  if (t.some((x) => x.includes("tokenized") || x === "real-world-assets" || x === "rwa")) return "tradfi";
  return "other";
}

export const SECTOR_LABEL: Record<Sector, string> = {
  btc: "BTC",
  l1: "L1",
  l2: "L2",
  defi: "DEFI",
  ai: "AI",
  meme: "MEME",
  privacy: "PRIVACY",
  tradfi: "TRADFI",
  stable: "STABLE",
  other: "OTHER",
};

export const CAT_TO_SECTOR: Record<string, Sector> = {
  Meme: "meme",
  "Solana Meme": "meme",
  "Artificial Intelligence (AI)": "ai",
  "AI Agents": "ai",
  "Privacy Coins": "privacy",
  Privacy: "privacy",
  "Decentralized Finance (DeFi)": "defi",
  "Layer 1 (L1)": "l1",
  "Layer 2 (L2)": "l2",
  "Real World Assets (RWA)": "tradfi",
  Perpetuals: "defi",
  "Zero Knowledge (ZK)": "privacy",
};

export function isStable(symbol: string): boolean {
  return sectorOf(symbol) === "stable";
}
