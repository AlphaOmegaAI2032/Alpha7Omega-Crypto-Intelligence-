import type { BreakoutHit, Kind, Verdict } from "./types";

export function verdictLabel(v: Verdict): string {
  switch (v) {
    case "SHORT_HARD":
      return "SHORT HARD";
    case "FADE":
      return "FADE";
    case "WAIT":
      return "WAIT";
    case "AVOID":
      return "NOT A P&D";
    case "BREAKOUT":
      return "BREAKOUT";
    case "TRAP":
      return "THIN TRAP";
    default:
      return "WATCH";
  }
}

export function verdictClass(v: Verdict): string {
  switch (v) {
    case "SHORT_HARD":
      return "bg-down text-fg";
    case "FADE":
      return "bg-down/15 text-down";
    case "WAIT":
      return "bg-wait/15 text-wait";
    case "AVOID":
      return "bg-elevated text-muted";
    case "BREAKOUT":
      return "bg-up text-accent-fg";
    case "TRAP":
      return "bg-down/20 text-down";
    default:
      return "bg-elevated text-muted";
  }
}

export function kindLabel(k: Kind): string {
  switch (k) {
    case "meme":
      return "MEME";
    case "project":
      return "PROJECT";
    case "tradfi":
      return "TRADFI";
    case "privacy":
      return "PRIVACY";
    default:
      return "UNK";
  }
}

export function sourceLabel(s: BreakoutHit["source"]): string {
  switch (s) {
    case "pump":
      return "PUMP";
    case "trending":
      return "TREND";
    case "boost":
      return "BOOST";
    case "new":
      return "NEW";
    case "live":
      return "LIVE";
    case "search":
      return "SEARCH";
    case "cto":
      return "CTO";
    default:
      return "DEX";
  }
}
