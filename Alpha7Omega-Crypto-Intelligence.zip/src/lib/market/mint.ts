import {
  CANON,
  CANON_MINT,
  fakeHit,
  isCanon,
  looksLikeUselessClone,
  SPL_TOKEN_PROGRAM,
  TOKEN_2022_PROGRAM,
  UNIPCS_BASELINE,
  UNIPCS_OWNER,
} from "./mint-canon";

export type AuthStatus = "revoked" | "live" | "immutable" | "mutable" | "unknown";
export type MintHolder = { owner: string; amount: number; pct: number; label: string | null };
export type MintPair = {
  dex: string; name: string; url: string; pair: string; priceUsd: number; liqUsd: number;
  vol24: number; pct24: number; fdv: number | null; marketCap: number | null; ageHours: number | null;
};
export type PerpTape = { venue: string; last: number; pct24: number; volUsd: number; oiUsd: number | null; funding: number | null };
export type MintDossier = {
  fetchedAt: string; sources: string[]; mint: string; canonical: boolean; clone: boolean; fakeNote: string | null;
  name: string; symbol: string; priceUsd: number; mcap: number | null; fdv: number | null; supply: number;
  maxSupply: number | null; decimals: number; tokenProgram: string; token2022: boolean;
  mintAuth: AuthStatus; freezeAuth: AuthStatus; updateAuth: AuthStatus; updateAuthority: string | null;
  creator: string | null; creatorBalance: number | null; firstMintAt: string | null; holders: number | null;
  lpProviders: number | null; totalLiqUsd: number; lpLockedUsd: number | null; rugScore: number | null;
  jupVerified: boolean; pairs: MintPair[]; holdersTop: MintHolder[]; perps: PerpTape[];
  unipcs: { owner: string; amount: number; pct: number; baseline: number; moved: boolean } | null;
  insiders: { accounts: number; tokens: number } | null;
  verdict: { metadata: "pass" | "fail" | "warn"; trade: "fade" | "watch" | "reject"; note: string };
};

async function fetchJson<T>(url: string, ms = 9000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { accept: "application/json", "user-agent": "Alpha7Omega-CryptoIntelligence/2.0" },
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}
function num(v: unknown, d = 0): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : d;
}

type Cache<T> = { at: number; value: T };
const cache = new Map<string, Cache<unknown>>();

function cached<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key) as Cache<T> | undefined;
  if (hit && Date.now() - hit.at < ttl) return Promise.resolve(hit.value);
  return fn().then((value) => {
    cache.set(key, { at: Date.now(), value });
    return value;
  });
}

const BASE58 = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

export function normMint(raw: string | undefined | null): string {
  const t = (raw ?? "").trim().replace(/\s/g, "");
  if (BASE58.test(t)) return t;
  return CANON_MINT;
}

type DxPair = {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress?: string;
  baseToken: { address?: string; symbol: string; name: string };
  quoteToken: { symbol: string };
  priceUsd?: string;
  volume?: { h24?: number };
  priceChange?: { h24?: number };
  liquidity?: { usd?: number };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
};

type RugHolder = {
  address?: string;
  owner?: string;
  uiAmount?: number;
  pct?: number;
  insider?: boolean;
};

type RugReport = {
  mint?: string;
  tokenProgram?: string;
  creator?: string;
  creatorBalance?: number;
  token?: { mintAuthority?: string | null; freezeAuthority?: string | null; supply?: number; decimals?: number };
  token_extensions?: unknown;
  tokenMeta?: {
    name?: string;
    symbol?: string;
    mutable?: boolean;
    updateAuthority?: string;
  };
  topHolders?: RugHolder[];
  freezeAuthority?: string | null;
  mintAuthority?: string | null;
  totalMarketLiquidity?: number;
  totalLPProviders?: number;
  totalHolders?: number;
  price?: number;
  score?: number;
  score_normalised?: number;
  detectedAt?: string;
  lockers?: Record<string, { usdcLocked?: number }>;
  verification?: { jup_verified?: boolean; name?: string; symbol?: string };
  insiderNetworks?: { size?: number; tokenAmount?: number }[];
};

function authOf(live: boolean | null, kind: "key" | "meta"): AuthStatus {
  if (live == null) return "unknown";
  if (kind === "meta") return live ? "mutable" : "immutable";
  return live ? "live" : "revoked";
}

function mapPairs(rows: DxPair[], mint: string): MintPair[] {
  const all = rows.map((p) => {
    const created = p.pairCreatedAt ?? NaN;
    return {
      dex: p.dexId,
      name: `${p.baseToken.symbol} / ${p.quoteToken.symbol}`,
      url: p.url,
      pair: p.pairAddress ?? "",
      priceUsd: num(p.priceUsd),
      liqUsd: num(p.liquidity?.usd),
      vol24: num(p.volume?.h24),
      pct24: num(p.priceChange?.h24),
      fdv: p.fdv ?? p.marketCap ?? null,
      marketCap: p.marketCap ?? p.fdv ?? null,
      ageHours: Number.isFinite(created) ? (Date.now() - created) / 36e5 : null,
      chain: p.chainId,
      base: p.baseToken?.address ?? "",
    };
  });
  const match = all.filter((p) => p.chain === "solana" && (p.base === mint || p.base === ""));
  const picked = (match.length ? match : all.filter((p) => p.chain === "solana")).sort(
    (a, b) => b.liqUsd - a.liqUsd,
  );
  return picked.slice(0, 8).map(({ chain: _c, base: _b, ...rest }) => rest);
}

async function dexPairs(mint: string): Promise<{ pairs: MintPair[]; sources: string[] }> {
  try {
    const raw = await fetchJson<{ pairs?: DxPair[] }>(
      `https://api.dexscreener.com/latest/dex/tokens/${mint}`,
      10_000,
    );
    const pairs = mapPairs(raw.pairs ?? [], mint);
    return { pairs, sources: pairs.length ? ["dexscreener"] : [] };
  } catch {
    return { pairs: [], sources: [] };
  }
}

async function rugReport(mint: string): Promise<{ rug: RugReport | null; sources: string[] }> {
  try {
    const rug = await fetchJson<RugReport>(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`, 14_000);
    return { rug, sources: ["rugcheck"] };
  } catch {
    return { rug: null, sources: [] };
  }
}

async function rpcMint(mint: string): Promise<{
  tokenProgram: string;
  token2022: boolean;
  mintRevoked: boolean | null;
  freezeRevoked: boolean | null;
  supplyRaw: number | null;
  decimals: number | null;
  sources: string[];
}> {
  const empty = {
    tokenProgram: SPL_TOKEN_PROGRAM,
    token2022: false,
    mintRevoked: null as boolean | null,
    freezeRevoked: null as boolean | null,
    supplyRaw: null as number | null,
    decimals: null as number | null,
    sources: [] as string[],
  };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch("https://api.mainnet-beta.solana.com", {
      method: "POST",
      signal: ctrl.signal,
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "getAccountInfo",
        params: [mint, { encoding: "base64" }],
      }),
    });
    clearTimeout(t);
    if (!res.ok) return empty;
    const json = (await res.json()) as {
      result?: { value?: { owner?: string; data?: [string, string] } | null };
    };
    const value = json.result?.value;
    if (!value?.data?.[0] || !value.owner) return empty;
    const buf = Buffer.from(value.data[0], "base64");
    if (buf.length < 82) return { ...empty, tokenProgram: value.owner, token2022: value.owner === TOKEN_2022_PROGRAM };
    const mintOpt = buf.readUInt32LE(0);
    const freezeOpt = buf.readUInt32LE(46);
    const supplyRaw = Number(buf.readBigUInt64LE(36));
    return {
      tokenProgram: value.owner,
      token2022: value.owner === TOKEN_2022_PROGRAM,
      mintRevoked: mintOpt === 0,
      freezeRevoked: freezeOpt === 0,
      supplyRaw: Number.isFinite(supplyRaw) ? supplyRaw : null,
      decimals: buf[44] ?? null,
      sources: ["solana-rpc"],
    };
  } catch {
    return empty;
  }
}

async function perpsFor(symbol: string): Promise<{ perps: PerpTape[]; sources: string[] }> {
  const sources: string[] = [];
  const perps: PerpTape[] = [];
  const [gate, okxTicker, okxOi] = await Promise.allSettled([
    fetchJson<{
      contract: string;
      last: string;
      change_percentage: string;
      volume_24h_quote: string;
      funding_rate: string;
    }[]>(`https://api.gateio.ws/api/v4/futures/usdt/tickers?contract=${symbol}_USDT`, 8000),
    fetchJson<{
      data?: { instId: string; last: string; open24h: string; volCcy24h: string }[];
    }>(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}-USDT-SWAP`, 8000),
    fetchJson<{ data?: { oiUsd?: string; oiCcy?: string }[] }>(
      `https://www.okx.com/api/v5/public/open-interest?instType=SWAP&instId=${symbol}-USDT-SWAP`,
      8000,
    ),
  ]);

  let gateLast = 0;
  if (gate.status === "fulfilled") {
    const g = Array.isArray(gate.value) ? gate.value[0] : gate.value;
    if (g?.last) {
      sources.push("gate-usdt-perps");
      gateLast = num(g.last);
      perps.push({
        venue: "Gate",
        last: gateLast,
        pct24: num(g.change_percentage),
        volUsd: num(g.volume_24h_quote),
        oiUsd: null,
        funding: num(g.funding_rate),
      });
    }
  }

  try {
    const stats = await fetchJson<{ open_interest_usd?: number; open_interest?: number; mark_price?: number }[]>(
      `https://api.gateio.ws/api/v4/futures/usdt/contract_stats?contract=${symbol}_USDT&limit=1`,
      8000,
    );
    const row = stats?.[0];
    const g = perps.find((p) => p.venue === "Gate");
    if (g && row) {
      g.oiUsd = num(row.open_interest_usd);
      sources.push("gate-oi");
    }
  } catch {
    /* optional */
  }

  if (okxTicker.status === "fulfilled") {
    const t = okxTicker.value.data?.[0];
    if (t) {
      sources.push("okx-swap");
      const last = num(t.last);
      const open = num(t.open24h);
      const oi = okxOi.status === "fulfilled" ? num(okxOi.value.data?.[0]?.oiUsd) : 0;
      perps.push({
        venue: "OKX",
        last,
        pct24: open ? ((last - open) / open) * 100 : 0,
        volUsd: last ? num(t.volCcy24h) * last : num(t.volCcy24h),
        oiUsd: oi || null,
        funding: null,
      });
    }
  } else if (okxOi.status === "fulfilled" && okxOi.value.data?.[0]) {
    sources.push("okx-oi");
    perps.push({
      venue: "OKX",
      last: gateLast,
      pct24: 0,
      volUsd: 0,
      oiUsd: num(okxOi.value.data[0].oiUsd),
      funding: null,
    });
  }

  return { perps, sources };
}

function labelHolder(owner: string): string | null {
  if (owner === UNIPCS_OWNER) return "Unipcs bag";
  if (owner === CANON.creator) return "Creator";
  return null;
}

function buildDossier(
  mint: string,
  rug: RugReport | null,
  pairs: MintPair[],
  rpc: Awaited<ReturnType<typeof rpcMint>>,
  perps: PerpTape[],
  sources: string[],
): MintDossier {
  const token = rug?.token;
  const meta = rug?.tokenMeta;
  const decimals = token?.decimals ?? rpc.decimals ?? CANON.decimals;
  const supplyRaw = token?.supply ?? rpc.supplyRaw ?? 0;
  const supply = supplyRaw > 1e9 ? supplyRaw / 10 ** decimals : supplyRaw;
  const tokenProgram = rug?.tokenProgram ?? rpc.tokenProgram;
  const token2022 = tokenProgram === TOKEN_2022_PROGRAM || rpc.token2022;
  const mintRevoked = rug
    ? token?.mintAuthority == null && rug.mintAuthority == null
    : rpc.mintRevoked;
  const freezeRevoked = rug
    ? token?.freezeAuthority == null && rug.freezeAuthority == null
    : rpc.freezeRevoked;
  const mintLive = mintRevoked == null ? null : !mintRevoked;
  const freezeLive = freezeRevoked == null ? null : !freezeRevoked;
  const mutable = meta?.mutable ?? null;

  const main = pairs[0];
  const priceUsd = main?.priceUsd || num(rug?.price);
  const mcap = main?.marketCap ?? (priceUsd && supply ? priceUsd * supply : null);
  const fdv = main?.fdv ?? mcap;
  const totalLiq = pairs.reduce((s, p) => s + p.liqUsd, 0) || num(rug?.totalMarketLiquidity);
  const lpLocked = rug?.lockers
    ? Object.values(rug.lockers).reduce((s, l) => s + num(l.usdcLocked), 0)
    : null;

  const holdersTop: MintHolder[] = (rug?.topHolders ?? []).slice(0, 16).map((h) => {
    const owner = h.owner || h.address || "";
    return {
      owner,
      amount: num(h.uiAmount),
      pct: num(h.pct),
      label: labelHolder(owner),
    };
  });

  const unipcsRow = holdersTop.find((h) => h.owner === UNIPCS_OWNER);
  const unipcs = isCanon(mint)
    ? unipcsRow
      ? {
          owner: UNIPCS_OWNER,
          amount: unipcsRow.amount,
          pct: unipcsRow.pct,
          baseline: UNIPCS_BASELINE,
          moved: unipcsRow.amount < UNIPCS_BASELINE * 0.92,
        }
      : {
          owner: UNIPCS_OWNER,
          amount: 0,
          pct: 0,
          baseline: UNIPCS_BASELINE,
          moved: true,
        }
    : null;

  const name = meta?.name || main?.name.split(" /")[0] || (isCanon(mint) ? CANON.name : "Unknown");
  const symbol = (meta?.symbol || "").toUpperCase() || (isCanon(mint) ? CANON.symbol : "???");
  const clone = looksLikeUselessClone(mint, symbol, name);
  const fake = fakeHit(mint);
  const mintAuth = authOf(mintLive, "key");
  const freezeAuth = authOf(freezeLive, "key");
  const updateAuth = authOf(mutable, "meta");

  const clean =
    mintAuth === "revoked" && freezeAuth === "revoked" && (updateAuth === "immutable" || updateAuth === "unknown");

  let metadata: MintDossier["verdict"]["metadata"] = "warn";
  if (fake || clone) metadata = clean ? "pass" : "fail";
  else if (mintAuth === "live" || freezeAuth === "live" || token2022) metadata = "fail";
  else if (updateAuth === "mutable") metadata = "warn";
  else if (clean) metadata = "pass";

  let trade: MintDossier["verdict"]["trade"] = "watch";
  let note: string;
  if (fake) {
    trade = "reject";
    note = fake;
  } else if (clone) {
    trade = "reject";
    note = "Same-name clone. Identify USELESS by Dz9mQ9…Mbonk, volume and May 2025 pair age — not the ticker.";
  } else if (metadata === "fail") {
    trade = "reject";
    note = "Mint or freeze still live, or Token-2022 extensions on the mint. Do not size this.";
  } else if (isCanon(mint)) {
    trade = unipcs?.moved ? "watch" : "fade";
    note = unipcs?.moved
      ? "Metadata still pass. Unipcs bag is off the 15.9M mark — treat as a moving dump, isolated, hard stops."
      : "Metadata pass is not a bid. Unipcs 15.9M still sitting. Perps vs pool is the unwind machine. Fade, don't chase.";
  } else if (clean) {
    trade = "watch";
    note = "Authorities look clean. That only freezes brand and supply. Wallets and LP still decide the tape.";
  } else {
    trade = "watch";
    note = "Incomplete read. Verify mint/freeze/update on Rugcheck before size.";
  }

  return {
    fetchedAt: new Date().toISOString(),
    sources: [...new Set(sources)],
    mint,
    canonical: isCanon(mint),
    clone,
    fakeNote: fake,
    name,
    symbol,
    priceUsd,
    mcap,
    fdv,
    supply,
    maxSupply: isCanon(mint) ? CANON.maxSupply : null,
    decimals,
    tokenProgram,
    token2022,
    mintAuth,
    freezeAuth,
    updateAuth,
    updateAuthority: meta?.updateAuthority ?? (isCanon(mint) ? CANON.updatePda : null),
    creator: rug?.creator ?? (isCanon(mint) ? CANON.creator : null),
    creatorBalance: rug?.creatorBalance ?? null,
    firstMintAt: rug?.detectedAt ?? (isCanon(mint) ? CANON.firstMintAt : null),
    holders: rug?.totalHolders ?? null,
    lpProviders: rug?.totalLPProviders ?? null,
    totalLiqUsd: totalLiq,
    lpLockedUsd: lpLocked,
    rugScore: rug?.score_normalised ?? rug?.score ?? null,
    jupVerified: Boolean(rug?.verification?.jup_verified),
    pairs,
    holdersTop,
    perps,
    unipcs,
    insiders: rug?.insiderNetworks?.[0]
      ? { accounts: num(rug.insiderNetworks[0].size), tokens: num(rug.insiderNetworks[0].tokenAmount) / 10 ** decimals }
      : null,
    verdict: { metadata, trade, note },
  };
}

async function loadDossier(mint: string): Promise<MintDossier> {
  const [rugPack, dexPack, rpc] = await Promise.all([rugReport(mint), dexPairs(mint), rpcMint(mint)]);
  const symbol = (rugPack.rug?.tokenMeta?.symbol || (isCanon(mint) ? "USELESS" : "")).toUpperCase();
  const perpPack = symbol ? await perpsFor(symbol) : { perps: [], sources: [] };
  return buildDossier(mint, rugPack.rug, dexPack.pairs, rpc, perpPack.perps, [
    ...rugPack.sources,
    ...dexPack.sources,
    ...rpc.sources,
    ...perpPack.sources,
  ]);
}

export async function fetchMint(raw?: string | null): Promise<MintDossier> {
  const mint = normMint(raw);
  return cached(`mint:${mint}`, 20_000, () => loadDossier(mint));
}
