export type PrivacyCoin = {
  sym: string;
  name: string;
  role: string;
  radar: "leader" | "reserve" | "under" | "adjacent" | "avoid";
  liveHint: string;
  thesis: string;
  levels: string;
};

export const PRIVACY: PrivacyCoin[] = [
  {
    sym: "ZEC",
    name: "Zcash",
    role: "Shielded L1. The tape leader.",
    radar: "leader",
    liveHint: "15:02 $1,169 +15%. Live ~$1,181, session high $1,230.",
    thesis:
      "This is not a meme rip. Privacy is being bid while BTC is flat (+0.2%). When ZEC expands on a Sunday with BTC asleep, it is sector rotation, not beta. Do not fade it like BULLA. Pullbacks that hold $1,000 are the swing. Daily close back under $980 kills the impulse.",
    levels: "Hold > $1,000 · invalidation daily close < $980 · stretch through $1,230 is trend, not a short",
  },
  {
    sym: "RAIL",
    name: "Railgun",
    role: "Shielded DeFi / private smart-contract layer.",
    radar: "under",
    liveHint: "Off the perp celebrity board. ~$2.36 +22% on the morning print.",
    thesis:
      "This is the name you asked for and the tape did not show. If ZEC is the headline, RAIL is the under-the-radar expression — privacy as a DeFi primitive, not a cypherpunk museum piece. Smaller, faster, easier to fake. Size down. It pays only if the ZEC bid is real.",
    levels: "Stalk while ZEC holds the rip. Cut if ZEC loses $1,000 on a closing basis",
  },
  {
    sym: "ZAMA",
    name: "Zama",
    role: "Fully homomorphic encryption. Privacy-adjacent compute.",
    radar: "adjacent",
    liveHint: "15:02 ranking +20% @ 0.0615. Live ~0.0606 +18%, high 0.0623.",
    thesis:
      "Sitting on the same board as BULLA. Completely different machine. FHE is the 'compute on encrypted data' narrative — AI + privacy, which is why it belongs next to RENDER, not next to CHILLGUY. Still young. Treat as a sector confirmation, not a 10x lotto. Do not short it as a meme because it printed +20% next to FLOCK.",
    levels: "Respect 0.050. Fade only if it loses the morning open with ZEC also rolling over",
  },
  {
    sym: "FIRO",
    name: "Firo",
    role: "Lelantus Spark. Old privacy L1, suddenly trending.",
    radar: "under",
    liveHint: "CoinGecko trending #1 this session, ~$0.96 +15%. Tiny mcap.",
    thesis:
      "Classic under-the-radar. When CG trending is a privacy L1 and ZEC is ripping, the sleeve is in play. Illiquid. This is a tell, not a core position. If you touch it, dust size, because a $18M coin does MARSCOIN things in both directions.",
    levels: "Tell, not a book. Dust or skip",
  },
  {
    sym: "XMR",
    name: "Monero",
    role: "The reserve. Default private money.",
    radar: "reserve",
    liveHint: "~$538, −1.3%. Not on the perp board. Quiet while ZEC runs.",
    thesis:
      "XMR lagging a ZEC impulse is the usual pattern — CEX-delisted, OTC-led, slower to reprice. It is the savings account of the sleeve, not the momentum name. Do not sell XMR to chase FIRO. Add only on ZEC confirmation, never because it 'hasn't moved yet' in isolation.",
    levels: "Core hold. Add on dips if ZEC holds $1,000. Not a breakout chase",
  },
  {
    sym: "NYM",
    name: "Nym",
    role: "Mixnet. Network-level privacy, not coin-level.",
    radar: "under",
    liveHint: "~$0.0195 +9%.",
    thesis:
      "Infrastructure, not a money-token. Moves with the privacy complex, not with memes. Small, easy to ignore, also easy to get stuck in. Pair with RAIL as the 'pipes' trade.",
    levels: "Basket only. No hero size",
  },
  {
    sym: "ROSE",
    name: "Oasis",
    role: "Confidential EVM. Sapphire.",
    radar: "under",
    liveHint: "~$0.0072 +7%.",
    thesis:
      "Been left for dead more than once. A +7% with ZEC +16% is participation, not leadership. Fine as a basket sleeve, not a single-name long.",
    levels: "Basket",
  },
  {
    sym: "DASH",
    name: "Dash",
    role: "Optional privacy, payments brand.",
    radar: "avoid",
    liveHint: "~$68, +0.7%. Not participating.",
    thesis:
      "If the bid is real privacy, Dash usually lags or ignores it. Do not force it into the sleeve because the name is old. Dead money vs ZEC/RAIL.",
    levels: "Ignore vs this rotation",
  },
  {
    sym: "SCRT",
    name: "Secret",
    role: "Secret contracts. Pioneer, diluted mindshare.",
    radar: "avoid",
    liveHint: "~$0.0073, −1.7%.",
    thesis:
      "Not invited to this party. ROSE/ZAMA took the confidential-compute mindshare. Leave it.",
    levels: "Skip",
  },
  {
    sym: "ARRR",
    name: "Pirate Chain",
    role: "Maximalist privacy fork.",
    radar: "under",
    liveHint: "Illiquid, off most perp boards.",
    thesis:
      "Pure-play, poor market structure. Same warning as FIRO: a tell if it rips, a trap if you size it.",
    levels: "Dust or skip",
  },
];

export const PRIVACY_NOTES = [
  "BTC +0.2% while ZEC +16% is the tell — this is idiosyncratic, not beta.",
  "Arthur Hayes / Maelstrom have been the loudest traditional voice on ZEC this cycle. Watch CT for that cluster, not for Ansem (SOL) or Justin Sun (TRON).",
  "Under-the-radar ranking: RAIL, FIRO, NYM, ZAMA (FHE), ROSE. Avoid forcing DASH/SCRT.",
  "Privacy is the opposite of a Sunday meme: books are thinner, but the bid is slower and stickier. Trail ZEC, do not scalp it like BULLA.",
  "If ZEC rolls over hard with BTC still bid, the sleeve was a squeeze. If ZEC holds while memes die, the sleeve is the trade.",
];
