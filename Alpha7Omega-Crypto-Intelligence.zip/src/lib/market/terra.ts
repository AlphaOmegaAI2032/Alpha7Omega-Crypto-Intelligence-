import { BRAND } from "@/lib/brand";

const UA = BRAND.ua;
const LCD_CLASSIC = "https://terra-classic-lcd.publicnode.com";
const LCD_PHOENIX = "https://terra-lcd.publicnode.com";
const GECKO = "https://api.coingecko.com/api/v3";
const GATE = "https://api.gateio.ws/api/v4";
const LLAMA = "https://api.llama.fi";
const DS = "https://api.dexscreener.com";

/** LuncScan genesis snapshot 13 May 2022 — post-hyperinflation supply. */
export const LUNC_GENESIS = 6_907_376_873_714;
const ULUNA = 1_000_000;

const WRAP_LUNA_BSC = "0x156ab3346823b651294766e23e6cf87254d68962";
const WRAP_LUNA_ETH = "0xbd31ea8212119f94a611fa969881cba3ea06fa3d";
const MEME_LUNA_BSC = "0xee132e984cafa9525a511e2033a1ec53b9f87777";
const MEME_LUNA_SOL = "sqyg5yer9quzzpr4gaoxiexfu3cybbebsq7gng6vudk";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn()
    .then((value) => {
      cache.set(key, { at: Date.now(), value });
      return value;
    })
    .catch((err) => {
      if (hit) return hit.value as T;
      throw err;
    });
}

async function getJson<T>(url: string, timeoutMs = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function numOrNull(v: unknown): number | null {
  if (v == null || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

function uluna(v: unknown): number {
  const n = typeof v === "string" ? Number(v.split(".")[0]) : Number(v);
  if (!Number.isFinite(n)) return 0;
  return n / ULUNA;
}

function settled<T>(s: PromiseSettledResult<T>): T | null {
  return s.status === "fulfilled" ? s.value : null;
}

export type TerraAsset = {
  id: "lunc" | "luna" | "ustc";
  symbol: string;
  name: string;
  geckoId: string;
  price: number;
  chg1h: number | null;
  chg24h: number | null;
  chg7d: number | null;
  chg30d: number | null;
  mcap: number;
  vol24: number;
  circ: number;
  total: number;
  rank: number | null;
  high24: number | null;
  low24: number | null;
  spark: number[] | null;
  turnover: number | null;
};

export type TerraVal = { moniker: string; tokens: number; share: number };

export type TerraChain = {
  id: "columbus-5" | "phoenix-1";
  label: string;
  token: "LUNC" | "LUNA";
  lcd: string;
  height: number;
  blockTime: string | null;
  txsInBlock: number;
  supply: number;
  ustcSupply: number | null;
  bonded: number;
  unbonding: number;
  bondedPct: number;
  unbondingPct: number;
  inflation: number;
  burnTax: number | null;
  burnSplit: number | null;
  validators: number;
  top10ValPct: number;
  topVals: TerraVal[];
  community: number;
  tvl: number;
};

export type TerraPerp = {
  contract: string;
  symbol: string;
  last: number;
  mark: number;
  index: number;
  change24: number | null;
  funding: number;
  leverageMax: number;
  oiTokens: number;
  oiUsd: number;
  volQuote: number;
  spark: number[];
  nextFunding: number | null;
};

export type Impostor = {
  chain: string;
  dex: string;
  symbol: string;
  name: string;
  address: string;
  quote: string;
  price: number;
  vol24: number;
  liq: number;
  fdv: number;
  chgH1: number | null;
  chgH24: number | null;
  buys: number;
  sells: number;
  createdAt: number | null;
  pair: string;
  url: string;
  cliff: number;
  tag: "meme-new" | "wrap-depeg" | "noise";
  verdict: "SHORT_HARD" | "FADE" | "WATCH" | "IGNORE";
  note: string;
};

export type TerraProto = {
  name: string;
  category: string;
  tvl: number;
  change1d: number | null;
  chains: string[];
};

export type TerraResponse = {
  assets: TerraAsset[];
  classic: TerraChain | null;
  phoenix: TerraChain | null;
  burned: number;
  burnedPct: number;
  genesis: number;
  perps: TerraPerp[];
  impostors: Impostor[];
  protocols: TerraProto[];
  notes: string[];
  read: string[];
  updatedAt: number;
};

type GeckoMarket = {
  id?: string;
  symbol?: string;
  name?: string;
  current_price?: number;
  market_cap?: number;
  total_volume?: number;
  circulating_supply?: number;
  total_supply?: number;
  market_cap_rank?: number;
  price_change_percentage_24h?: number;
  price_change_percentage_1h_in_currency?: number;
  price_change_percentage_7d_in_currency?: number;
  price_change_percentage_30d_in_currency?: number;
  high_24h?: number;
  low_24h?: number;
  sparkline_in_7d?: { price?: number[] };
};

type LcdBlock = {
  block?: {
    header?: { height?: string; time?: string; chain_id?: string };
    data?: { txs?: unknown[] };
  };
};

type LcdAmount = { amount?: { denom?: string; amount?: string } };
type LcdPool = { pool?: { bonded_tokens?: string; not_bonded_tokens?: string } };
type LcdInflation = { inflation?: string };
type LcdTax = { params?: { burn_tax_rate?: string } };
type LcdTreasury = { params?: { burn_tax_split?: string } };
type LcdCommunity = { pool?: Array<{ denom?: string; amount?: string }> };
type LcdVals = {
  validators?: Array<{ tokens?: string; description?: { moniker?: string } }>;
};

type GateTicker = {
  contract?: string;
  last?: string;
  mark_price?: string;
  index_price?: string;
  funding_rate?: string;
  change_percentage?: string;
  volume_24h_quote?: string;
  total_size?: string;
  quanto_multiplier?: string;
};
type GateContract = {
  name?: string;
  last_price?: string;
  mark_price?: string;
  index_price?: string;
  funding_rate?: string;
  leverage_max?: string;
  position_size?: number;
  quanto_multiplier?: string;
  funding_next_apply?: number;
};
type GateSpot = {
  currency_pair?: string;
  last?: string;
  change_percentage?: string;
  quote_volume?: string;
  high_24h?: string;
  low_24h?: string;
};
type GateCandle = { t?: number; c?: string; o?: string; v?: number };

type DsPair = {
  chainId?: string;
  dexId?: string;
  url?: string;
  pairAddress?: string;
  pairCreatedAt?: number;
  baseToken?: { address?: string; name?: string; symbol?: string };
  quoteToken?: { symbol?: string; name?: string };
  priceUsd?: string;
  volume?: { h24?: number };
  liquidity?: { usd?: number };
  fdv?: number;
  marketCap?: number;
  priceChange?: { h1?: number; h24?: number };
  txns?: { h24?: { buys?: number; sells?: number } };
};

function downSpark(arr: number[] | undefined, n = 42): number[] | null {
  if (!arr || arr.length < 8) return null;
  const clean = arr.filter((x) => Number.isFinite(x));
  if (clean.length < 8) return null;
  const step = Math.max(1, Math.floor(clean.length / n));
  const out: number[] = [];
  for (let i = 0; i < clean.length; i += step) out.push(clean[i]);
  return out.slice(-n);
}

function hydrateAsset(
  a: TerraAsset,
  opts: { perp?: TerraPerp | null; supply?: number; spot?: GateSpot | null },
) {
  const spotLast = num(opts.spot?.last);
  const perpLast = opts.perp?.last ?? 0;
  if (!a.price) a.price = spotLast || perpLast;
  if (a.chg24h == null) a.chg24h = numOrNull(opts.spot?.change_percentage) ?? opts.perp?.change24 ?? null;
  if (!a.vol24) a.vol24 = num(opts.spot?.quote_volume) || opts.perp?.volQuote || 0;
  if (a.high24 == null) a.high24 = numOrNull(opts.spot?.high_24h);
  if (a.low24 == null) a.low24 = numOrNull(opts.spot?.low_24h);
  if (!a.total && opts.supply) a.total = opts.supply;
  if (!a.circ && opts.supply) a.circ = opts.supply;
  if (!a.mcap && a.price && (a.circ || opts.supply)) a.mcap = a.price * (a.circ || opts.supply || 0);
  if (a.turnover == null && a.mcap > 0 && a.vol24 > 0) a.turnover = a.vol24 / a.mcap;
  if ((!a.spark || a.spark.length < 8) && opts.perp?.spark && opts.perp.spark.length >= 8) a.spark = opts.perp.spark;
}

async function lcdChain(
  id: "columbus-5" | "phoenix-1",
  lcd: string,
  label: string,
  token: "LUNC" | "LUNA",
  tvl: number,
): Promise<TerraChain> {
  const isClassic = id === "columbus-5";
  const [blkS, supS, ustS, poolS, infS, taxS, treS, comS, valS] = await Promise.allSettled([
    getJson<LcdBlock>(`${lcd}/cosmos/base/tendermint/v1beta1/blocks/latest`, 10_000),
    getJson<LcdAmount>(`${lcd}/cosmos/bank/v1beta1/supply/by_denom?denom=uluna`, 10_000),
    isClassic
      ? getJson<LcdAmount>(`${lcd}/cosmos/bank/v1beta1/supply/by_denom?denom=uusd`, 10_000)
      : Promise.resolve(null),
    getJson<LcdPool>(`${lcd}/cosmos/staking/v1beta1/pool`, 10_000),
    getJson<LcdInflation>(`${lcd}/cosmos/mint/v1beta1/inflation`, 8_000),
    isClassic ? getJson<LcdTax>(`${lcd}/terra/tax/v1beta1/params`, 8_000) : Promise.resolve(null),
    isClassic ? getJson<LcdTreasury>(`${lcd}/terra/treasury/v1beta1/params`, 8_000) : Promise.resolve(null),
    getJson<LcdCommunity>(`${lcd}/cosmos/distribution/v1beta1/community_pool`, 8_000),
    getJson<LcdVals>(`${lcd}/cosmos/staking/v1beta1/validators?status=BOND_STATUS_BONDED&pagination.limit=200`, 12_000),
  ]);

  const blk = settled(blkS);
  const header = blk?.block?.header;
  const supply = uluna(settled(supS)?.amount?.amount);
  const ustcSupply = isClassic ? uluna(settled(ustS as PromiseSettledResult<LcdAmount | null>)?.amount?.amount) : null;
  const pool = settled(poolS)?.pool;
  const bonded = uluna(pool?.bonded_tokens);
  const unbonding = uluna(pool?.not_bonded_tokens);
  const inflation = num(settled(infS)?.inflation);
  const burnTax = isClassic ? numOrNull(settled(taxS as PromiseSettledResult<LcdTax | null>)?.params?.burn_tax_rate) : null;
  const burnSplit = isClassic
    ? numOrNull(settled(treS as PromiseSettledResult<LcdTreasury | null>)?.params?.burn_tax_split)
    : null;
  const communityCoin = (settled(comS)?.pool || []).find((c) => c.denom === "uluna");
  const community = uluna(communityCoin?.amount);
  const vals = settled(valS)?.validators || [];
  const tot = vals.reduce((s, v) => s + uluna(v.tokens), 0) || 1;
  const ranked = [...vals].sort((a, b) => uluna(b.tokens) - uluna(a.tokens));
  const top10 = ranked.slice(0, 10).reduce((s, v) => s + uluna(v.tokens), 0);
  const topVals = ranked.slice(0, 6).map((v) => ({
    moniker: (v.description?.moniker || "validator").slice(0, 42),
    tokens: uluna(v.tokens),
    share: tot > 0 ? (uluna(v.tokens) / tot) * 100 : 0,
  }));

  return {
    id,
    label,
    token,
    lcd,
    height: num(header?.height),
    blockTime: header?.time || null,
    txsInBlock: (blk?.block?.data?.txs || []).length,
    supply,
    ustcSupply,
    bonded,
    unbonding,
    bondedPct: supply > 0 ? (bonded / supply) * 100 : 0,
    unbondingPct: supply > 0 ? (unbonding / supply) * 100 : 0,
    inflation: inflation * 100,
    burnTax: burnTax != null ? burnTax * 100 : null,
    burnSplit: burnSplit != null ? burnSplit * 100 : null,
    validators: vals.length,
    top10ValPct: (top10 / tot) * 100,
    topVals,
    community,
    tvl,
  };
}

function assetFromGecko(row: GeckoMarket | undefined, fallback: TerraAsset): TerraAsset {
  if (!row) return fallback;
  const price = num(row.current_price);
  const mcap = num(row.market_cap);
  const vol24 = num(row.total_volume);
  return {
    ...fallback,
    name: row.name || fallback.name,
    price: price || fallback.price,
    chg1h: numOrNull(row.price_change_percentage_1h_in_currency),
    chg24h: numOrNull(row.price_change_percentage_24h),
    chg7d: numOrNull(row.price_change_percentage_7d_in_currency),
    chg30d: numOrNull(row.price_change_percentage_30d_in_currency),
    mcap,
    vol24,
    circ: num(row.circulating_supply),
    total: num(row.total_supply),
    rank: row.market_cap_rank ?? null,
    high24: numOrNull(row.high_24h),
    low24: numOrNull(row.low_24h),
    spark: downSpark(row.sparkline_in_7d?.price),
    turnover: mcap > 0 ? vol24 / mcap : null,
  };
}

function classifyPair(p: DsPair, luncPx: number): Impostor | null {
  const base = p.baseToken;
  if (!base?.symbol || !p.pairAddress) return null;
  const addr = (base.address || "").toLowerCase();
  const name = base.name || base.symbol;
  const chain = p.chainId || "";
  const liq = num(p.liquidity?.usd);
  const vol24 = num(p.volume?.h24);
  const price = num(p.priceUsd);
  const fdv = num(p.fdv);
  const chgH24 = numOrNull(p.priceChange?.h24);
  const chgH1 = numOrNull(p.priceChange?.h1);
  const createdAt = p.pairCreatedAt ?? null;
  const ageH = createdAt ? (Date.now() - createdAt) / 3_600_000 : null;
  const cliff = liq > 0 ? vol24 / liq : 0;

  if (liq >= 8_000_000 && cliff < 0.05) return null;
  if (vol24 < 40_000 && liq < 20_000) return null;
  if (vol24 < 100_000 && cliff < 8) return null;
  if (chain === "robinhood") return null;
  if (/virtuals/i.test(name)) return null;

  const isWrap =
    addr === WRAP_LUNA_BSC ||
    addr === WRAP_LUNA_ETH ||
    (price > 0 && luncPx > 0 && Math.abs(price / luncPx - 1) < 1.6 && price < 0.001 && ageH != null && ageH > 24 * 30);

  const isNewMeme =
    addr === MEME_LUNA_BSC ||
    addr === MEME_LUNA_SOL ||
    ((ageH != null && ageH < 48) && (chgH24 ?? 0) >= 80 && liq < 500_000 && vol24 > 500_000);

  let tag: Impostor["tag"] = "noise";
  let verdict: Impostor["verdict"] = "WATCH";
  let note = "Name collision. Not columbus-5, not phoenix-1.";

  if (isNewMeme) {
    tag = "meme-new";
    verdict = "SHORT_HARD";
    note = `Ticker snatch. Pool ${liq >= 1000 ? `$${(liq / 1000).toFixed(0)}k` : `$${liq.toFixed(0)}`} vs ${cliff.toFixed(0)}× 24h turnover. Hours-old mint — the inventory is the pool.`;
  } else if (isWrap && luncPx > 0 && price > luncPx * 1.25 && cliff >= 20) {
    tag = "wrap-depeg";
    verdict = "FADE";
    const prem = ((price / luncPx - 1) * 100).toFixed(0);
    note = `Legacy wrapped LUNA trading ${prem}% over native LUNC. Thin pool, not the L1.`;
  } else if (cliff >= 40 && (chgH24 ?? 0) >= 40 && liq < 400_000) {
    tag = "meme-new";
    verdict = "SHORT_HARD";
    note = `CLIFF ${cliff.toFixed(0)}×. Same class as a listing pop with no L1 behind it.`;
  } else if (cliff < 2 && Math.abs(chgH24 ?? 0) < 8) {
    return null;
  } else {
    verdict = "WATCH";
    note = "Same ticker, different mint. Do not size it as Terra.";
  }

  return {
    chain,
    dex: p.dexId || "",
    symbol: base.symbol.toUpperCase(),
    name,
    address: base.address || "",
    quote: p.quoteToken?.symbol || "",
    price,
    vol24,
    liq,
    fdv,
    chgH1,
    chgH24,
    buys: num(p.txns?.h24?.buys),
    sells: num(p.txns?.h24?.sells),
    createdAt,
    pair: p.pairAddress,
    url: p.url || "",
    cliff,
    tag,
    verdict,
    note,
  };
}

function uniqImpostors(rows: Impostor[]): Impostor[] {
  const best = new Map<string, Impostor>();
  for (const r of rows) {
    const key = `${r.chain}:${r.address.toLowerCase()}`;
    const prev = best.get(key);
    if (!prev || r.vol24 > prev.vol24) best.set(key, r);
  }
  return [...best.values()].sort((a, b) => b.vol24 - a.vol24).slice(0, 8);
}

function buildRead(args: {
  lunc: TerraAsset;
  luna: TerraAsset;
  classic: TerraChain | null;
  phoenix: TerraChain | null;
  burned: number;
  impostors: Impostor[];
  perps: TerraPerp[];
}): string[] {
  const { lunc, luna, classic, phoenix, burned, impostors, perps } = args;
  const hard = impostors.filter((i) => i.verdict === "SHORT_HARD");
  const wrap = impostors.find((i) => i.tag === "wrap-depeg");
  const luncPerp = perps.find((p) => p.symbol === "LUNC");
  const out: string[] = [];

  if (hard[0]) {
    const age = hard[0].createdAt ? `${Math.max(1, Math.round((Date.now() - hard[0].createdAt) / 3_600_000))}h old` : "fresh";
    out.push(
      `The tape on fire is not Terra. ${hard[0].chain} ${hard[0].symbol} (${hard[0].name}) is ${hard[0].chgH24 != null ? `${hard[0].chgH24 >= 0 ? "+" : ""}${hard[0].chgH24.toFixed(0)}%` : "parabolic"} on a $${(hard[0].liq / 1000).toFixed(0)}k pool, ${hard[0].cliff.toFixed(0)}× turnover, ${age}. SHORT_HARD the mint — not LUNC, not LUNA2.`,
    );
  } else {
    out.push("No hours-old LUNA mint is printing a CLIFF right now. Native LUNC/LUNA are the book.");
  }

  out.push(
    `Native LUNC is ${lunc.chg24h != null ? `${lunc.chg24h >= 0 ? "+" : ""}${lunc.chg24h.toFixed(1)}%` : "flat"} at $${lunc.price.toPrecision(3)}, mcap $${(lunc.mcap / 1e6).toFixed(0)}M. That is a burn-narrative grind, not a dump setup. Do not short the L1 hard.`,
  );

  if (classic) {
    out.push(
      `columbus-5 live: height ${classic.height.toLocaleString("en-US")}, supply ${(classic.supply / 1e12).toFixed(2)}T, bonded ${classic.bondedPct.toFixed(1)}%, burn tax ${classic.burnTax != null ? `${classic.burnTax.toFixed(1)}%` : "—"} (LCD), inflation 0. Cumulative burn since May 2022 genesis ${(burned / 1e9).toFixed(1)}B (${((burned / LUNC_GENESIS) * 100).toFixed(2)}%).`,
    );
  }

  out.push(
    `Native LUNA (phoenix-1) is ${luna.chg24h != null ? `${luna.chg24h >= 0 ? "+" : ""}${luna.chg24h.toFixed(1)}%` : "flat"} at $${luna.price.toFixed(4)}, mcap $${(luna.mcap / 1e6).toFixed(0)}M. ${phoenix ? `${phoenix.inflation.toFixed(0)}% inflation and ${phoenix.unbondingPct.toFixed(1)}% of supply sitting in the unbonding queue.` : "Thin L1."} Attention trade, not a CLIFF.`,
  );

  if (wrap) {
    out.push(
      `BSC/ETH wrapped "LUNA" is trading ${((wrap.price / Math.max(lunc.price, 1e-12) - 1) * 100).toFixed(0)}% over native LUNC on a $${(wrap.liq / 1000).toFixed(0)}k pool. FADE the wrap, not the columbus-5 coin.`,
    );
  }

  if (luncPerp) {
    out.push(
      `Gate LUNC perp OI $${(luncPerp.oiUsd / 1000).toFixed(0)}k — too small to be a crowded short. Funding ${((luncPerp.funding || 0) * 100).toFixed(3)}%. The casino floor is the DEX ticker snatch.`,
    );
  }

  return out;
}

export async function fetchTerra(): Promise<TerraResponse> {
  return cached("terra-desk-v3", 45_000, async () => {
    const notes: string[] = [];
    const [geckoS, chainsS, protoS, tickS, luncC, lunaC, dsLuna, dsLunc] = await Promise.allSettled([
      getJson<GeckoMarket[]>(
        `${GECKO}/coins/markets?vs_currency=usd&ids=terra-luna,terra-luna-2,terrausd&sparkline=true&price_change_percentage=1h,24h,7d,30d`,
      ),
      getJson<Array<{ name?: string; tvl?: number; tokenSymbol?: string }>>(`${LLAMA}/v2/chains`),
      getJson<Array<{ name?: string; category?: string; tvl?: number; change_1d?: number; chains?: string[] }>>(
        `${LLAMA}/protocols`,
      ),
      getJson<GateTicker[]>(`${GATE}/futures/usdt/tickers`),
      getJson<GateContract>(`${GATE}/futures/usdt/contracts/LUNC_USDT`),
      getJson<GateContract>(`${GATE}/futures/usdt/contracts/LUNA_USDT`),
      getJson<{ pairs?: DsPair[] }>(`${DS}/latest/dex/search?q=LUNA`),
      getJson<{ pairs?: DsPair[] }>(`${DS}/latest/dex/search?q=LUNC`),
    ]);

    const gecko = settled(geckoS) || [];
    if (gecko.length) notes.push(`Gecko ${gecko.length} quotes`);
    const byId = new Map(gecko.map((g) => [g.id, g]));

    const lunc = assetFromGecko(byId.get("terra-luna"), {
      id: "lunc",
      symbol: "LUNC",
      name: "Terra Classic",
      geckoId: "terra-luna",
      price: 0,
      chg1h: null,
      chg24h: null,
      chg7d: null,
      chg30d: null,
      mcap: 0,
      vol24: 0,
      circ: 0,
      total: 0,
      rank: null,
      high24: null,
      low24: null,
      spark: null,
      turnover: null,
    });
    const luna = assetFromGecko(byId.get("terra-luna-2"), {
      id: "luna",
      symbol: "LUNA",
      name: "Terra 2.0",
      geckoId: "terra-luna-2",
      price: 0,
      chg1h: null,
      chg24h: null,
      chg7d: null,
      chg30d: null,
      mcap: 0,
      vol24: 0,
      circ: 0,
      total: 0,
      rank: null,
      high24: null,
      low24: null,
      spark: null,
      turnover: null,
    });
    const ustc = assetFromGecko(byId.get("terrausd"), {
      id: "ustc",
      symbol: "USTC",
      name: "TerraClassicUSD",
      geckoId: "terrausd",
      price: 0,
      chg1h: null,
      chg24h: null,
      chg7d: null,
      chg30d: null,
      mcap: 0,
      vol24: 0,
      circ: 0,
      total: 0,
      rank: null,
      high24: null,
      low24: null,
      spark: null,
      turnover: null,
    });

    const llamaChains = settled(chainsS) || [];
    const tvlClassic = num(llamaChains.find((c) => /terra classic/i.test(c.name || ""))?.tvl);
    const tvlPhoenix = num(llamaChains.find((c) => /terra2/i.test(c.name || ""))?.tvl);
    if (llamaChains.length) notes.push("Llama chains");

    const [classicS, phoenixS, luncKl, lunaKl, luncSpotS, lunaSpotS, ustcSpotS] = await Promise.allSettled([
      lcdChain("columbus-5", LCD_CLASSIC, "Terra Classic", "LUNC", tvlClassic),
      lcdChain("phoenix-1", LCD_PHOENIX, "Terra 2.0", "LUNA", tvlPhoenix),
      getJson<GateCandle[]>(`${GATE}/futures/usdt/candlesticks?contract=LUNC_USDT&interval=15m&limit=96`, 10_000),
      getJson<GateCandle[]>(`${GATE}/futures/usdt/candlesticks?contract=LUNA_USDT&interval=15m&limit=96`, 10_000),
      getJson<GateSpot[]>(`${GATE}/spot/tickers?currency_pair=LUNC_USDT`, 8_000),
      getJson<GateSpot[]>(`${GATE}/spot/tickers?currency_pair=LUNA_USDT`, 8_000),
      getJson<GateSpot[]>(`${GATE}/spot/tickers?currency_pair=USTC_USDT`, 8_000),
    ]);

    const classic = settled(classicS);
    const phoenix = settled(phoenixS);
    if (classic) notes.push(`LCD columbus-5 #${classic.height}`);
    if (phoenix) notes.push(`LCD phoenix-1 #${phoenix.height}`);
    if (classic?.supply && !lunc.total) lunc.total = classic.supply;
    if (phoenix?.supply && !luna.total) luna.total = phoenix.supply;

    const tickers = settled(tickS) || [];
    const perps: TerraPerp[] = [];
    for (const [sym, contract, row, kl] of [
      ["LUNC", settled(luncC), tickers.find((t) => t.contract === "LUNC_USDT"), settled(luncKl)],
      ["LUNA", settled(lunaC), tickers.find((t) => t.contract === "LUNA_USDT"), settled(lunaKl)],
    ] as const) {
      if (!row && !contract) continue;
      const last = num(row?.last) || num(contract?.last_price);
      const mark = num(row?.mark_price) || num(contract?.mark_price) || last;
      const quanto = num(row?.quanto_multiplier) || num(contract?.quanto_multiplier) || 1;
      const pos = num(contract?.position_size) || num(row?.total_size);
      const oiTokens = pos * quanto;
      perps.push({
        contract: `${sym}_USDT`,
        symbol: sym,
        last,
        mark,
        index: num(row?.index_price) || num(contract?.index_price) || last,
        change24: numOrNull(row?.change_percentage),
        funding: num(row?.funding_rate) || num(contract?.funding_rate),
        leverageMax: num(contract?.leverage_max),
        oiTokens,
        oiUsd: oiTokens * last,
        volQuote: num(row?.volume_24h_quote),
        spark: (kl || []).map((c) => num(c.c)).filter((x) => x > 0),
        nextFunding: contract?.funding_next_apply ? contract.funding_next_apply * 1000 : null,
      });
    }
    if (perps.length) notes.push(`Gate ${perps.length} perps`);

    const spotOf = (s: PromiseSettledResult<GateSpot[] | null>) => settled(s)?.[0] ?? null;
    hydrateAsset(lunc, { perp: perps.find((x) => x.symbol === "LUNC"), supply: classic?.supply, spot: spotOf(luncSpotS) });
    hydrateAsset(luna, { perp: perps.find((x) => x.symbol === "LUNA"), supply: phoenix?.supply, spot: spotOf(lunaSpotS) });
    hydrateAsset(ustc, { supply: classic?.ustcSupply ?? undefined, spot: spotOf(ustcSpotS) });
    if (!gecko.length) notes.push("Gecko miss — Gate + LCD mcap");

    const dsPairs = [...(settled(dsLuna)?.pairs || []), ...(settled(dsLunc)?.pairs || [])];
    if (dsPairs.length) notes.push(`DexScreener ${dsPairs.length} pairs`);
    const impostors = uniqImpostors(
      dsPairs
        .map((p) => classifyPair(p, lunc.price))
        .filter((x): x is Impostor => !!x && x.verdict !== "IGNORE"),
    );

    const protoRaw = settled(protoS) || [];
    const protocols = protoRaw
      .filter((p) => {
        const chains = p.chains || [];
        const tvl = num(p.tvl);
        if (tvl <= 0) return false;
        return chains.some((c) => /terra classic|terra2/i.test(c)) && tvl < 80_000_000;
      })
      .map((p) => ({
        name: p.name || "",
        category: p.category || "other",
        tvl: num(p.tvl),
        change1d: p.change_1d != null ? num(p.change_1d) : null,
        chains: (p.chains || []).filter((c) => /terra/i.test(c)).slice(0, 4),
      }))
      .sort((a, b) => b.tvl - a.tvl)
      .slice(0, 10);

    const chainSupply = classic?.supply || lunc.total || 0;
    const burned = chainSupply > 0 ? Math.max(0, LUNC_GENESIS - chainSupply) : 0;

    const read = buildRead({ lunc, luna, classic, phoenix, burned, impostors, perps });

    return {
      assets: [lunc, luna, ustc],
      classic,
      phoenix,
      burned,
      burnedPct: LUNC_GENESIS > 0 ? (burned / LUNC_GENESIS) * 100 : 0,
      genesis: LUNC_GENESIS,
      perps,
      impostors,
      protocols,
      notes,
      read,
      updatedAt: Date.now(),
    };
  });
}
