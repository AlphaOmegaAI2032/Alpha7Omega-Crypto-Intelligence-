import { binanceSymbol, classifySymbol, findKnown, KNOWN, normSym } from "./known";
import { scoreBreakout, scoreFade } from "./score";
import type {
  BreakoutHit,
  BreakoutResponse,
  DexSnapshot,
  PerpSnapshot,
  ScoredMover,
  TapeResponse,
} from "./types";

const UA = "Alpha7Omega-CryptoIntelligence/2.0";
const BN = "https://www.binance.com";
const DS = "https://api.dexscreener.com";

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();
const lastDex = new Map<string, DexSnapshot>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn().then((value) => {
    cache.set(key, { at: Date.now(), value });
    return value;
  });
}

async function getJson<T>(url: string, timeoutMs = 12_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function numOrNull(v: unknown): number | null {
  if (v == null || v === "") return null;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : null;
}

type DexPair = {
  chainId?: string;
  dexId?: string;
  url?: string;
  pairAddress?: string;
  labels?: string[];
  baseToken?: { address?: string; name?: string; symbol?: string };
  quoteToken?: { symbol?: string };
  priceNative?: string;
  priceUsd?: string;
  txns?: Record<string, { buys?: number; sells?: number }>;
  volume?: Record<string, number>;
  priceChange?: Record<string, number>;
  liquidity?: { usd?: number };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
  info?: { imageUrl?: string };
};

function pairQuality(p: DexPair): number {
  const liq = num(p.liquidity?.usd);
  const vol = num(p.volume?.h24) + num(p.volume?.h1);
  const fdv = num(p.fdv);
  if (liq <= 0) return -1;
  if (fdv > 0 && liq > fdv * 0.8) return vol * 0.01;
  if (vol < 50 && liq > 5_000_000) return -1;
  return vol * 2 + liq * 0.04;
}

function pairToDex(p: DexPair): DexSnapshot | null {
  const base = p.baseToken;
  if (!base?.symbol || !p.pairAddress) return null;
  const tx = p.txns || {};
  const vol = p.volume || {};
  const chg = p.priceChange || {};
  return {
    chain: p.chainId || "",
    dex: p.dexId || "",
    pairAddress: p.pairAddress,
    tokenAddress: base.address || "",
    name: base.name || base.symbol,
    symbol: base.symbol,
    priceUsd: numOrNull(p.priceUsd),
    priceNative: numOrNull(p.priceNative),
    changeM5: numOrNull(chg.m5),
    changeH1: numOrNull(chg.h1),
    changeH6: numOrNull(chg.h6),
    changeH24: numOrNull(chg.h24),
    volumeM5: num(vol.m5),
    volumeH1: num(vol.h1),
    volumeH6: num(vol.h6),
    volumeH24: num(vol.h24),
    liquidityUsd: num(p.liquidity?.usd),
    fdv: numOrNull(p.fdv),
    marketCap: numOrNull(p.marketCap),
    buysM5: num(tx.m5?.buys),
    sellsM5: num(tx.m5?.sells),
    buysH1: num(tx.h1?.buys),
    sellsH1: num(tx.h1?.sells),
    buysH24: num(tx.h24?.buys),
    sellsH24: num(tx.h24?.sells),
    pairCreatedAt: p.pairCreatedAt ?? null,
    url: p.url || "",
    imageUrl: p.info?.imageUrl || null,
  };
}

function bestPair(pairs: DexPair[], preferSymbol?: string): DexPair | null {
  const usable = pairs.filter((p) => p.pairAddress && pairQuality(p) >= 0);
  if (!usable.length) return null;
  const target = preferSymbol?.toUpperCase();
  const matched = target
    ? usable.filter((p) => (p.baseToken?.symbol || "").toUpperCase() === target)
    : usable;
  const pool = matched.length ? matched : usable;
  const prices = pool
    .map((p) => Number(p.priceUsd))
    .filter((n) => Number.isFinite(n) && n > 0)
    .sort((a, b) => a - b);
  const mid = prices[Math.floor(prices.length / 2)];
  const sane =
    mid && prices.length >= 2
      ? pool.filter((p) => {
          const px = Number(p.priceUsd);
          return px > 0 && px > mid * 0.2 && px < mid * 5;
        })
      : pool;
  const ranked = sane.length ? sane : pool;
  ranked.sort((a, b) => pairQuality(b) - pairQuality(a));
  return ranked[0] || null;
}

export async function dexByToken(address: string, preferSymbol?: string): Promise<DexSnapshot | null> {
  const j = await cached(`tok:${address}`, 12_000, () =>
    getJson<{ pairs?: DexPair[] }>(`${DS}/latest/dex/tokens/${address}`),
  );
  const p = bestPair(j.pairs || [], preferSymbol);
  return p ? pairToDex(p) : null;
}

export async function dexByPair(chain: string, pair: string): Promise<DexSnapshot | null> {
  const j = await cached(`pair:${chain}:${pair}`, 12_000, () =>
    getJson<{ pair?: DexPair; pairs?: DexPair[] }>(`${DS}/latest/dex/pairs/${chain}/${pair}`),
  );
  const p = j.pair || (j.pairs || [])[0];
  return p ? pairToDex(p) : null;
}

export async function dexSearch(q: string, preferSymbol?: string): Promise<DexSnapshot | null> {
  const j = await cached(`q:${q}`, 20_000, () =>
    getJson<{ pairs?: DexPair[] }>(`${DS}/latest/dex/search?q=${encodeURIComponent(q)}`),
  );
  const p = bestPair(j.pairs || [], preferSymbol || q);
  return p ? pairToDex(p) : null;
}

async function dexMany(addresses: string[]): Promise<Map<string, DexSnapshot>> {
  const out = new Map<string, DexSnapshot>();
  if (!addresses.length) return out;
  const evm = addresses.filter((a) => a.startsWith("0x"));
  const rest = addresses.filter((a) => !a.startsWith("0x"));
  for (const group of [evm, rest]) {
    for (let i = 0; i < group.length; i += 25) {
      const chunk = group.slice(i, i + 25).join(",");
      try {
        const j = await cached(`toks:${chunk}`, 12_000, () =>
          getJson<{ pairs?: DexPair[] }>(`${DS}/latest/dex/tokens/${chunk}`),
        );
        const byToken = new Map<string, DexPair[]>();
        for (const p of j.pairs || []) {
          const addr = (p.baseToken?.address || "").toLowerCase();
          if (!addr) continue;
          const arr = byToken.get(addr) || [];
          arr.push(p);
          byToken.set(addr, arr);
        }
        for (const [addr, pairs] of byToken) {
          const best = bestPair(pairs);
          const snap = best ? pairToDex(best) : null;
          if (snap) out.set(addr, snap);
        }
      } catch {
        /* callers still have perp side */
      }
    }
  }
  return out;
}

type GateTicker = {
  contract: string;
  last: string;
  mark_price: string;
  index_price: string;
  change_percentage: string;
  high_24h: string;
  low_24h: string;
  volume_24h_quote: string;
  funding_rate: string;
  total_size: string;
  quanto_multiplier: string;
};

type BnTicker = {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  highPrice: string;
  lowPrice: string;
  quoteVolume: string;
  count?: number;
};

type BnPrem = {
  symbol: string;
  markPrice: string;
  indexPrice: string;
  lastFundingRate: string;
  nextFundingTime?: number;
};

function gateToPerp(t: GateTicker): PerpSnapshot {
  const last = num(t.last);
  const mark = num(t.mark_price) || last;
  const quanto = num(t.quanto_multiplier) || 1;
  const size = num(t.total_size);
  return {
    venue: "gate",
    contract: t.contract,
    last,
    mark,
    index: num(t.index_price) || last,
    change24h: num(t.change_percentage),
    high24h: num(t.high_24h),
    low24h: num(t.low_24h),
    volumeQuote: num(t.volume_24h_quote),
    funding: num(t.funding_rate),
    oiUsd: size * mark * quanto,
  };
}

async function fetchBinanceOi(symbols: string[]): Promise<Map<string, number>> {
  const out = new Map<string, number>();
  const uniq = [...new Set(symbols)].filter(Boolean);
  for (let i = 0; i < uniq.length; i += 12) {
    const slice = uniq.slice(i, i + 12);
    await Promise.all(
      slice.map(async (s) => {
        try {
          const j = await cached(`oi:${s}`, 20_000, () =>
            getJson<{ openInterest?: string }>(
              `${BN}/fapi/v1/openInterest?symbol=${encodeURIComponent(s)}`,
              8_000,
            ),
          );
          out.set(s, num(j.openInterest));
        } catch {
          /* skip */
        }
      }),
    );
  }
  return out;
}

export async function fetchTape(): Promise<TapeResponse> {
  return cached("tape", 8_000, async () => {
    const notes: string[] = [];
    const movers: ScoredMover[] = [];
    const seen = new Set<string>();

    const [bnT, bnP, gateT] = await Promise.allSettled([
      getJson<BnTicker[]>(`${BN}/fapi/v1/ticker/24hr`),
      getJson<BnPrem[]>(`${BN}/fapi/v1/premiumIndex`),
      getJson<GateTicker[]>("https://api.gateio.ws/api/v4/futures/usdt/tickers"),
    ]);

    const bnTickers = bnT.status === "fulfilled" ? bnT.value : [];
    const bnPrem = bnP.status === "fulfilled" ? bnP.value : [];
    const gateTickers = gateT.status === "fulfilled" ? gateT.value : [];
    if (bnT.status === "fulfilled") notes.push(`Binance USD-M ${bnTickers.length} perps`);
    else notes.push("Binance tape blocked — falling back to Gate");
    if (gateT.status === "fulfilled") notes.push(`Gate ${gateTickers.length} perps`);

    const premBy = new Map(bnPrem.map((p) => [p.symbol, p]));
    const gateBy = new Map(gateTickers.map((t) => [t.contract, t]));
    const gateByBase = new Map(
      gateTickers.filter((t) => t.contract.endsWith("_USDT")).map((t) => [t.contract.replace(/_USDT$/, ""), t]),
    );

    const usdt = bnTickers.filter((t) => t.symbol.endsWith("USDT"));
    const hot = [...usdt].sort((a, b) => Math.abs(num(b.priceChangePercent)) - Math.abs(num(a.priceChangePercent)));

    const wantedBn = new Set<string>([
      ...KNOWN.map(binanceSymbol),
      ...hot.slice(0, 50).map((t) => t.symbol),
    ]);

    const oiNeed: string[] = [];
    for (const sym of wantedBn) {
      const base = normSym(sym);
      const known = findKnown(base, sym);
      const kind = classifySymbol(base, known);
      if (known || kind === "meme" || kind === "unknown") oiNeed.push(sym);
    }
    const oiContracts = bnTickers.length ? await fetchBinanceOi(oiNeed) : new Map<string, number>();

    const tokenAddrs = KNOWN.map((k) => k.address).filter((a): a is string => !!a);
    const dexByAddr = await dexMany(tokenAddrs);

    const pairSnaps = new Map<string, DexSnapshot>();
    await Promise.all(
      KNOWN.filter((k) => k.pair && k.chain).map(async (k) => {
        try {
          const snap = await dexByPair(k.chain, k.pair as string);
          if (snap) pairSnaps.set(k.symbol, snap);
        } catch {
          /* ignore */
        }
      }),
    );
    await Promise.all(
      KNOWN.filter((k) => !k.address && !pairSnaps.has(k.symbol)).map(async (k) => {
        try {
          const snap = await dexSearch(k.symbol, k.symbol);
          if (snap) pairSnaps.set(k.symbol, snap);
        } catch {
          /* ignore */
        }
      }),
    );

    await Promise.all(
      KNOWN.filter((k) => !!k.address).map(async (k) => {
        const addr = (k.address as string).toLowerCase();
        if (dexByAddr.has(addr) || pairSnaps.has(k.symbol)) return;
        try {
          const snap = await dexByToken(k.address as string, k.symbol);
          if (snap) {
            dexByAddr.set(addr, snap);
            pairSnaps.set(k.symbol, snap);
          }
        } catch {
          /* ignore */
        }
      }),
    );

    const pickDex = (known: ReturnType<typeof findKnown>, symbol: string): DexSnapshot | null => {
      let dex: DexSnapshot | null = null;
      if (known?.address) {
        const hit = dexByAddr.get(known.address.toLowerCase());
        if (hit) dex = hit;
        if (!dex) {
          for (const [k, v] of dexByAddr) {
            if (k.toLowerCase() === known.address.toLowerCase()) dex = v;
          }
        }
      }
      if (!dex) dex = (known && pairSnaps.get(known.symbol)) || pairSnaps.get(symbol) || null;
      if (dex) lastDex.set(symbol, dex);
      else dex = lastDex.get(symbol) || null;
      return dex;
    };

    const bnBy = new Map(usdt.map((t) => [t.symbol, t]));

    for (const contract of wantedBn) {
      const t = bnBy.get(contract);
      const prem = premBy.get(contract);
      const base = normSym(contract);
      const known = findKnown(base, contract);
      const kind = classifySymbol(base, known);
      const symbol = known?.symbol || base;

      let perp: PerpSnapshot | null = null;
      if (t) {
        const last = num(t.lastPrice);
        const mark = num(prem?.markPrice) || last;
        const oiC = oiContracts.get(contract) ?? 0;
        perp = {
          venue: "binance",
          contract,
          last,
          mark,
          index: num(prem?.indexPrice) || last,
          change24h: num(t.priceChangePercent),
          high24h: num(t.highPrice),
          low24h: num(t.lowPrice),
          volumeQuote: num(t.quoteVolume),
          funding: num(prem?.lastFundingRate),
          oiUsd: oiC * mark,
          trades: t.count,
          nextFunding: prem?.nextFundingTime ?? null,
        };
      } else {
        const g = gateBy.get(`${symbol}_USDT`) || gateByBase.get(symbol) || (known?.gate ? gateBy.get(known.gate) : undefined);
        if (g) perp = gateToPerp(g);
      }
      if (!perp && !known) continue;
      if (seen.has(symbol)) continue;
      seen.add(symbol);

      const dex = pickDex(known, symbol);
      const scored = scoreFade({
        symbol,
        kind,
        flags: known?.flags || [],
        note: known?.note || "",
        invalidation: known?.invalidation,
        perp,
        dex,
      });
      movers.push({
        id: contract || symbol,
        name: dex?.name || known?.symbol || symbol,
        watchlist: !!known,
        ...scored,
      });
    }

    for (const k of KNOWN) {
      if (seen.has(k.symbol)) continue;
      const dex = pickDex(k, k.symbol);
      const g = k.gate ? gateBy.get(k.gate) : undefined;
      if (!dex && !g) continue;
      seen.add(k.symbol);
      const scored = scoreFade({
        symbol: k.symbol,
        kind: k.kind,
        flags: k.flags,
        note: k.note,
        invalidation: k.invalidation,
        perp: g ? gateToPerp(g) : null,
        dex,
      });
      movers.push({ id: k.symbol, name: dex?.name || k.symbol, watchlist: true, ...scored });
    }

    movers.sort((a, b) => b.score - a.score || (b.perp?.change24h || 0) - (a.perp?.change24h || 0));
    notes.push("OI in USD = Binance contracts × mark. Spot from DexScreener.");
    return { updatedAt: Date.now(), movers, sourceNotes: notes };
  });
}

type GeckoPool = {
  id?: string;
  attributes?: {
    name?: string;
    address?: string;
    pool_created_at?: string;
  };
  relationships?: { base_token?: { data?: { id?: string } } };
};

type PumpCoin = {
  mint: string;
  name: string;
  symbol: string;
  usd_market_cap?: number;
  created_timestamp?: number;
  image_uri?: string;
};

type Boost = { chainId?: string; tokenAddress?: string; amount?: number; totalAmount?: number; url?: string };

function allowedChain(id?: string) {
  if (!id) return true;
  return ["solana", "bsc", "base", "ethereum", "pulsechain", "ton", "arbitrum", "polygon", "robinhood"].includes(id);
}

export async function fetchBreakouts(): Promise<BreakoutResponse> {
  return cached("breakouts", 15_000, async () => {
    const notes: string[] = [];
    const hits: BreakoutHit[] = [];
    const seen = new Set<string>();

    const [pump, pumpLive, trending, boosts, boostTop, profiles, newSol, newBsc, cto] = await Promise.allSettled([
      getJson<PumpCoin[]>(
        "https://frontend-api-v3.pump.fun/coins?offset=0&limit=30&sort=last_trade_timestamp&order=DESC&includeNsfw=false",
      ),
      getJson<PumpCoin[]>("https://frontend-api-v3.pump.fun/coins/currently-live?offset=0&limit=20"),
      getJson<{ data?: GeckoPool[] }>("https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?page=1"),
      getJson<Boost[]>(`${DS}/token-boosts/latest/v1`),
      getJson<Boost[]>(`${DS}/token-boosts/top/v1`),
      getJson<Boost[]>(`${DS}/token-profiles/latest/v1`),
      getJson<{ data?: GeckoPool[] }>("https://api.geckoterminal.com/api/v2/networks/solana/new_pools?page=1"),
      getJson<{ data?: GeckoPool[] }>("https://api.geckoterminal.com/api/v2/networks/bsc/new_pools?page=1"),
      getJson<Boost[]>(`${DS}/community-takeovers/latest/v1`),
    ]);

    type Hydra = {
      source: BreakoutHit["source"];
      address: string;
      chain?: string;
      boost?: number;
      extra?: Partial<BreakoutHit>;
    };
    const hydrate: Hydra[] = [];

    const takePump = (list: PumpCoin[], source: BreakoutHit["source"], n: number, label: string) => {
      notes.push(`${label} ${list.length}`);
      for (const c of list.slice(0, n)) {
        if (!c.mint) continue;
        hydrate.push({
          source,
          address: c.mint,
          extra: {
            name: c.name,
            symbol: c.symbol,
            createdAt: c.created_timestamp
              ? c.created_timestamp > 1e12
                ? c.created_timestamp
                : c.created_timestamp * 1000
              : null,
            pumpMc: c.usd_market_cap ?? null,
            imageUrl: c.image_uri ?? null,
          },
        });
      }
    };

    if (pump.status === "fulfilled") takePump(pump.value, "pump", 18, "Pump.fun");
    else notes.push("Pump.fun unavailable");
    if (pumpLive.status === "fulfilled") {
      const rows = Array.isArray(pumpLive.value) ? pumpLive.value : [];
      takePump(rows, "live", 12, "Pump live");
    }

    const takeGecko = (rows: GeckoPool[], source: BreakoutHit["source"], n: number, label: string) => {
      notes.push(`${label} ${rows.length}`);
      for (const row of rows.slice(0, n)) {
        const id = row.relationships?.base_token?.data?.id || "";
        const addr = id.includes("_") ? id.split("_").slice(1).join("_") : row.attributes?.address;
        if (!addr) continue;
        hydrate.push({
          source,
          address: addr,
          extra: {
            name: row.attributes?.name || addr.slice(0, 6),
            createdAt: row.attributes?.pool_created_at ? Date.parse(row.attributes.pool_created_at) : null,
          },
        });
      }
    };
    if (trending.status === "fulfilled") takeGecko(trending.value.data || [], "trending", 12, "Gecko trending");
    else notes.push("Gecko trending delayed");
    if (newSol.status === "fulfilled") takeGecko(newSol.value.data || [], "new", 10, "New SOL");
    if (newBsc.status === "fulfilled") takeGecko(newBsc.value.data || [], "new", 8, "New BSC");

    const takeBoost = (list: Boost[], source: BreakoutHit["source"], label: string) => {
      const rows = Array.isArray(list) ? list : [];
      notes.push(`${label} ${rows.length}`);
      for (const b of rows.slice(0, 40)) {
        if (!b.tokenAddress) continue;
        if (b.chainId && !allowedChain(b.chainId)) continue;
        hydrate.push({
          source,
          address: b.tokenAddress,
          chain: b.chainId,
          boost: num(b.amount || b.totalAmount),
        });
      }
    };
    if (boosts.status === "fulfilled") takeBoost(boosts.value, "boost", "Boosts");
    if (boostTop.status === "fulfilled") takeBoost(boostTop.value, "boost", "Top boosts");
    if (profiles.status === "fulfilled") takeBoost(profiles.value, "new", "New profiles");
    if (cto.status === "fulfilled") takeBoost(cto.value, "cto", "CTO");

    const uniq: Hydra[] = [];
    const addrSeen = new Set<string>();
    for (const h of hydrate) {
      const key = h.address.toLowerCase();
      if (addrSeen.has(key)) continue;
      addrSeen.add(key);
      uniq.push(h);
    }

    const map = await dexMany(uniq.slice(0, 80).map((b) => b.address));
    for (const h of uniq.slice(0, 80)) {
      let dex: DexSnapshot | null = null;
      for (const [k, v] of map) {
        if (k.toLowerCase() === h.address.toLowerCase()) dex = v;
      }
      if (!dex) {
        try {
          dex = await dexByToken(h.address);
        } catch {
          dex = null;
        }
      }
      if (!dex) continue;
      const id = `${dex.chain}:${dex.tokenAddress || dex.pairAddress}`;
      if (seen.has(id)) continue;
      seen.add(id);
      const scored = scoreBreakout(dex, h.source, h.boost || 0);
      hits.push({
        id,
        source: h.source,
        symbol: dex.symbol,
        name: h.extra?.name || dex.name,
        chain: dex.chain,
        address: dex.tokenAddress || h.address,
        verdict: scored.verdict,
        score: scored.score,
        reasons: scored.reasons,
        dex,
        createdAt: h.extra?.createdAt || dex.pairCreatedAt,
        pumpMc: h.extra?.pumpMc ?? null,
        imageUrl: h.extra?.imageUrl || dex.imageUrl,
        boost: h.boost ?? null,
        fdvCliff: scored.fdvCliff,
      });
    }

    for (const q of ["SOL", "PEPE", "BONK", "WBNB"]) {
      try {
        const j = await getJson<{ pairs?: DexPair[] }>(`${DS}/latest/dex/search?q=${encodeURIComponent(q)}`);
        let n = 0;
        for (const p of j.pairs || []) {
          if (n >= 8) break;
          if (pairQuality(p) < 0) continue;
          const dex = pairToDex(p);
          if (!dex) continue;
          const id = `${dex.chain}:${dex.tokenAddress || dex.pairAddress}`;
          if (seen.has(id)) continue;
          seen.add(id);
          const scored = scoreBreakout(dex, "search");
          hits.push({
            id,
            source: "search",
            symbol: dex.symbol,
            name: dex.name,
            chain: dex.chain,
            address: dex.tokenAddress,
            verdict: scored.verdict,
            score: scored.score,
            reasons: scored.reasons,
            dex,
            createdAt: dex.pairCreatedAt,
            pumpMc: null,
            imageUrl: dex.imageUrl,
            boost: null,
            fdvCliff: scored.fdvCliff,
          });
          n += 1;
        }
        notes.push(`Search ${q} ${n}`);
      } catch {
        notes.push(`Search ${q} delayed`);
      }
    }

    hits.sort((a, b) => b.score - a.score);
    return { updatedAt: Date.now(), hits, sourceNotes: notes };
  });
}

export async function searchDex(q: string): Promise<BreakoutResponse> {
  const query = q.trim();
  if (query.length < 2) return { updatedAt: Date.now(), hits: [], sourceNotes: ["empty"] };
  const j = await getJson<{ pairs?: DexPair[] }>(
    `${DS}/latest/dex/search?q=${encodeURIComponent(query)}`,
  );
  const hits: BreakoutHit[] = [];
  const seen = new Set<string>();
  for (const p of j.pairs || []) {
    if (pairQuality(p) < 0) continue;
    const dex = pairToDex(p);
    if (!dex) continue;
    const id = `${dex.chain}:${dex.tokenAddress || dex.pairAddress}`;
    if (seen.has(id)) continue;
    seen.add(id);
    const scored = scoreBreakout(dex, "search");
    hits.push({
      id,
      source: "search",
      symbol: dex.symbol,
      name: dex.name,
      chain: dex.chain,
      address: dex.tokenAddress,
      verdict: scored.verdict,
      score: scored.score,
      reasons: scored.reasons,
      dex,
      createdAt: dex.pairCreatedAt,
      pumpMc: null,
      imageUrl: dex.imageUrl,
      boost: null,
      fdvCliff: scored.fdvCliff,
    });
  }
  hits.sort((a, b) => b.score - a.score);
  return { updatedAt: Date.now(), hits: hits.slice(0, 28), sourceNotes: [`DexScreener “${query}”`] };
}
