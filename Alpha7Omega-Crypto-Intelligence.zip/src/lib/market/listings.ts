export type ListingRow = {
  id: string;
  name: string;
  symbol: string;
  venue: string;
  window: string;
  pump: number;
  narrative: string;
  note: string;
  status: "live" | "soon" | "spent";
};

/** Robinson-style ICO / Alpha / TGE pump book. Scores retail-promise, not quality. */
export const LISTINGS: ListingRow[] = [
  {
    id: "binance-alpha-spot",
    name: "Binance Alpha → Spot",
    symbol: "MARSCOIN",
    venue: "Binance",
    window: "Alpha wrapper shrinking into Spot. Withdrawals were the 5 Sep flow event.",
    pump: 92,
    narrative: "Listing premium",
    note: "Retail promise is the Spot unlock. Inventory already dripped through a $900k pool. Do not treat a new Alpha name the same as a real TGE.",
    status: "spent",
  },
  {
    id: "bulla-websea",
    name: "BULLA listing squeeze",
    symbol: "BULLA",
    venue: "Websea + perps",
    window: "6 Sep +20% into 0.077 after a 4x week. High 0.092.",
    pump: 88,
    narrative: "Listing premium",
    note: "$1 needs ~$1B FDV. Fade on loss of 0.070, invalidation 0.093. Isolated. Do not long the headline.",
    status: "live",
  },
  {
    id: "letsbonk-useless",
    name: "LetsBONK.fun → Raydium LaunchLab",
    symbol: "USELESS",
    venue: "Solana",
    window: "May 2025 mint. CTO social, not on-chain. Unipcs 15.9M still sitting.",
    pump: 70,
    narrative: "Meme season",
    note: "Clean mint is not a bid. Perps vs pool is the unwind. Reject any CA that does not end in Mbonk.",
    status: "live",
  },
  {
    id: "stonkfun-ray",
    name: "StonkFun / LaunchLab buybacks",
    symbol: "RAY",
    venue: "Solana",
    window: "Fee-share buybacks >30% supply. Not a listing dump.",
    pump: 35,
    narrative: "Perp DEX",
    note: "Do not fade RAY as MARSCOIN. RSI stretch is a pullback, not a rug. Protocol bid can snap.",
    status: "live",
  },
  {
    id: "flock-leftover",
    name: "FLOCK leftover print",
    symbol: "FLOCK",
    venue: "Base / perps",
    window: "6 Sep +36% leftover. Real project, still used as a listing vehicle.",
    pump: 74,
    narrative: "AI agents",
    note: "AI narrative can keep it bid. Fade only isolated after a 1h roll — not as a dump-to-zero meme.",
    status: "live",
  },
  {
    id: "robinson-tge",
    name: "Retail TGE / seed-board",
    symbol: "TGE",
    venue: "CEX seed + Alpha",
    window: "Any name with a loud unlock calendar, thin pool, and a celebrity perp.",
    pump: 80,
    narrative: "Listing premium",
    note: "Robinson-class: promise the moon on a 4-week unlock, list the perp first, sell the float into the CEX book. Score = FDV/pool × 24h % × young pair. First print belongs to the listing. Second session is the fade.",
    status: "soon",
  },
];

export function pumpLabel(n: number) {
  if (n >= 85) return "HARD PUMP";
  if (n >= 70) return "RETAIL BAIT";
  if (n >= 50) return "WATCH";
  return "QUALITY";
}
