import { BRAND } from "@/lib/brand";

const UA = BRAND.ua;
const QUANTO = 0.0001;

type CacheEntry<T> = { at: number; value: T };
const cache = new Map<string, CacheEntry<unknown>>();

function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return Promise.resolve(hit.value as T);
  return fn()
    .then((value) => {
      cache.set(key, { at: Date.now(), value });
      return value;
    })
    .catch((err) => {
      if (hit) return hit.value as T;
      throw err;
    });
}

async function getJson<T>(url: string, timeoutMs = 8_000): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error(`${res.status} ${url}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

export type BookLevel = { price: number; size: number; usd: number };
export type BookWall = BookLevel & { side: "bid" | "ask"; pct: number };
export type Pocket = { lo: number; hi: number; side: "bid" | "ask" };

export type HeatSnap = {
  t: number;
  mid: number;
  lo: number;
  hi: number;
  bid: number[];
  ask: number[];
};

export type BtcBook = {
  mid: number;
  last: number;
  change24: number | null;
  high24: number | null;
  low24: number | null;
  volume24: number | null;
  funding: number | null;
  oiUsd: number | null;
  spread: number;
  imbalance: number;
  bidUsd: number;
  askUsd: number;
  bids: BookLevel[];
  asks: BookLevel[];
  walls: BookWall[];
  pockets: Pocket[];
  band: number;
  bucketPx: number;
  nBuckets: number;
  candles: Candle[];
  spark: number[];
  tape: HeatSnap[];
  read: string;
  source: string;
  venues: string[];
  updatedAt: number;
};

function num(v: unknown) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function levels(rows: unknown, side: "bid" | "ask", sizeMul = 1): BookLevel[] {
  if (!Array.isArray(rows)) return [];
  const out: BookLevel[] = [];
  for (const row of rows) {
    let price = 0;
    let size = 0;
    if (Array.isArray(row)) {
      price = num(row[0]);
      size = num(row[1]) * sizeMul;
    } else if (row && typeof row === "object") {
      const r = row as { p?: string; s?: string; price?: string; size?: string };
      price = num(r.p ?? r.price);
      size = num(r.s ?? r.size) * sizeMul;
    }
    if (price > 0 && size > 0) out.push({ price, size, usd: price * size });
  }
  out.sort((a, b) => (side === "ask" ? a.price - b.price : b.price - a.price));
  return out;
}

function mergeLevels(sides: BookLevel[][], side: "bid" | "ask"): BookLevel[] {
  const map = new Map<number, BookLevel>();
  for (const list of sides) {
    for (const l of list) {
      const key = Math.round(l.price * 100);
      const prev = map.get(key);
      if (prev) {
        prev.size += l.size;
        prev.usd += l.usd;
      } else {
        map.set(key, { ...l });
      }
    }
  }
  const out = [...map.values()];
  out.sort((a, b) => (side === "ask" ? a.price - b.price : b.price - a.price));
  return out;
}

function bucketPxFor(mid: number) {
  if (mid >= 10_000) return 10;
  if (mid >= 1_000) return 1;
  if (mid >= 100) return 0.1;
  return 0.01;
}

function findWalls(bids: BookLevel[], asks: BookLevel[], mid: number): BookWall[] {
  const all = [
    ...bids.map((l) => ({ ...l, side: "bid" as const })),
    ...asks.map((l) => ({ ...l, side: "ask" as const })),
  ];
  if (!all.length) return [];
  const sizes = all.map((l) => l.usd).sort((a, b) => a - b);
  const med = sizes[Math.floor(sizes.length * 0.55)] || 1;
  const floor = Math.max(80_000, med * 2.2);
  return all
    .filter((l) => l.usd >= floor && l.size >= 0.05)
    .sort((a, b) => b.usd - a.usd)
    .slice(0, 10)
    .map((l) => ({ ...l, pct: ((l.price - mid) / mid) * 100 }));
}

function findPockets(bids: BookLevel[], asks: BookLevel[], mid: number, band: number): Pocket[] {
  const lo = mid * (1 - band);
  const hi = mid * (1 + band);
  const step = bucketPxFor(mid);
  const pockets: Pocket[] = [];
  const scan = (list: BookLevel[], side: "bid" | "ask", from: number, to: number, dir: 1 | -1) => {
    const by = new Map<number, number>();
    for (const l of list) by.set(Math.round(l.price / step) * step, l.usd);
    let runStart: number | null = null;
    for (let p = from; dir > 0 ? p <= to : p >= to; p += dir * step) {
      const usd = by.get(Math.round(p / step) * step) || 0;
      const thin = usd < 25_000;
      if (thin && runStart == null) runStart = p;
      if ((!thin || (dir > 0 ? p >= to : p <= to)) && runStart != null) {
        const a = runStart;
        const b = p - dir * step;
        if (Math.abs(b - a) >= step * 3) {
          pockets.push({ lo: Math.min(a, b), hi: Math.max(a, b), side });
        }
        runStart = thin && (dir > 0 ? p < to : p > to) ? p : null;
      }
    }
  };
  scan(bids, "bid", mid - step, lo, -1);
  scan(asks, "ask", mid + step, hi, 1);
  return pockets.slice(0, 6);
}

function deskRead(book: {
  imbalance: number;
  walls: BookWall[];
  pockets: Pocket[];
  change24: number | null;
  funding: number | null;
  last: number;
}): string {
  const imb = book.imbalance;
  const side = imb >= 0.55 ? "Bids own the band" : imb <= 0.45 ? "Asks own the band" : "Book is balanced";
  const wall = book.walls[0];
  const wallBit = wall
    ? ` Biggest wall is a ${wall.side} at ${wall.price.toFixed(0)} (${wall.size.toFixed(2)} BTC).`
    : "";
  const pocket = book.pockets[0];
  const air = pocket
    ? ` Air pocket ${pocket.lo.toFixed(0)}–${pocket.hi.toFixed(0)} on the ${pocket.side} side.`
    : "";
  const chg = book.change24 ?? 0;
  const tape =
    chg <= -1.5 ? " Tape is risk-off — alts inherit the dip." : chg >= 1.5 ? " Tape is bid — alts will follow a squeeze." : "";
  const fund =
    book.funding != null && book.funding > 0.0002
      ? " Funding still pays longs."
      : book.funding != null && book.funding < -0.0001
        ? " Funding pays shorts."
        : "";
  return `${side}.${wallBit}${air}${tape}${fund}`.trim();
}

const tapeBuf: HeatSnap[] = [];
const TAPE_MAX = 72;
const TAPE_BUCKETS = 80;

function pushTape(mid: number, bids: BookLevel[], asks: BookLevel[], band: number) {
  const lo = mid * (1 - band);
  const hi = mid * (1 + band);
  const span = hi - lo || 1;
  const bid = new Array<number>(TAPE_BUCKETS).fill(0);
  const ask = new Array<number>(TAPE_BUCKETS).fill(0);
  const idx = (price: number) => {
    const i = Math.floor(((price - lo) / span) * TAPE_BUCKETS);
    return Math.max(0, Math.min(TAPE_BUCKETS - 1, i));
  };
  for (const l of bids) if (l.price >= lo) bid[idx(l.price)] += l.usd;
  for (const l of asks) if (l.price <= hi) ask[idx(l.price)] += l.usd;
  tapeBuf.push({ t: Date.now(), mid, lo, hi, bid, ask });
  while (tapeBuf.length > TAPE_MAX) tapeBuf.shift();
}

export async function fetchBtcBook(): Promise<BtcBook> {
  return cached("btc-book", 6_000, async () => {
    const [spot10, spot50, ticker, candles15, futBook] = await Promise.allSettled([
      getJson<{ bids?: unknown; asks?: unknown; current?: number }>(
        "https://api.gateio.ws/api/v4/spot/order_book?currency_pair=BTC_USDT&limit=120&interval=10",
      ),
      getJson<{ bids?: unknown; asks?: unknown }>(
        "https://api.gateio.ws/api/v4/spot/order_book?currency_pair=BTC_USDT&limit=80&interval=50",
      ),
      getJson<
        Array<{
          last?: string;
          change_percentage?: string;
          high_24h?: string;
          low_24h?: string;
          volume_24h_quote?: string;
          funding_rate?: string;
          total_size?: string;
          mark_price?: string;
        }>
      >("https://api.gateio.ws/api/v4/futures/usdt/tickers?contract=BTC_USDT"),
      getJson<unknown>(
        "https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=BTC_USDT&interval=15m&limit=192",
      ),
      getJson<{ bids?: unknown; asks?: unknown }>(
        "https://api.gateio.ws/api/v4/futures/usdt/order_book?contract=BTC_USDT&limit=50",
      ),
    ]);

    const venues: string[] = [];
    const bidSets: BookLevel[][] = [];
    const askSets: BookLevel[][] = [];

    if (spot10.status === "fulfilled") {
      bidSets.push(levels(spot10.value.bids, "bid"));
      askSets.push(levels(spot10.value.asks, "ask"));
      venues.push("Gate spot ×$10");
    }
    if (spot50.status === "fulfilled") {
      const nearB = bidSets[0] || [];
      const nearA = askSets[0] || [];
      const minBid = nearB.length ? Math.min(...nearB.map((l) => l.price)) : Infinity;
      const maxAsk = nearA.length ? Math.max(...nearA.map((l) => l.price)) : 0;
      const wingB = levels(spot50.value.bids, "bid").filter((l) => l.price < minBid);
      const wingA = levels(spot50.value.asks, "ask").filter((l) => l.price > maxAsk);
      if (wingB.length) bidSets.push(wingB);
      if (wingA.length) askSets.push(wingA);
      venues.push("Gate spot ×$50 wings");
    }
    if (futBook.status === "fulfilled") {
      bidSets.push(levels(futBook.value.bids, "bid", QUANTO));
      askSets.push(levels(futBook.value.asks, "ask", QUANTO));
      venues.push("Gate perp");
    }

    if (!bidSets.length && !askSets.length) {
      throw new Error("no book venues");
    }

    const bidsAll = mergeLevels(bidSets, "bid");
    const asksAll = mergeLevels(askSets, "ask");
    const tick = ticker.status === "fulfilled" ? ticker.value[0] : undefined;
    const last = num(tick?.last) || num(tick?.mark_price) || bidsAll[0]?.price || asksAll[0]?.price || 0;
    const mid = bidsAll[0] && asksAll[0] ? (bidsAll[0].price + asksAll[0].price) / 2 : last;
    const band = 0.012;
    const lo = mid * (1 - 0.05);
    const hi = mid * (1 + 0.05);
    const bids = bidsAll.filter((l) => l.price >= lo);
    const asks = asksAll.filter((l) => l.price <= hi);
    const inBandBids = bids.filter((l) => l.price >= mid * (1 - band));
    const inBandAsks = asks.filter((l) => l.price <= mid * (1 + band));
    const bidUsd = inBandBids.reduce((s, l) => s + l.usd, 0);
    const askUsd = inBandAsks.reduce((s, l) => s + l.usd, 0);
    const walls = findWalls(bids, asks, mid);
    const pockets = findPockets(inBandBids, inBandAsks, mid, band);
    const spread = bidsAll[0] && asksAll[0] ? asksAll[0].price - bidsAll[0].price : 0;
    const imbalance = bidUsd + askUsd > 0 ? bidUsd / (bidUsd + askUsd) : 0.5;
    const candles = candles15.status === "fulfilled" ? parseCandles(candles15.value) : [];
    const spark: number[] = [];
    for (let i = 0; i < candles.length; i += 4) spark.push(candles[i].c);
    if (candles.length) spark.push(candles[candles.length - 1].c);

    pushTape(mid, bids, asks, 0.025);

    const high24 = tick?.high_24h != null ? num(tick.high_24h) : candles.length ? Math.max(...candles.map((c) => c.h)) : null;
    const low24 = tick?.low_24h != null ? num(tick.low_24h) : candles.length ? Math.min(...candles.map((c) => c.l)) : null;
    const volume24 = tick?.volume_24h_quote != null ? num(tick.volume_24h_quote) : null;
    const funding = tick?.funding_rate != null ? num(tick.funding_rate) : null;
    const oiUsd = tick?.total_size != null ? num(tick.total_size) * QUANTO * last : null;

    const draft = {
      imbalance,
      walls,
      pockets,
      change24: tick?.change_percentage != null ? num(tick.change_percentage) : null,
      funding,
      last,
    };

    return {
      mid,
      last,
      change24: draft.change24,
      high24,
      low24,
      volume24,
      funding,
      oiUsd,
      spread,
      imbalance,
      bidUsd,
      askUsd,
      bids,
      asks,
      walls,
      pockets,
      band,
      bucketPx: bucketPxFor(mid),
      nBuckets: TAPE_BUCKETS,
      candles,
      spark,
      tape: tapeBuf.map((s) => ({ ...s })),
      read: deskRead(draft),
      source: venues.join(" + ") || "offline",
      venues,
      updatedAt: Date.now(),
    };
  });
}

export type Candle = {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
};

export type KlineResponse = {
  symbol: string;
  contract: string;
  interval: string;
  venue: string;
  candles: Candle[];
  updatedAt: number;
};

function toContract(raw: string) {
  const s = raw.trim().toUpperCase().replace(/[-/]/g, "");
  if (s.includes("_")) return s;
  if (s.endsWith("USDT")) return `${s.slice(0, -4)}_USDT`;
  return `${s}_USDT`;
}

function parseCandles(raw: unknown): Candle[] {
  if (!Array.isArray(raw)) return [];
  const out: Candle[] = [];
  for (const row of raw) {
    if (Array.isArray(row)) {
      const t = num(row[0]) * (String(row[0]).length < 12 ? 1000 : 1);
      const c = num(row[2]);
      const h = num(row[3]);
      const l = num(row[4]);
      const o = num(row[5]);
      const v = num(row[1]);
      if (t && h && l) out.push({ t, o, h, l, c, v });
    } else if (row && typeof row === "object") {
      const r = row as Record<string, unknown>;
      const t = num(r.t) * (String(r.t).length < 12 ? 1000 : 1);
      const o = num(r.o);
      const h = num(r.h);
      const l = num(r.l);
      const c = num(r.c);
      const v = num(r.v ?? r.sum);
      if (t && h && l) out.push({ t, o, h, l, c, v });
    }
  }
  out.sort((a, b) => a.t - b.t);
  return out;
}

export async function fetchKlines(symbol: string, interval: string): Promise<KlineResponse> {
  const contract = toContract(symbol);
  const tf = ["15m", "1h", "4h", "1d"].includes(interval) ? interval : "1h";
  const limit = tf === "15m" ? 180 : tf === "1h" ? 180 : 120;
  return cached(`kl:${contract}:${tf}`, 20_000, async () => {
    try {
      const fut = await getJson<unknown>(
        `https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${encodeURIComponent(contract)}&interval=${tf}&limit=${limit}`,
      );
      const candles = parseCandles(fut);
      if (candles.length >= 8) {
        return { symbol: contract.replace("_USDT", ""), contract, interval: tf, venue: "gate-perp", candles, updatedAt: Date.now() };
      }
    } catch {
      /* spot fallback */
    }
    const spot = await getJson<unknown>(
      `https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=${encodeURIComponent(contract)}&interval=${tf}&limit=${limit}`,
    );
    return {
      symbol: contract.replace("_USDT", ""),
      contract,
      interval: tf,
      venue: "gate-spot",
      candles: parseCandles(spot),
      updatedAt: Date.now(),
    };
  });
}
