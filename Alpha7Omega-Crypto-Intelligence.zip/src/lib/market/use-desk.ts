import { useEffect, useMemo, useState } from "react";
import { giStats, syncGiBook } from "./gi";
import {
  loadPins,
  loadWatch,
  savePins,
  saveWatch,
  type GiMark,
  type WatchBias,
  type WatchItem,
} from "./client-store";
import type { DeepHeatRow } from "./deepheat";

export function usePins() {
  const [pins, setPins] = useState<string[]>([]);
  useEffect(() => setPins(loadPins()), []);
  const toggle = (symbol: string) => {
    const key = symbol.toUpperCase();
    setPins((prev) => {
      const next = prev.includes(key) ? prev.filter((s) => s !== key) : [...prev, key];
      savePins(next);
      return next;
    });
  };
  return { pins, toggle };
}

export function useWatchList() {
  const [items, setItems] = useState<WatchItem[]>([]);
  useEffect(() => setItems(loadWatch()), []);
  const add = (symbol: string, bias: WatchBias) => {
    const key = symbol.trim().toUpperCase();
    if (!key) return;
    setItems((prev) => {
      const next = [{ symbol: key, bias, addedAt: Date.now() }, ...prev.filter((i) => i.symbol !== key)];
      saveWatch(next);
      return next;
    });
  };
  const remove = (symbol: string) => {
    setItems((prev) => {
      const next = prev.filter((i) => i.symbol !== symbol);
      saveWatch(next);
      return next;
    });
  };
  return { items, add, remove };
}

export function useGiBook(rows: DeepHeatRow[], prices: Record<string, number>) {
  const [marks, setMarks] = useState<GiMark[]>([]);
  useEffect(() => {
    setMarks(syncGiBook(rows, prices));
  }, [rows, prices]);
  const stats = useMemo(() => giStats(marks), [marks]);
  const open = useMemo(() => marks.filter((m) => m.status === "open"), [marks]);
  return { marks, open, stats };
}
