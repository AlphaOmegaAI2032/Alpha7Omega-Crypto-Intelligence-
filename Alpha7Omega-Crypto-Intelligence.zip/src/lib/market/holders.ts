import type { HolderProfile } from "./types";

/** Snapshot from BscScan / CryptoRank around 4 Sep 2026. Not a live indexer. */
export const HOLDERS: Record<string, HolderProfile> = {
  MARSCOIN: {
    top100Pct: 68.3,
    top10Pct: 31,
    holders: 42000,
    inventoryToPool: "30–40×",
    dripSeller: "0x6d8ac75d911bf7339fcf414ea79ae1edde18dabc",
    slices: [
      { label: "Top 1 · Binance Alpha router", pct: 16.89, tokens: "168.9M", note: "CEX custody, not a diamond hand" },
      { label: "Gate + MEXC", pct: 4.64, tokens: "46.4M", note: "Exchange inventory" },
      { label: "Pancake LP", pct: 0.62, tokens: "6.17M", note: "Cannot absorb a top-10 wallet" },
      { label: "Unlabeled 2.5% EOA (Unipcs-sized)", pct: 2.5, tokens: "24.96M", note: "Lookonchain: Unipcs 24.95M MARS. Silent through the drip." },
      { label: "Unlabeled 2.26% EOA", pct: 2.26, tokens: "22.57M", note: "Silent. Next shoe if it isn't the same cluster." },
      { label: "Drip seller 0x6d8a…", pct: 0.84, tokens: "8.44M", note: "13.48M → 8.44M live. Cost $0.00133. Still dripping." },
      { label: "1% clone belt (~15 wallets)", pct: 20, tokens: "~200M", note: "Allocation fingerprints, not retail" },
      { label: "Outside top 100", pct: 31.7, tokens: "317M", note: "~40k shrimp. Cosmetic holder count." },
    ],
  },
  USELESS: {
    top100Pct: 47,
    top10Pct: 15,
    holders: 48000,
    inventoryToPool: "7× vs Raydium / 80× vs Orca",
    dripSeller: "Unipcs / Bonk Guy ~15.9M",
    slices: [
      { label: "Unipcs (Bonk Guy)", pct: 1.6, tokens: "15.9M", note: "Public bag. Scheduled distribution, not a believer." },
      { label: "Top cluster 4.4 / 4.2 / 3.5 / 3.0%", pct: 15, tokens: "~150M", note: "KOL + early. One 2–3% sell is a 20% candle on the thin pool." },
    ],
  },
  "龙虾": {
    top100Pct: 55,
    top10Pct: 22,
    holders: 0,
    inventoryToPool: "20×",
    dripSeller: null,
    slices: [
      { label: "CTO / no-community tag", pct: 0, tokens: "—", note: "Blacklist function on contract. Owner can brick wallets." },
    ],
  },
  "4": {
    top100Pct: 0,
    top10Pct: 0,
    holders: 0,
    inventoryToPool: "thin",
    dripSeller: null,
    slices: [
      { label: "Joke ticker", pct: 0, tokens: "—", note: "CEX derivative on a BNB Chain security-warning shitpost." },
    ],
  },
};

export function holdersFor(symbol: string): HolderProfile | null {
  return HOLDERS[symbol] ?? HOLDERS[symbol.toUpperCase()] ?? null;
}
