/** Purple marks from the 09:48–09:50 SAST Binance ranking screen recording. */

export type CircledMark = "arrow" | "underline" | "cluster";
export type CircledCall =
  | "hold-long"
  | "beta"
  | "trail"
  | "short-now"
  | "re-fade"
  | "peel"
  | "isolated"
  | "never"
  | "late"
  | "skip"
  | "wait";

export type CircledRow = {
  id: string;
  board: "hot" | "gainers" | "losers";
  sym: string;
  name: string;
  px: number;
  chg: number;
  mark: CircledMark;
  call: CircledCall;
  label: string;
  why: string;
};

export const CIRCLED_META = {
  stamp: "09:48–09:50 SAST",
  date: "2026-09-09",
  source: "Binance USDT-M ranking · 117s screen recording",
  note: "Purple arrows = real bid. Underlines = your short book. Cluster line = L1/beta, not a cliff.",
};

export const CIRCLED: CircledRow[] = [
  {
    id: "zec",
    board: "hot",
    sym: "ZEC",
    name: "Zcash",
    px: 1242.97,
    chg: 11.27,
    mark: "arrow",
    call: "hold-long",
    label: "HOLD LONG",
    why: "Privacy sleeve. Higher high on $2.59B vol. Do not fade like BULLA.",
  },
  {
    id: "btc",
    board: "hot",
    sym: "BTC",
    name: "Bitcoin",
    px: 79187.8,
    chg: 1.16,
    mark: "arrow",
    call: "beta",
    label: "BETA",
    why: "Alts inherit this book. +1.2% is risk-on, not a squeeze to fade.",
  },
  {
    id: "eth",
    board: "hot",
    sym: "ETH",
    name: "Ethereum",
    px: 2509.98,
    chg: 1.46,
    mark: "arrow",
    call: "beta",
    label: "BETA",
    why: "Same sleeve as BTC/SOL. Not a ranking cliff.",
  },
  {
    id: "mars",
    board: "hot",
    sym: "MARSCOIN",
    name: "Marscoin",
    px: 0.13698,
    chg: -4.21,
    mark: "underline",
    call: "trail",
    label: "TRAIL ONLY",
    why: "T1 0.150 hit. −28% from Sunday 0.191. Peel into 0.12. Cover 0.155.",
  },
  {
    id: "sol",
    board: "hot",
    sym: "SOL",
    name: "Solana",
    px: 104.63,
    chg: 1.84,
    mark: "underline",
    call: "beta",
    label: "BETA · NOT A FADE",
    why: "You underlined it next to MARS. Different machine. Do not short SOL like a meme.",
  },
  {
    id: "soph-hot",
    board: "hot",
    sym: "SOPH",
    name: "Sophon",
    px: 0.005542,
    chg: -44.73,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Already the dump. Next short is a +25% bounce from 0.0054, not this print.",
  },
  {
    id: "vvv",
    board: "gainers",
    sym: "VVV",
    name: "Venice",
    px: 28.32,
    chg: 60.22,
    mark: "arrow",
    call: "never",
    label: "NOT A P&D",
    why: "Venice AI. $1.2B mcap, $100M ARR. Same class as RAY. Percent is a liar.",
  },
  {
    id: "useless",
    board: "gainers",
    sym: "USELESS",
    name: "Useless",
    px: 0.32282,
    chg: 38.51,
    mark: "underline",
    call: "re-fade",
    label: "RE-FADE · 0.320",
    why: "Sunday short stopped. NEW ticket. Fire loss of 0.320 then 0.312. Stop 0.337.",
  },
  {
    id: "ray",
    board: "gainers",
    sym: "RAY",
    name: "Raydium",
    px: 1.3269,
    chg: 22.68,
    mark: "underline",
    call: "peel",
    label: "PEEL · DO NOT FADE",
    why: "LaunchLab buybacks. Funding negative. The 38× was the mistake.",
  },
  {
    id: "ff",
    board: "gainers",
    sym: "FF",
    name: "Falcon Finance",
    px: 0.14721,
    chg: 22.74,
    mark: "underline",
    call: "short-now",
    label: "SHORT NOW · NEAR 0.152",
    why: "09:50 take. Live is pressing the abort. If in: stop 0.152, no add. If not in: wait for 0.145. Do not chase green.",
  },
  {
    id: "iost",
    board: "gainers",
    sym: "IOST",
    name: "IOST",
    px: 0.0011816,
    chg: 22.55,
    mark: "underline",
    call: "isolated",
    label: "ISOLATED FADE",
    why: "+65% from Sunday 0.000717. Dust. Red 15m / 0.00116. Stop 0.00125.",
  },
  {
    id: "niulai",
    board: "gainers",
    sym: "牛来",
    name: "Niu Lai",
    px: 0.11013,
    chg: 19.41,
    mark: "underline",
    call: "wait",
    label: "WAIT · SHORTS IN",
    why: "Chinese meme. Funding already negative. Late short is crowded.",
  },
  {
    id: "truth",
    board: "gainers",
    sym: "TRUTH",
    name: "Truth",
    px: 0.01433,
    chg: 15.68,
    mark: "underline",
    call: "skip",
    label: "THIN TRAP",
    why: "~$99k vol. A 16% print on dust. Percent is a liar.",
  },
  {
    id: "lit",
    board: "gainers",
    sym: "LIT",
    name: "Lighter",
    px: 5.2953,
    chg: 14.83,
    mark: "underline",
    call: "never",
    label: "NAMED · NOT LTC",
    why: "Lighter perp-DEX token at $5.29. Infra, not a cliff.",
  },
  {
    id: "atom",
    board: "gainers",
    sym: "ATOM",
    name: "Cosmos",
    px: 1.881,
    chg: 14.28,
    mark: "cluster",
    call: "never",
    label: "L1 BETA",
    why: "Your vertical line with MAGMA/BTR. Cosmos Hub. Same bucket as DOT.",
  },
  {
    id: "magma",
    board: "gainers",
    sym: "MAGMA",
    name: "Magma",
    px: 0.26858,
    chg: 13.78,
    mark: "cluster",
    call: "never",
    label: "NAMED BETA",
    why: "On the cluster line with ATOM. Not a 4-hour mint.",
  },
  {
    id: "soph",
    board: "losers",
    sym: "SOPH",
    name: "Sophon",
    px: 0.005548,
    chg: -44.41,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Pumped then −45%. Price is UP from Sunday 0.00418. Inverse knife.",
  },
  {
    id: "form",
    board: "losers",
    sym: "FORM",
    name: "Four",
    px: 0.2865,
    chg: -25.85,
    mark: "underline",
    call: "late",
    label: "TOO LATE · ACCELERATING",
    why: "−16.6% → −25.9% in two minutes on this tape. Dump already happened.",
  },
  {
    id: "collect",
    board: "losers",
    sym: "COLLECT",
    name: "Collect",
    px: 0.02542,
    chg: -21.64,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Sunday −45% @ 0.044. Same machine, later. Do not add.",
  },
  {
    id: "cys",
    board: "losers",
    sym: "CYS",
    name: "CYS",
    px: 0.1669,
    chg: -16.76,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Already −17%. Inverse knife.",
  },
  {
    id: "star",
    board: "losers",
    sym: "STAR",
    name: "STAR",
    px: 0.07485,
    chg: -16.85,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Already −17%.",
  },
  {
    id: "ake",
    board: "losers",
    sym: "AKE",
    name: "Akedo",
    px: 0.01629,
    chg: -13.03,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Sunday −30%. Funding deeply negative. Shorts already in.",
  },
  {
    id: "xan",
    board: "losers",
    sym: "XAN",
    name: "XAN",
    px: 0.0116,
    chg: -10.87,
    mark: "underline",
    call: "late",
    label: "FADE WORKED",
    why: "Sunday +22% leftover is −32% from stamp. Do not add.",
  },
  {
    id: "hemi",
    board: "losers",
    sym: "HEMI",
    name: "Hemi",
    px: 0.00753,
    chg: -10.08,
    mark: "underline",
    call: "late",
    label: "TOO LATE",
    why: "Funding already negative. Do not short late.",
  },
];

export const CIRCLED_BOARDS: Array<{
  id: CircledRow["board"];
  title: string;
  kicker: string;
}> = [
  { id: "hot", title: "Hot · arrows vs leftover", kicker: "You marked ZEC/BTC/ETH as the real bid. MARS is the trail. SOPH is dead." },
  { id: "gainers", title: "Gainers · the 09:50 window", kicker: "VVV is Venice. FF is the take. USELESS is a trigger, not a market short." },
  { id: "losers", title: "Losers · already dumped", kicker: "Every underline here is an inverse knife. Do not chase." },
];

export function callClass(call: CircledCall): string {
  switch (call) {
    case "short-now":
    case "re-fade":
      return "text-down";
    case "hold-long":
    case "beta":
    case "never":
      return "text-up";
    case "trail":
    case "peel":
    case "isolated":
    case "wait":
      return "text-wait";
    default:
      return "text-muted";
  }
}

export function markLabel(mark: CircledMark): string {
  if (mark === "arrow") return "→";
  if (mark === "cluster") return "∥";
  return "—";
}
