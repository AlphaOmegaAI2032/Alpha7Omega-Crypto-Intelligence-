export const BRAND = {
  lockup: "A7Ω",
  name: "Alpha7Ωmega",
  product: "Crypto Intelligence",
  title: "Alpha7Ωmega Crypto Intelligence",
  tagline: "09:50 NOW book. Isolated shorts.",
  kicker: "Command desk",
  footer:
    "Research desk, not a broker. Perps can liquidate. DeepHeat is a score, not a signal you have to take. CLIFF is inventory math, not a fill.",
  ua: "Alpha7Omega-CryptoIntelligence/2.0",
  dh: "DH-1.4",
} as const;

export const STORAGE = {
  pins: "a7o_pins",
  watch: "a7o_watch",
  gi: "a7o_gi_book",
  godmode: "a7o_godmode",
} as const;
