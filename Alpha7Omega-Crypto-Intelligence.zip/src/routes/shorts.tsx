import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { DetailSheet } from "@/components/detail-sheet";
import { DhRow } from "@/components/dh-row";
import { MoverRow } from "@/components/mover-row";
import { NowBook } from "@/components/now-book";
import { PageHead } from "@/components/page-head";
import { WatchStrip } from "@/components/watch-strip";
import { dhFades, scoreDeepHeat } from "@/lib/market/deepheat";
import { useTape, useUniverse } from "@/lib/market/hooks";
import { usePins } from "@/lib/market/use-desk";
import type { ScoredMover } from "@/lib/market/types";

export const Route = createFileRoute("/shorts")({ component: ShortsPage });

function ShortsPage() {
  const [filter, setFilter] = useState<"fade" | "action" | "all">("fade");
  const [target, setTarget] = useState<ScoredMover | null>(null);
  const universe = useUniverse();
  const tape = useTape(true);
  const { pins, toggle } = usePins();
  const movers = tape.data?.movers ?? [];
  const coins = universe.data?.coins ?? [];
  const rows = useMemo(() => scoreDeepHeat(coins, movers), [coins, movers]);
  const fades = dhFades(rows, 12);
  const mars = movers.find((m) => m.symbol.toUpperCase() === "MARSCOIN") ?? null;
  const useless = movers.find((m) => m.symbol.toUpperCase() === "USELESS") ?? null;
  const ff = movers.find((m) => m.symbol.toUpperCase() === "FF") ?? null;
  const quotes = useMemo(() => {
    const q: Record<string, { price: number; chg: number | null }> = {};
    for (const c of coins) q[c.symbol] = { price: c.price, chg: c.chg24h };
    for (const m of movers) {
      const last = m.perp?.last ?? m.dex?.priceUsd;
      if (last) q[m.symbol.toUpperCase()] = { price: last, chg: m.perp?.change24h ?? m.dex?.changeH24 ?? null };
    }
    return q;
  }, [coins, movers]);
  const list = movers.filter((m) => {
    if (filter === "all") return true;
    if (filter === "action") return m.verdict === "SHORT_HARD" || m.verdict === "FADE" || m.verdict === "WAIT";
    return m.verdict === "SHORT_HARD" || m.verdict === "FADE";
  });

  return (
    <div>
      <PageHead kicker="Fade book · 09:50 SAST" title="Shorts you can take this hour" />
      <p className="mb-4 max-w-3xl text-sm leading-relaxed text-muted">
        Super-gain filter with a hard NOW stamp. Ranked when the tape is high and fast: 24h ≥ 12%, 1h stalled, stretched
        funding, thin books. Mean-reversion desk — not a trend short. Do not fade Venice, RAY, ATOM or ZEC as if they
        were MARSCOIN. Do not chase SOPH/FORM — that dump already printed.
      </p>
      <NowBook quotes={quotes} />
      <WatchStrip mars={mars} useless={useless} ff={ff} onOpen={(m) => setTarget(m)} />
      <div className="mb-4 grid gap-3 lg:grid-cols-2">
        {fades.map((r) => (
          <DhRow key={r.symbol} row={r} onPin={toggle} pinned={pins.includes(r.symbol.toUpperCase())} />
        ))}
      </div>
      <div className="mb-3 flex gap-1">
        {(
          [
            ["fade", "Super-gain"],
            ["action", "Action"],
            ["all", "All tape"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase tracking-wide ${
              filter === id ? "bg-accent text-accent-fg" : "bg-surface text-muted"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
      {tape.isLoading ? (
        <div className="grid gap-2 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="skel h-24 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid gap-2 lg:grid-cols-2">
          {list.map((m) => (
            <MoverRow key={m.id} item={m} onOpen={() => setTarget(m)} />
          ))}
        </div>
      )}
      <DetailSheet
        open={!!target}
        onOpenChange={(v) => {
          if (!v) setTarget(null);
        }}
        target={target ? { mode: "mover", item: target } : null}
        pinned={pins}
        onTogglePin={toggle}
      />
    </div>
  );
}
