import { Link, createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { DetailSheet } from "@/components/detail-sheet";
import { PageHead } from "@/components/page-head";
import { RadarDesk } from "@/components/radar-desk";
import { WhaleMap } from "@/components/whale-map";
import { pct, px, usd } from "@/lib/market/format";
import { useBreakouts, useFlow, useIntel, useNews, useTape, useTerra, useUniverse } from "@/lib/market/hooks";
import type { FlowResponse } from "@/lib/market/flow";
import { INTEL_UNIVERSE } from "@/lib/market/intel";
import { isStable } from "@/lib/market/sectors";
import { usePins } from "@/lib/market/use-desk";
import type { BreakoutHit, ScoredMover } from "@/lib/market/types";

export const Route = createFileRoute("/flow")({ component: FlowPage });

type Tab = "defi" | "dex" | "whales" | "exchanges" | "coins" | "rules";

function FlowPage() {
  const [tab, setTab] = useState<Tab>("defi");
  const [whaleSym, setWhaleSym] = useState("MARSCOIN");
  const [hit, setHit] = useState<BreakoutHit | null>(null);
  const [mover, setMover] = useState<ScoredMover | null>(null);
  const flow = useFlow();
  const news = useNews();
  const universe = useUniverse();
  const tape = useTape(tab === "dex" || tab === "coins");
  const brk = useBreakouts(tab === "dex");
  const intel = useIntel(whaleSym);
  const terra = useTerra();
  const { pins, toggle } = usePins();
  const d = flow.data;
  const coins = universe.data?.coins ?? [];
  const movers = tape.data?.movers ?? [];
  const mars = movers.find((m) => m.symbol.toUpperCase() === "MARSCOIN") ?? null;
  const useless = movers.find((m) => m.symbol.toUpperCase() === "USELESS") ?? null;

  const emerging = useMemo(() => {
    return [...coins]
      .filter((c) => !isStable(c.symbol) && c.mcap > 2_000_000 && c.mcap < 400_000_000 && (c.chg24h ?? 0) >= 8 && c.volume > 400_000)
      .sort((a, b) => (b.chg24h ?? 0) - (a.chg24h ?? 0))
      .slice(0, 16);
  }, [coins]);
  const top = useMemo(() => [...coins].filter((c) => !isStable(c.symbol)).sort((a, b) => b.mcap - a.mcap).slice(0, 16), [coins]);
  const rules = (news.data?.items ?? []).filter((n) => n.bucket === "clarity" || n.bucket === "fed");

  return (
    <div>
      <PageHead kicker="Flow" title="DeFi, venues, whales" />
      <p className="mb-4 max-w-3xl text-sm text-muted">
        Live TVL, DEX volume, CEX market share, a visual whale cliff, emerging names and the policy tape. Grok reads
        on demand — one per desk per day. LUNA/LUNC chain metrics live on{" "}
        <Link to="/terra" className="text-fg underline">
          Terra
        </Link>
        {terra.data?.impostors.some((i) => i.verdict === "SHORT_HARD")
          ? " — a ticker-snatch mint is printing a CLIFF right now."
          : "."}
      </p>

      <div className="mb-4 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1">
        {([
          ["defi", "DeFi"],
          ["dex", "DEX"],
          ["whales", "Whales"],
          ["exchanges", "Exchanges"],
          ["coins", "Coins"],
          ["rules", "Rules"],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`h-11 flex-1 rounded-md px-3 text-sm ${tab === id ? "bg-accent text-accent-fg" : "text-muted"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {flow.isLoading && !d ? <div className="skel mb-4 h-28 rounded-xl" /> : null}

      {tab === "defi" && d ? <DefiDesk flow={d} /> : null}
      {tab === "dex" ? (
        <div className="space-y-6">
          {d ? <VenueShare title="DEX 24h volume" rows={d.dexes.map((x) => ({ name: x.name, value: x.vol24, hint: pct(x.change1d) }))} totalLabel={usd(d.dexTotal24, 0)} /> : null}
          <RadarDesk
            hits={brk.data?.hits ?? []}
            loading={brk.isLoading}
            error={brk.isError}
            notes={brk.data?.sourceNotes}
            mars={mars}
            useless={useless}
            onOpenHit={setHit}
            onOpenMover={setMover}
          />
        </div>
      ) : null}
      {tab === "whales" ? (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-1">
            {INTEL_UNIVERSE.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setWhaleSym(s)}
                className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase ${whaleSym === s ? "bg-accent text-accent-fg" : "bg-surface text-muted"}`}
              >
                {s}
              </button>
            ))}
          </div>
          {intel.isLoading ? <div className="skel h-64 rounded-xl" /> : null}
          {intel.data ? (
            <WhaleMap holders={intel.data.holders} whales={intel.data.whales} symbol={intel.data.symbol} />
          ) : intel.isError ? (
            <p className="text-sm text-muted">Whale tape not on the wire.</p>
          ) : null}
          <GrokRead desk="whales" />
        </div>
      ) : null}
      {tab === "exchanges" && d ? (
        <div className="space-y-6">
          <div className="grid gap-3 sm:grid-cols-3">
            <Kpi label="CEX 24h (self-rep.)" value={`${d.cexVolBtc.toFixed(0)} BTC`} hint="Gecko, inflated" />
            <Kpi label="DEX 24h" value={usd(d.dexTotal24, 0)} hint={pct(d.dexChange1d)} />
            <Kpi
              label="DEX / CEX"
              value={d.cexVolBtc > 0 && d.dexTotal24 > 0 ? `${((d.dexTotal24 / (d.cexVolBtc * (coins.find((c) => c.symbol === "BTC")?.price || 80000))) * 100).toFixed(1)}%` : "—"}
              hint="DEX share of spot-ish flow"
            />
          </div>
          <VenueShare title="CEX reported volume" rows={d.cexes.map((x) => ({ name: x.name, value: x.volBtc, hint: x.country }))} totalLabel={`${d.cexVolBtc.toFixed(0)} BTC`} unit="BTC" />
          <VenueShare title="DEX venues" rows={d.dexes.map((x) => ({ name: x.name, value: x.vol24, hint: pct(x.change1d) }))} totalLabel={usd(d.dexTotal24, 0)} />
          <p className="text-xs text-faint">
            CEX volumes are self-reported and routinely washed. DEX volume on DeFiLlama is closer to a real tape. Use
            the ratio as a weather vane, not a fill.
          </p>
          <GrokRead desk="exchanges" />
        </div>
      ) : null}
      {tab === "coins" ? (
        <div className="grid gap-6 lg:grid-cols-2">
          <section>
            <h2 className="mb-3 text-sm font-medium">Top cap</h2>
            <CoinTable rows={top} />
          </section>
          <section>
            <h2 className="mb-3 text-sm font-medium">Emerging (small-cap heat)</h2>
            <CoinTable rows={emerging} />
          </section>
          {d?.trending.length ? (
            <section className="lg:col-span-2">
              <h2 className="mb-3 text-sm font-medium">Gecko trending</h2>
              <div className="flex flex-wrap gap-2">
                {d.trending.map((t) => (
                  <div key={t.id} className="glass rounded-xl px-4 py-3">
                    <div className="font-mono text-sm">{t.symbol}</div>
                    <div className="text-xs text-muted">{t.name}</div>
                    <div className={`mt-1 font-mono text-xs tabular ${ (t.chg24 ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                      {pct(t.chg24)} · rank {t.rank ?? "—"}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ) : null}
          <GrokRead desk="coins" />
        </div>
      ) : null}
      {tab === "rules" ? (
        <div className="space-y-4">
          <p className="text-sm text-muted">
            Clarity, MiCA, Fed, FSCA/SARB. Daily wire — not legal advice. Johannesburg sits under FSCA; USD venues sit
            under whatever Washington printed this week.
          </p>
          <ul className="space-y-3">
            {rules.slice(0, 18).map((n) => (
              <li key={n.id} className="glass rounded-xl p-4">
                <div className="font-mono text-[10px] uppercase tracking-widest text-faint">
                  {n.bucket} · {n.source}
                </div>
                <a href={n.url} target="_blank" rel="noreferrer" className="mt-1 block text-sm text-fg hover:underline">
                  {n.title}
                </a>
              </li>
            ))}
            {!rules.length ? <li className="text-sm text-muted">No policy headlines on this pull.</li> : null}
          </ul>
          <GrokRead desk="rules" />
        </div>
      ) : null}

      {tab === "defi" && d ? <GrokRead desk="defi" /> : null}

      <DetailSheet
        open={!!hit || !!mover}
        onOpenChange={(v) => {
          if (!v) {
            setHit(null);
            setMover(null);
          }
        }}
        target={mover ? { mode: "mover", item: mover } : hit ? { mode: "hit", item: hit } : null}
        pinned={pins}
        onTogglePin={toggle}
      />
    </div>
  );
}

function DefiDesk({ flow }: { flow: FlowResponse }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label="DeFi TVL" value={usd(flow.tvl, 0)} hint={flow.tvlChange1d != null ? `avg 1d ${pct(flow.tvlChange1d)}` : "Llama chains"} />
        <Kpi label="DEX 24h" value={usd(flow.dexTotal24, 0)} hint={pct(flow.dexChange1d)} />
        <Kpi label="Chains" value={String(flow.chains.length)} hint={flow.chains[0]?.name} />
        <Kpi label="Yields in book" value={String(flow.yields.length)} hint="TVL ≥ $8M, APY 2–55%" />
      </div>
      <VenueShare title="Chain TVL" rows={flow.chains.map((c) => ({ name: c.name, value: c.tvl, hint: c.token || "" }))} totalLabel={usd(flow.tvl, 0)} />
      <section>
        <h2 className="mb-3 text-sm font-medium">Protocols</h2>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-[0.16em] text-muted">
              <tr className="border-b border-line">
                <th className="py-2 font-medium">Name</th>
                <th className="py-2 font-medium">Cat</th>
                <th className="py-2 font-medium">TVL</th>
                <th className="py-2 font-medium">1d</th>
                <th className="py-2 font-medium">Chains</th>
              </tr>
            </thead>
            <tbody>
              {flow.protocols.map((p) => (
                <tr key={p.name} className="border-b border-line/70">
                  <td className="py-2 font-medium">{p.name}</td>
                  <td className="py-2 font-mono text-xs text-muted">{p.category}</td>
                  <td className="py-2 font-mono tabular">{usd(p.tvl, 0)}</td>
                  <td className={`py-2 font-mono tabular ${(p.change1d ?? 0) >= 0 ? "text-up" : "text-down"}`}>{pct(p.change1d)}</td>
                  <td className="py-2 font-mono text-[11px] text-faint">{p.chains.join(" · ")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section>
        <h2 className="mb-3 text-sm font-medium">Real yields (not farm bait)</h2>
        <div className="grid gap-2 sm:grid-cols-2">
          {flow.yields.map((y) => (
            <div key={`${y.project}-${y.symbol}-${y.chain}`} className="glass rounded-xl p-3">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-medium">{y.project}</span>
                <span className="font-mono text-up">{y.apy.toFixed(1)}%</span>
              </div>
              <p className="mt-1 font-mono text-xs text-muted">
                {y.symbol} · {y.chain} · {usd(y.tvl, 0)}
                {y.stable ? " · stable" : ""}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function VenueShare({
  title,
  rows,
  totalLabel,
  unit,
}: {
  title: string;
  rows: Array<{ name: string; value: number; hint?: string }>;
  totalLabel: string;
  unit?: string;
}) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  const sum = rows.reduce((s, r) => s + r.value, 0) || 1;
  return (
    <section className="glass rounded-xl p-4">
      <div className="mb-3 flex items-baseline justify-between">
        <h2 className="text-sm font-medium">{title}</h2>
        <span className="font-mono text-xs text-muted">{totalLabel}</span>
      </div>
      <div className="mb-3 flex h-3 overflow-hidden rounded-sm">
        {rows.slice(0, 8).map((r, i) => (
          <div
            key={r.name}
            className="h-full"
            style={{
              width: `${(r.value / sum) * 100}%`,
              background: i % 2 === 0 ? "var(--color-fg)" : "var(--color-muted)",
              opacity: 1 - i * 0.08,
            }}
          />
        ))}
      </div>
      <ul className="space-y-2">
        {rows.slice(0, 12).map((r) => (
          <li key={r.name}>
            <div className="flex items-baseline justify-between gap-2 text-sm">
              <span className="truncate">{r.name}</span>
              <span className="font-mono tabular text-muted">
                {unit === "BTC" ? `${r.value.toFixed(0)} BTC` : usd(r.value, 0)} · {((r.value / sum) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-sm bg-elevated">
              <div className="h-full bg-fg/70" style={{ width: `${Math.max(2, (r.value / max) * 100)}%` }} />
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function CoinTable({ rows }: { rows: Array<{ id: string; symbol: string; name: string; price: number; chg24h: number | null; mcap: number; volume: number }> }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[480px] text-left text-sm">
        <thead className="text-[11px] uppercase tracking-[0.16em] text-muted">
          <tr className="border-b border-line">
            <th className="py-2 font-medium">Market</th>
            <th className="py-2 font-medium">Last</th>
            <th className="py-2 font-medium">24h</th>
            <th className="py-2 font-medium">Mcap</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((c) => (
            <tr key={c.id} className="border-b border-line/70">
              <td className="py-2">
                <Link to="/ta" search={{ s: `${c.symbol}USDT` }} className="font-mono font-semibold hover:underline">
                  {c.symbol}
                </Link>
                <div className="text-xs text-faint">{c.name}</div>
              </td>
              <td className="py-2 font-mono tabular">{px(c.price)}</td>
              <td className={`py-2 font-mono tabular ${(c.chg24h ?? 0) >= 0 ? "text-up" : "text-down"}`}>{pct(c.chg24h)}</td>
              <td className="py-2 font-mono tabular text-muted">{usd(c.mcap, 0)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <section className="glass rounded-xl p-4">
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted">{label}</p>
      <p className="mt-1 font-mono text-xl tabular">{value}</p>
      {hint ? <p className="mt-1 truncate font-mono text-[11px] text-faint">{hint}</p> : null}
    </section>
  );
}

function GrokRead({ desk }: { desk: "defi" | "exchanges" | "whales" | "rules" | "coins" }) {
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState<string | null>(null);
  const [meta, setMeta] = useState<string | null>(null);

  async function run(force = false) {
    setBusy(true);
    try {
      const res = await fetch("/api/read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ desk, force }),
      });
      const json = (await res.json()) as { ok?: boolean; text?: string; error?: string; cached?: boolean };
      if (!json.ok) {
        setText(json.error || "Read failed.");
        setMeta("error");
        return;
      }
      setText(json.text || "");
      setMeta(json.cached ? "Cached — one Grok read per desk per day." : "Fresh Grok 4.5 read.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="glass rounded-xl p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-medium">Grok interpretation</h2>
        <button
          type="button"
          onClick={() => run(false)}
          disabled={busy}
          className="h-11 rounded-md bg-accent px-4 text-sm text-accent-fg disabled:opacity-40"
        >
          {busy ? "Reading…" : "Grok read"}
        </button>
      </div>
      {meta ? <p className="mt-2 font-mono text-[11px] text-faint">{meta}</p> : null}
      {text ? <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-muted">{text}</pre> : (
        <p className="mt-2 text-sm text-faint">User-initiated. Cached for the UTC day so the desk does not burn quota on refresh.</p>
      )}
    </section>
  );
}
