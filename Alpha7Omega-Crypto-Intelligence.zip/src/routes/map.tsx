import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useMemo, useState } from "react";
import { BubbleField, type Layout, type SizeBy } from "@/components/bubble-field";
import { DetailSheet } from "@/components/detail-sheet";
import { PageHead } from "@/components/page-head";
import { SignalFeed } from "@/components/signal-feed";
import { WeatherBar } from "@/components/weather-bar";
import { isStable, SECTOR_LABEL } from "@/lib/market/sectors";
import { useUniverse } from "@/lib/market/hooks";
import { usePins } from "@/lib/market/use-desk";
import type { BubbleCoin, Sector, Timeframe } from "@/lib/market/types";

export const Route = createFileRoute("/map")({ component: MapPage });

const TFS: Timeframe[] = ["1h", "24h", "7d", "30d", "90d", "1y"];
const SIZES: { id: SizeBy; label: string }[] = [
  { id: "heat", label: "Heat" },
  { id: "mcap", label: "Mcap" },
  { id: "volume", label: "Vol" },
  { id: "oi", label: "OI" },
  { id: "turnover", label: "Turn" },
];
const LAYS: { id: Layout; label: string }[] = [
  { id: "pack", label: "Pack" },
  { id: "sector", label: "Sectors" },
  { id: "galaxy", label: "Galaxy" },
  { id: "squeeze", label: "Squeeze" },
  { id: "cliff", label: "Cliff" },
];

function MapPage() {
  const universe = useUniverse();
  const { pins, toggle } = usePins();
  const [tf, setTf] = useState<Timeframe>("24h");
  const [sizeBy, setSizeBy] = useState<SizeBy>("heat");
  const [layout, setLayout] = useState<Layout>("pack");
  const [sector, setSector] = useState<Sector | "all">("all");
  const [hideStables, setHideStables] = useState(true);
  const [q, setQ] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [target, setTarget] = useState<BubbleCoin | null>(null);

  const coins = universe.data?.coins ?? [];
  const qn = q.trim().toUpperCase();
  const visible = useMemo(() => {
    return coins.filter((c) => {
      if (hideStables && isStable(c.symbol)) return false;
      if (sector !== "all" && c.sector !== sector) return false;
      if (qn && !c.symbol.includes(qn) && !c.name.toUpperCase().includes(qn)) return false;
      return true;
    });
  }, [coins, hideStables, sector, qn]);

  const onBubble = useCallback((c: BubbleCoin | null) => {
    setSelectedId(c?.id ?? null);
    if (c) setTarget(c);
  }, []);

  return (
    <div>
      <PageHead kicker="Living map" title="The market as a packed field." />
      {universe.data?.pulse ? <WeatherBar pulse={universe.data.pulse} onSector={setSector} /> : null}

      <div className="mb-2 flex flex-wrap gap-1">
        {TFS.map((t) => (
          <Chip key={t} active={tf === t} onClick={() => setTf(t)}>
            {t}
          </Chip>
        ))}
        <span className="mx-1 hidden h-11 w-px bg-line sm:block" />
        {SIZES.map((s) => (
          <Chip key={s.id} active={sizeBy === s.id} onClick={() => setSizeBy(s.id)}>
            {s.label}
          </Chip>
        ))}
        <span className="mx-1 hidden h-11 w-px bg-line sm:block" />
        {LAYS.map((s) => (
          <Chip key={s.id} active={layout === s.id} onClick={() => setLayout(s.id)}>
            {s.label}
          </Chip>
        ))}
      </div>
      <div className="mb-2 flex flex-wrap items-center gap-1">
        <Chip active={sector === "all"} onClick={() => setSector("all")}>
          All
        </Chip>
        {(["meme", "ai", "l1", "defi", "tradfi", "privacy"] as Sector[]).map((s) => (
          <Chip key={s} active={sector === s} onClick={() => setSector(s)}>
            {SECTOR_LABEL[s]}
          </Chip>
        ))}
        <button
          type="button"
          onClick={() => setHideStables((v) => !v)}
          className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase tracking-wide ${
            hideStables ? "bg-elevated text-muted" : "bg-accent text-accent-fg"
          }`}
        >
          {hideStables ? "Stables off" : "Stables on"}
        </button>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter ticker"
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 font-mono text-sm text-fg outline-none placeholder:text-faint focus:border-line-strong sm:max-w-xs"
        />
      </div>

      {universe.isLoading ? (
        <div className="skel h-[min(56vh,680px)] rounded-lg" />
      ) : universe.isError ? (
        <p className="rounded-lg border border-down/40 bg-down/10 px-4 py-3 text-sm text-down">Universe feed failed.</p>
      ) : (
        <BubbleField
          coins={visible}
          tf={tf}
          sizeBy={sizeBy}
          layout={layout}
          query=""
          selectedId={selectedId}
          pinned={pins}
          onSelect={onBubble}
        />
      )}

      <p className="mt-2 font-mono text-[10px] leading-relaxed text-faint">
        Color = {tf} change. Size = {sizeBy === "heat" ? "|%| × √volume" : sizeBy}. Red ring = short-hard. Inner ring =
        within 8% of ATH.
        {universe.data?.sourceNotes?.length ? ` · ${universe.data.sourceNotes.join(" · ")}` : ""}
      </p>
      <SignalFeed coins={visible} tf={tf} onOpen={onBubble} />

      <DetailSheet
        open={!!target}
        onOpenChange={(v) => {
          if (!v) {
            setTarget(null);
            setSelectedId(null);
          }
        }}
        target={target ? { mode: "bubble", item: target } : null}
        pinned={pins}
        onTogglePin={toggle}
      />
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-11 shrink-0 rounded-md px-3 font-mono text-[11px] uppercase tracking-wide ${
        active ? "bg-accent text-accent-fg" : "bg-surface text-muted hover:text-fg"
      }`}
    >
      {children}
    </button>
  );
}
