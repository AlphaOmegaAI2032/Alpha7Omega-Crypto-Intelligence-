import { createFileRoute } from "@tanstack/react-router";
import { fetchFlow } from "@/lib/market/flow";

export const Route = createFileRoute("/api/flow")({
  server: {
    handlers: {
      GET: async () => {
        try {
          return Response.json(await fetchFlow());
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "flow failed",
              tvl: 0,
              tvlChange1d: null,
              chains: [],
              protocols: [],
              yields: [],
              dexTotal24: 0,
              dexChange1d: null,
              dexes: [],
              cexes: [],
              cexVolBtc: 0,
              trending: [],
              boosts: [],
              notes: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
