import { createFileRoute } from "@tanstack/react-router";
import { fetchKlines } from "@/lib/market/book";

export const Route = createFileRoute("/api/klines")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const s = url.searchParams.get("s") || "BTCUSDT";
        const tf = url.searchParams.get("tf") || "1h";
        try {
          return Response.json(await fetchKlines(s, tf));
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "klines failed",
              symbol: s,
              contract: s,
              interval: tf,
              venue: "none",
              candles: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
