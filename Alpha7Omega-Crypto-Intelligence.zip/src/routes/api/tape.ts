import { createFileRoute } from "@tanstack/react-router";
import { fetchTape } from "@/lib/market/fetchers";

export const Route = createFileRoute("/api/tape")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await fetchTape();
          return Response.json(data);
        } catch (e) {
          return Response.json(
            { error: e instanceof Error ? e.message : "tape failed", movers: [], sourceNotes: [], updatedAt: Date.now() },
            { status: 500 },
          );
        }
      },
    },
  },
});
