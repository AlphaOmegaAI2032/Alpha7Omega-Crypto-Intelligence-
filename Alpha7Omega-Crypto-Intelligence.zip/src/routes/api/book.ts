import { createFileRoute } from "@tanstack/react-router";
import { fetchBtcBook } from "@/lib/market/book";

const empty = {
  error: "book failed",
  mid: 0,
  last: 0,
  change24: null,
  high24: null,
  low24: null,
  volume24: null,
  funding: null,
  oiUsd: null,
  spread: 0,
  imbalance: 0.5,
  bidUsd: 0,
  askUsd: 0,
  bids: [],
  asks: [],
  walls: [],
  pockets: [],
  band: 0.012,
  bucketPx: 10,
  nBuckets: 80,
  candles: [],
  spark: [],
  tape: [],
  read: "",
  source: "offline",
  venues: [],
  updatedAt: Date.now(),
};

export const Route = createFileRoute("/api/book")({
  server: {
    handlers: {
      GET: async () => {
        try {
          return Response.json(await fetchBtcBook());
        } catch (e) {
          return Response.json(
            { ...empty, error: e instanceof Error ? e.message : "book failed", updatedAt: Date.now() },
            { status: 500 },
          );
        }
      },
    },
  },
});
