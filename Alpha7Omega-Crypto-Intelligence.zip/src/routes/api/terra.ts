import { createFileRoute } from "@tanstack/react-router";
import { fetchTerra } from "@/lib/market/terra";

export const Route = createFileRoute("/api/terra")({
  server: {
    handlers: {
      GET: async () => {
        try {
          return Response.json(await fetchTerra());
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "terra failed",
              assets: [],
              classic: null,
              phoenix: null,
              burned: 0,
              burnedPct: 0,
              genesis: 0,
              perps: [],
              impostors: [],
              protocols: [],
              notes: [],
              read: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
