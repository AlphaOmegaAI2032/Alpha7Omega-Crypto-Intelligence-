import { createFileRoute } from "@tanstack/react-router";
import { fetchBtcBook } from "@/lib/market/book";
import { dhFades, dhLongs, scoreDeepHeat } from "@/lib/market/deepheat";
import { GODMODE_DESKS, type GodmodeDeskId } from "@/lib/market/godmode";
import { fetchNews } from "@/lib/market/news";
import { fetchTape } from "@/lib/market/fetchers";
import { fetchUniverse } from "@/lib/market/universe";
import { fetchIntel } from "@/lib/market/intel";
import { fetchMint } from "@/lib/market/mint";
import { CANON_MINT } from "@/lib/market/mint-canon";

type CacheRow = { at: number; day: string; text: string };
const cache = new Map<string, CacheRow>();

function utcDay() {
  return new Date().toISOString().slice(0, 10);
}

function compact(n: number) {
  if (Math.abs(n) >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (Math.abs(n) >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e3) return `${(n / 1e3).toFixed(1)}k`;
  return n.toFixed(4);
}

async function snapshot(desk: GodmodeDeskId): Promise<string> {
  const [uni, tape, news] = await Promise.all([
    fetchUniverse(),
    fetchTape(),
    fetchNews().catch(() => ({ items: [], sourceNotes: [] as string[] })),
  ]);
  const rows = scoreDeepHeat(uni.coins, tape.movers);
  const longs = dhLongs(rows, 8);
  const fades = dhFades(rows, 8);
  const pulse = uni.pulse;
  const hard = tape.movers.filter((m) => m.verdict === "SHORT_HARD" || m.verdict === "FADE").slice(0, 8);
  const lines: string[] = [];
  if (pulse) {
    lines.push(
      `PULSE F&G ${pulse.fng} ${pulse.fngLabel} · weather ${pulse.weather} · BTC.D ${pulse.btcDom.toFixed(1)}% · breadth ${pulse.breadthPct.toFixed(0)}% · mcap chg ${pulse.marketChange24.toFixed(2)}%`,
    );
    lines.push(`DESK ${pulse.deskNote}`);
  }
  const btc = uni.coins.find((c) => c.symbol === "BTC");
  const eth = uni.coins.find((c) => c.symbol === "ETH");
  const sol = uni.coins.find((c) => c.symbol === "SOL");
  if (btc) lines.push(`BTC ${btc.price} 24h ${btc.chg24h}% 1h ${btc.chg1h}%`);
  if (eth) lines.push(`ETH ${eth.price} 24h ${eth.chg24h}%`);
  if (sol) lines.push(`SOL ${sol.price} 24h ${sol.chg24h}%`);
  lines.push("DEEPHEAT LONGS");
  for (const r of longs) {
    lines.push(`${r.symbol} ${r.price} +${r.chg24.toFixed(1)}% DH ${r.dh} ${r.thesis} cliff ${r.cliff ?? "—"} fund ${r.funding ?? "—"}`);
  }
  lines.push("24H FADE SHORTS");
  for (const r of fades) {
    lines.push(`${r.symbol} ${r.price} +${r.chg24.toFixed(1)}% DH ${r.dh} fade ${r.fadeScore} ${r.thesis} pool/FDV ${r.poolPctFdv?.toFixed(2) ?? "—"}%`);
  }
  lines.push("CLIFF TAPE");
  for (const m of hard) {
    lines.push(
      `${m.symbol} ${m.verdict} score ${m.score} last ${m.perp?.last ?? m.dex?.priceUsd} fund ${m.perp?.funding ?? "—"} cliff ${m.cliff ?? "—"} · ${m.reasons[0] || m.note}`,
    );
  }
  if (desk === "whale") {
    const intel = await fetchIntel("MARSCOIN").catch(() => null);
    if (intel) {
      lines.push(`WHALES ${intel.symbol} drip=${intel.dripLive} sells ${compact(intel.flowSummary.sellUsd)} buys ${compact(intel.flowSummary.buyUsd)}`);
      for (const w of intel.whales.slice(0, 8)) {
        lines.push(`${w.verdict} ${w.label} tokens ${w.tokens} Δ ${w.delta} ${w.note}`);
      }
    }
  }
  if (desk === "sentinel") {
    const book = await fetchBtcBook().catch(() => null);
    if (book) {
      lines.push(`BTC BOOK mid ${book.mid} last ${book.last} chg ${book.change24}`);
      for (const w of book.walls) {
        lines.push(`WALL ${w.side} ${w.price} ${compact(w.usd)} ${w.pct.toFixed(2)}%`);
      }
    }
  }
  if (desk === "scribe" || desk === "macro") {
    lines.push("NEWS");
    for (const n of news.items.slice(0, 12)) {
      lines.push(`${n.bucket} · ${n.source} · ${n.title}`);
    }
  }
  if (desk === "assayer") {
    const dossier = await fetchMint(CANON_MINT).catch(() => null);
    if (dossier) {
      lines.push(
        `MINT ${dossier.symbol} ${dossier.mint} meta ${dossier.verdict.metadata} trade ${dossier.verdict.trade} pool ${compact(dossier.totalLiqUsd)} fdv ${compact(dossier.fdv ?? 0)}`,
      );
      lines.push(dossier.verdict.note);
      if (dossier.unipcs) {
        lines.push(`UNIPCS ${dossier.unipcs.amount} pct ${dossier.unipcs.pct} moved=${dossier.unipcs.moved}`);
      }
    }
  }
  return lines.join("\n");
}

function systemFor(id: GodmodeDeskId) {
  const d = GODMODE_DESKS.find((x) => x.id === id)!;
  return `You are the ${d.name} desk (${d.role}) on Alpha7Ωmega Crypto Intelligence. ${d.brief}
Research floor, not a broker. Isolated margin only. No emoji. No marketing. Concrete names, prices, invalidations, size rules.
If the window is still vertical, say WAIT. If it is a chip/ETF/privacy coin, say AVOID as a P&D.
End with a 4-line card: BIAS / NAMES / INVALIDATION / SIZE.`;
}

export const Route = createFileRoute("/api/godmode")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => ({}))) as { desk?: string; force?: boolean };
        const desk = GODMODE_DESKS.some((d) => d.id === body.desk) ? (body.desk as GodmodeDeskId) : "fade";
        const force = !!body.force;
        const day = utcDay();
        const hit = cache.get(desk);
        if (!force && hit && hit.day === day) {
          return Response.json({ ok: true, desk, text: hit.text, cached: true, at: hit.at });
        }
        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json({ ok: false, desk, error: "Godmode is not available in this environment.", cached: false, at: Date.now() });
        }
        const snap = await snapshot(desk);
        const res = await fetch("https://api.x.ai/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify({
            model: "grok-4.5",
            max_tokens: 1400,
            temperature: 0.2,
            messages: [
              { role: "system", content: systemFor(desk) },
              { role: "user", content: `Live snapshot (SAST tape):\n${snap}` },
            ],
          }),
        });
        if (!res.ok) {
          return Response.json({ ok: false, desk, error: `xAI ${res.status}`, cached: false, at: Date.now() });
        }
        const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
        const text = json.choices?.[0]?.message?.content ?? "";
        const row = { at: Date.now(), day, text };
        cache.set(desk, row);
        return Response.json({ ok: true, desk, text, cached: false, at: row.at });
      },
    },
  },
});
