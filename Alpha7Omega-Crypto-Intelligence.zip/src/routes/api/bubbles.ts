import { createFileRoute } from "@tanstack/react-router";
import { fetchUniverse } from "@/lib/market/universe";

export const Route = createFileRoute("/api/bubbles")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await fetchUniverse();
          return Response.json(data);
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "universe failed",
              coins: [],
              pulse: null,
              sourceNotes: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
