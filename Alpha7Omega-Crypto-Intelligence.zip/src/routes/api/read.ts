import { createFileRoute } from "@tanstack/react-router";
import { fetchFlow, flowSnapshot } from "@/lib/market/flow";
import { fetchNews } from "@/lib/market/news";
import { fetchIntel } from "@/lib/market/intel";

type Desk = "defi" | "exchanges" | "whales" | "rules" | "coins";
const DESKS: Desk[] = ["defi", "exchanges", "whales", "rules", "coins"];

type CacheRow = { at: number; day: string; text: string };
const cache = new Map<string, CacheRow>();

function utcDay() {
  return new Date().toISOString().slice(0, 10);
}

function systemFor(desk: Desk) {
  const role: Record<Desk, string> = {
    defi: "DeFi desk. TVL, chain rotation, protocol share, real yields vs farm bait. Name what is actually in demand.",
    exchanges: "Venue desk. CEX self-reported volume is inflated — say so. DEX volume is closer to truth. Market share, not marketing.",
    whales: "Whale desk. Inventory vs pool is the only chart that matters. Name drip, silent 2% bags, CEX routers.",
    rules: "Policy desk. Clarity Act, MiCA, FSCA/SARB, ETF, SEC, CFTC. What a trader in Johannesburg actually needs to know today.",
    coins: "Coin desk. Top-cap vs emerging. Trending is not a buy. Separate heat from a window.",
  };
  return `You are the ${desk} desk on Alpha7Ωmega Crypto Intelligence. ${role[desk]}
Research floor, not a broker. No emoji. No marketing. Concrete names and numbers. End with a 4-line card: BIAS / NAMES / INVALIDATION / WHAT TO IGNORE.`;
}

export const Route = createFileRoute("/api/read")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json().catch(() => ({}))) as { desk?: string; force?: boolean };
        const desk: Desk = DESKS.includes(body.desk as Desk) ? (body.desk as Desk) : "defi";
        const force = !!body.force;
        const day = utcDay();
        const hit = cache.get(desk);
        if (!force && hit && hit.day === day) {
          return Response.json({ ok: true, desk, text: hit.text, cached: true, at: hit.at });
        }
        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json({ ok: false, desk, error: "Grok read is not available in this environment.", cached: false, at: Date.now() });
        }
        const [flow, news] = await Promise.all([
          fetchFlow().catch(() => null),
          fetchNews().catch(() => ({ items: [] as { bucket: string; source: string; title: string }[] })),
        ]);
        const lines: string[] = [];
        if (flow) lines.push(flowSnapshot(flow));
        if (desk === "whales") {
          const intel = await fetchIntel("MARSCOIN").catch(() => null);
          if (intel) {
            lines.push(`WHALES ${intel.symbol} drip=${intel.dripLive} sellUsd ${intel.flowSummary.sellUsd} buyUsd ${intel.flowSummary.buyUsd}`);
            for (const w of intel.whales.slice(0, 8)) lines.push(`${w.verdict} ${w.label} ${w.note}`);
          }
        }
        if (desk === "rules" || desk === "coins") {
          lines.push("NEWS");
          for (const n of news.items.slice(0, 16)) lines.push(`${n.bucket} · ${n.source} · ${n.title}`);
        }
        const res = await fetch("https://api.x.ai/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify({
            model: "grok-4.5",
            max_tokens: 900,
            temperature: 0.2,
            messages: [
              { role: "system", content: systemFor(desk) },
              { role: "user", content: `Live snapshot:\n${lines.join("\n")}` },
            ],
          }),
        });
        if (!res.ok) {
          return Response.json({ ok: false, desk, error: `xAI ${res.status}`, cached: false, at: Date.now() });
        }
        const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
        const text = json.choices?.[0]?.message?.content ?? "";
        const row = { at: Date.now(), day, text };
        cache.set(desk, row);
        return Response.json({ ok: true, desk, text, cached: false, at: row.at });
      },
    },
  },
});
