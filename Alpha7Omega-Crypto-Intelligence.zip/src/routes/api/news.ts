import { createFileRoute } from "@tanstack/react-router";
import { fetchNews } from "@/lib/market/news";

export const Route = createFileRoute("/api/news")({
  server: {
    handlers: {
      GET: async () => {
        try {
          return Response.json(await fetchNews());
        } catch (e) {
          return Response.json(
            { error: e instanceof Error ? e.message : "news failed", items: [], sourceNotes: [], updatedAt: Date.now() },
            { status: 500 },
          );
        }
      },
    },
  },
});
