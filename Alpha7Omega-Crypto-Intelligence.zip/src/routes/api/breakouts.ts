import { createFileRoute } from "@tanstack/react-router";
import { fetchBreakouts } from "@/lib/market/fetchers";

export const Route = createFileRoute("/api/breakouts")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await fetchBreakouts();
          return Response.json(data);
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "breakouts failed",
              hits: [],
              sourceNotes: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
