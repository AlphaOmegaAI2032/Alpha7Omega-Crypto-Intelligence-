import { createFileRoute } from "@tanstack/react-router";
import { fetchMint } from "@/lib/market/mint";

export const Route = createFileRoute("/api/mint")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const mint = url.searchParams.get("m") || url.searchParams.get("mint") || undefined;
        try {
          const data = await fetchMint(mint);
          return Response.json(data);
        } catch (e) {
          return Response.json(
            { error: e instanceof Error ? e.message : "mint failed" },
            { status: 500 },
          );
        }
      },
    },
  },
});
