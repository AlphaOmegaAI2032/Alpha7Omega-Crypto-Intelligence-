import { createFileRoute } from "@tanstack/react-router";
import { fetchDaily } from "@/lib/market/intel";

export const Route = createFileRoute("/api/daily")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const data = await fetchDaily();
          return Response.json(data);
        } catch (e) {
          return Response.json(
            { error: e instanceof Error ? e.message : "daily failed" },
            { status: 500 },
          );
        }
      },
    },
  },
});
