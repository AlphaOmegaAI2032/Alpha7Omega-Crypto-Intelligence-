import { createFileRoute } from "@tanstack/react-router";
import { searchDex } from "@/lib/market/fetchers";

export const Route = createFileRoute("/api/search")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const q = new URL(request.url).searchParams.get("q") || "";
        try {
          const data = await searchDex(q);
          return Response.json(data);
        } catch (e) {
          return Response.json(
            {
              error: e instanceof Error ? e.message : "search failed",
              hits: [],
              sourceNotes: [],
              updatedAt: Date.now(),
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
