import { createFileRoute } from "@tanstack/react-router";
import { fetchIntel } from "@/lib/market/intel";

export const Route = createFileRoute("/api/intel")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const symbol = url.searchParams.get("symbol") || "MARSCOIN";
        try {
          const data = await fetchIntel(symbol);
          return Response.json(data);
        } catch (e) {
          return Response.json(
            { error: e instanceof Error ? e.message : "intel failed", symbol },
            { status: 500 },
          );
        }
      },
    },
  },
});
