import { createFileRoute } from "@tanstack/react-router";
import {
  AssetCard,
  ChainCard,
  DualOrbs,
  ImpostorTape,
  PerpSeats,
  ProtoList,
  SupplyStack,
  VerdictList,
} from "@/components/terra-desk";
import { PageHead } from "@/components/page-head";
import { ago } from "@/lib/market/format";
import { useTerra } from "@/lib/market/hooks";

export const Route = createFileRoute("/terra")({ component: TerraPage });

function TerraPage() {
  const q = useTerra();
  const d = q.data;
  const lunc = d?.assets.find((a) => a.id === "lunc");
  const luna = d?.assets.find((a) => a.id === "luna");
  const ustc = d?.assets.find((a) => a.id === "ustc");
  const err = q.isError ? ((q.error as Error)?.message ?? "desk failed") : null;

  return (
    <div>
      <PageHead
        kicker="Terra desk"
        title="LUNA vs LUNC — chain, not ticker"
        right={d ? ago(d.updatedAt) : undefined}
      />
      <p className="mb-4 max-w-3xl text-sm leading-relaxed text-muted">
        Live columbus-5 and phoenix-1 LCD, Gecko books, Gate perps, Llama TVL, DexScreener impostors. If it says LUNA
        and the price has three extra zeros, it is a mint — not Do Kwon's chain.
      </p>

      {q.isLoading && !d ? <div className="skel mb-4 h-36 rounded-xl" /> : null}
      {err && !d ? <p className="mb-4 text-sm text-down">{err}</p> : null}

      {d ? (
        <div className="space-y-6">
          <VerdictList lines={d.read} />

          {lunc && luna ? <DualOrbs lunc={lunc} luna={luna} /> : null}

          <div className="grid gap-3 sm:grid-cols-3">
            {lunc ? <AssetCard a={lunc} /> : null}
            {luna ? <AssetCard a={luna} /> : null}
            {ustc ? <AssetCard a={ustc} /> : null}
          </div>

          <ImpostorTape rows={d.impostors} />

          {d.classic ? (
            <SupplyStack
              genesis={d.genesis}
              burned={d.burned}
              bonded={d.classic.bonded}
              unbonding={d.classic.unbonding}
              supply={d.classic.supply}
            />
          ) : null}

          <div className="grid gap-3 lg:grid-cols-2">
            {d.classic ? <ChainCard c={d.classic} /> : null}
            {d.phoenix ? <ChainCard c={d.phoenix} /> : null}
          </div>

          <PerpSeats rows={d.perps} />
          <ProtoList rows={d.protocols} />

          {d.notes.length ? (
            <p className="font-mono text-[11px] text-faint">{d.notes.join(" · ")}</p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
