import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHead } from "@/components/page-head";
import type { WatchBias } from "@/lib/market/client-store";
import { pct, px } from "@/lib/market/format";
import { useTape, useUniverse } from "@/lib/market/hooks";
import { useWatchList } from "@/lib/market/use-desk";

export const Route = createFileRoute("/watch")({ component: WatchPage });

function WatchPage() {
  const { items, add, remove } = useWatchList();
  const [sym, setSym] = useState("");
  const [bias, setBias] = useState<WatchBias>("watch");
  const universe = useUniverse();
  const tape = useTape(true);
  const prices = useMemo(() => {
    const p: Record<string, { price: number; chg: number | null }> = {};
    for (const c of universe.data?.coins ?? []) p[c.symbol] = { price: c.price, chg: c.chg24h };
    for (const m of tape.data?.movers ?? []) {
      const last = m.perp?.last ?? m.dex?.priceUsd;
      if (last) p[m.symbol.toUpperCase()] = { price: last, chg: m.perp?.change24h ?? m.dex?.changeH24 ?? null };
    }
    return p;
  }, [universe.data, tape.data]);

  return (
    <div>
      <PageHead kicker="Watch" title="Names you actually care about" />
      <p className="mb-4 text-sm text-muted">
        Seeded with the live book: MARSCOIN / USELESS / BULLA shorts, RENDER stalk, RAY respect, ZEC / RAIL privacy.
        Bias is yours. Isolated.
      </p>
      <form
        className="mb-5 flex flex-wrap gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          add(sym, bias);
          setSym("");
        }}
      >
        <input
          value={sym}
          onChange={(e) => setSym(e.target.value.toUpperCase())}
          placeholder="MARSCOIN"
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 font-mono text-sm outline-none sm:max-w-xs"
        />
        {(["watch", "long", "short"] as const).map((b) => (
          <button
            key={b}
            type="button"
            onClick={() => setBias(b)}
            className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase ${
              bias === b ? "bg-accent text-accent-fg" : "bg-surface text-muted"
            }`}
          >
            {b}
          </button>
        ))}
        <button type="submit" className="h-11 rounded-md bg-elevated px-4 text-sm">
          Add
        </button>
      </form>
      <ul className="space-y-2">
        {items.map((i) => {
          const q = prices[i.symbol];
          return (
            <li key={i.symbol} className="glass flex items-center justify-between gap-3 rounded-xl p-4">
              <div>
                <Link to="/ta" search={{ s: `${i.symbol}USDT` }} className="font-mono text-sm font-semibold hover:underline">
                  {i.symbol}
                </Link>
                <div className={`font-mono text-[10px] uppercase ${i.bias === "short" ? "text-down" : i.bias === "long" ? "text-up" : "text-muted"}`}>
                  {i.bias}
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono tabular">{px(q?.price)}</div>
                <div className={`font-mono text-xs tabular ${(q?.chg ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                  {pct(q?.chg)}
                </div>
              </div>
              <button type="button" onClick={() => remove(i.symbol)} className="h-11 px-3 text-xs text-muted hover:text-fg">
                Remove
              </button>
            </li>
          );
        })}
        {!items.length ? <p className="text-sm text-muted">Empty. Pin a fade or a break window.</p> : null}
      </ul>
    </div>
  );
}
