import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { IntelPanel } from "@/components/intel-panel";
import { PageHead } from "@/components/page-head";
import { CT_CLUSTERS, INFLUENCERS } from "@/lib/market/ct";
import { ago, pct, px } from "@/lib/market/format";
import { useBreakouts, useDaily, useNews, useUniverse } from "@/lib/market/hooks";
import { LISTINGS, pumpLabel } from "@/lib/market/listings";
import type { NewsBucket } from "@/lib/market/news";
import { PRIVACY, PRIVACY_NOTES } from "@/lib/market/privacy";

export const Route = createFileRoute("/intel")({ component: IntelPage });

type Tab = "onchain" | "diary" | "listings" | "privacy" | "ct";
const BUCKETS: { id: NewsBucket; label: string }[] = [
  { id: "all", label: "All" },
  { id: "clarity", label: "Clarity Act" },
  { id: "fed", label: "Fed / dots" },
  { id: "orange", label: "Orange Wire" },
  { id: "tweet", label: "Tweet tape" },
  { id: "xai", label: "xAI news" },
  { id: "listings", label: "Listings" },
];

function IntelPage() {
  const [tab, setTab] = useState<Tab>("onchain");
  const [symbol, setSymbol] = useState("MARSCOIN");
  const [bucket, setBucket] = useState<NewsBucket>("all");
  const news = useNews();
  const daily = useDaily();
  const brk = useBreakouts(tab === "listings");
  const universe = useUniverse();
  const items = useMemo(() => {
    const list = news.data?.items ?? [];
    if (bucket === "all") return list;
    return list.filter((i) => i.bucket === bucket);
  }, [news.data, bucket]);
  const quotes = useMemo(() => {
    const q: Record<string, { price: number; chg: number | null }> = {};
    for (const c of universe.data?.coins ?? []) q[c.symbol] = { price: c.price, chg: c.chg24h };
    return q;
  }, [universe.data]);

  return (
    <div>
      <PageHead kicker="Fundamentals diary" title="Clarity, Orange Wire, Fed, listings, privacy, CT." />
      <p className="mb-4 max-w-3xl text-sm text-muted">
        Dated buckets. Godmode Scribe and Macro write into this tape. On-chain is the tax / whale desk. Privacy and CT
        are the names the gainer board hid.
      </p>
      <div className="mb-4 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1">
        {([
          ["onchain", "On-chain"],
          ["diary", "Diary"],
          ["listings", "Listings / TGE"],
          ["privacy", "Privacy"],
          ["ct", "CT"],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`h-11 flex-1 rounded-md px-3 text-sm ${tab === id ? "bg-accent text-accent-fg" : "text-muted"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "onchain" ? <IntelPanel symbol={symbol} onSymbol={setSymbol} /> : null}

      {tab === "diary" ? (
        <div>
          {daily.data ? (
            <section className="glass mb-4 rounded-xl p-4">
              <p className="font-mono text-[10px] uppercase tracking-widest text-faint">Daily</p>
              <h2 className="mt-1 text-lg font-medium">{daily.data.headline}</h2>
              <ul className="mt-3 space-y-1 text-sm text-muted">
                {daily.data.thesis.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </section>
          ) : null}
          <div className="mb-3 flex flex-wrap gap-1">
            {BUCKETS.map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => setBucket(b.id)}
                className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase ${
                  bucket === b.id ? "bg-accent text-accent-fg" : "bg-surface text-muted"
                }`}
              >
                {b.label}
              </button>
            ))}
          </div>
          <ul className="space-y-2">
            {items.map((n) => (
              <li key={n.id} className="glass rounded-xl p-4">
                <a href={n.url} target="_blank" rel="noreferrer" className="text-sm font-medium hover:underline">
                  {n.title}
                </a>
                <div className="mt-1 font-mono text-[11px] text-faint">
                  {n.source} · {n.bucket} · {ago(n.at)}
                </div>
              </li>
            ))}
            {!items.length ? <p className="text-sm text-muted">Wire is quiet on this bucket.</p> : null}
          </ul>
        </div>
      ) : null}

      {tab === "listings" ? (
        <div className="space-y-4">
          <p className="text-sm text-muted">
            Robinson-class ICO / Alpha / TGE book. High pump score = loud retail promise on a thin pool. First print
            belongs to the listing. Second session is the fade.
          </p>
          <div className="grid gap-2 lg:grid-cols-2">
            {LISTINGS.map((row) => (
              <article key={row.id} className="glass rounded-xl p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-mono font-semibold">{row.symbol}</span>
                  <span className={`font-mono text-[10px] uppercase ${row.pump >= 80 ? "text-down" : "text-wait"}`}>
                    {pumpLabel(row.pump)} {row.pump}
                  </span>
                </div>
                <p className="mt-1 text-sm">{row.name}</p>
                <p className="mt-1 text-xs text-muted">{row.note}</p>
                <p className="mt-2 font-mono text-[10px] uppercase text-faint">
                  {row.venue} · {row.status} · {row.narrative}
                </p>
              </article>
            ))}
          </div>
          <p className="text-sm text-muted">Live DexScreener pump tape (young pool × volume).</p>
          <div className="grid gap-2 lg:grid-cols-2">
            {(brk.data?.hits ?? []).slice(0, 12).map((h) => (
              <article key={h.id} className="glass rounded-xl p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="font-mono font-semibold">{h.symbol}</span>
                  <span className="font-mono text-xs text-muted">score {h.score}</span>
                </div>
                <p className="mt-1 text-xs text-muted">{h.reasons[0]}</p>
                <p className="mt-1 font-mono text-[10px] uppercase text-faint">
                  {h.chain} · {h.source} · {h.verdict}
                </p>
              </article>
            ))}
          </div>
        </div>
      ) : null}

      {tab === "privacy" ? (
        <div className="space-y-4">
          <p className="text-sm text-muted">{PRIVACY_NOTES[0]}</p>
          <div className="grid gap-3 lg:grid-cols-2">
            {PRIVACY.map((c) => {
              const q = quotes[c.sym];
              return (
                <article key={c.sym} className="glass rounded-xl p-4">
                  <div className="flex items-baseline justify-between gap-2">
                    <Link to="/ta" search={{ s: `${c.sym}USDT` }} className="font-mono font-semibold hover:underline">
                      {c.sym}
                    </Link>
                    <span className="font-mono text-[10px] uppercase text-muted">{c.radar}</span>
                  </div>
                  <div className="mt-1 flex items-baseline justify-between">
                    <span className="text-sm text-muted">{c.name}</span>
                    {q ? (
                      <span className={`font-mono text-xs tabular ${ (q.chg ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                        {px(q.price)} {pct(q.chg)}
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-2 text-sm text-muted">{c.thesis}</p>
                  <p className="mt-2 font-mono text-[10px] text-faint">{c.levels}</p>
                </article>
              );
            })}
          </div>
          <ul className="space-y-1 text-xs text-muted">
            {PRIVACY_NOTES.slice(1).map((n) => (
              <li key={n}>{n}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {tab === "ct" ? (
        <div className="space-y-4">
          <div className="grid gap-3 lg:grid-cols-2">
            {CT_CLUSTERS.map((c) => (
              <article key={c.title} className="glass rounded-xl p-4">
                <h3 className="text-sm font-medium">{c.title}</h3>
                <p className="mt-1 font-mono text-xs text-muted">{c.handles}</p>
                <p className="mt-2 text-sm text-muted">{c.rule}</p>
                <p className="mt-2 font-mono text-[10px] text-faint">{c.tape}</p>
              </article>
            ))}
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            {INFLUENCERS.map((i) => (
              <article key={i.handle} className="glass rounded-xl p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <a
                    href={`https://x.com/${i.handle}`}
                    target="_blank"
                    rel="noreferrer"
                    className="font-mono text-sm hover:underline"
                  >
                    @{i.handle}
                  </a>
                  <span className="text-xs text-muted">{i.lane}</span>
                </div>
                <p className="mt-1 text-sm">{i.name}</p>
                <p className="mt-1 text-xs text-muted">{i.bias}</p>
                <p className="mt-2 font-mono text-[10px] text-faint">{i.watch}</p>
              </article>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}