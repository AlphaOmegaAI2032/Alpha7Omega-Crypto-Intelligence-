import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { DepthLadder, LiqHeatmap, bandLabel, imbTone, type HeatBand } from "@/components/liq-heatmap";
import { PageHead } from "@/components/page-head";
import { Sparkline } from "@/components/sparkline";
import { fundingPct, pct, px, usd } from "@/lib/market/format";
import { useBtcBook } from "@/lib/market/hooks";

export const Route = createFileRoute("/btc")({ component: BtcPage });

const BANDS: HeatBand[] = [0.006, 0.012, 0.025, 0.05, "48h"];
type View = "heat" | "ladder";

function BtcPage() {
  const book = useBtcBook();
  const data = book.data;
  const [band, setBand] = useState<HeatBand>("48h");
  const [view, setView] = useState<View>("heat");

  const walls = useMemo(() => {
    if (!data) return [];
    return data.walls.filter((w) => w.size >= 0.05).slice(0, 8);
  }, [data]);

  return (
    <div>
      <PageHead
        kicker="Sentinel"
        title="BTC liquidity heatmap"
        right={data ? `${data.source}` : undefined}
      />
      {data ? (
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span
            className={`inline-flex items-center rounded-md px-2 py-1 font-mono text-xs tabular ${
              (data.change24 ?? 0) >= 0 ? "bg-up/15 text-up" : "bg-down/15 text-down"
            }`}
          >
            {px(data.last)} · {pct(data.change24)}
          </span>
          <span className="font-mono text-[11px] text-muted">{data.read}</span>
        </div>
      ) : null}

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex gap-1 overflow-x-auto">
          {BANDS.map((b) => (
            <button
              key={String(b)}
              type="button"
              onClick={() => setBand(b)}
              className={`h-10 shrink-0 rounded-sm px-3 text-sm ${
                band === b ? "bg-accent text-accent-fg" : "text-muted hover:bg-elevated hover:text-fg"
              }`}
            >
              {bandLabel(b)}
            </button>
          ))}
        </div>
        <div className="ml-auto flex gap-1">
          {(["heat", "ladder"] as const).map((v) => (
            <button
              key={v}
              type="button"
              onClick={() => setView(v)}
              className={`h-10 rounded-sm px-3 text-sm capitalize ${
                view === v ? "bg-elevated text-fg" : "text-muted hover:text-fg"
              }`}
            >
              {v === "heat" ? "Heat" : "Ladder"}
            </button>
          ))}
        </div>
      </div>

      {book.isLoading && !data ? <div className="skel h-[min(56vh,560px)] min-h-[320px] rounded-xl" /> : null}

      {data ? (
        <>
          <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
            <Kpi label="Mid" value={px(data.mid)} hint={`spread ${data.spread.toFixed(1)}`} />
            <Kpi
              label="Last"
              value={px(data.last)}
              hint={pct(data.change24)}
              tone={(data.change24 ?? 0) >= 0 ? "text-up" : "text-down"}
            />
            <Kpi
              label="Imbalance"
              value={`${(data.imbalance * 100).toFixed(0)}% bid`}
              hint={`${usd(data.bidUsd, 0)} / ${usd(data.askUsd, 0)}`}
              tone={imbTone(data.imbalance)}
            />
            <Kpi label="24h high" value={data.high24 ? px(data.high24) : "—"} hint={data.low24 ? `low ${px(data.low24)}` : undefined} />
            <Kpi label="Quote vol" value={usd(data.volume24, 0)} hint={data.oiUsd ? `OI ${usd(data.oiUsd, 0)}` : "perp"} />
            <Kpi
              label="Funding"
              value={fundingPct(data.funding)}
              hint="USDT-M"
              tone={(data.funding ?? 0) >= 0 ? "text-up" : "text-down"}
            />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <section className="glass rounded-xl p-3 sm:p-4 lg:col-span-2">
              <div className="mb-2 flex items-end justify-between gap-2">
                <div>
                  <h2 className="text-sm font-medium">Spot book {band === "48h" ? "over 48h" : `±${typeof band === "number" ? (band * 100).toFixed(1) : "1.2"}% of mid`}</h2>
                  <p className="text-xs text-muted">
                    Heat is volume-at-price over 48h. The right rail is live rest. Green stacks bids, red stacks asks. Tall bars are walls.
                  </p>
                </div>
                {data.spark.length > 8 ? <Sparkline values={data.spark} className="h-8 w-28 shrink-0" /> : null}
              </div>
              {view === "heat" ? <LiqHeatmap book={data} band={band} /> : <DepthLadder book={data} band={band} />}
            </section>

            <div className="space-y-4">
              <section className="glass rounded-xl p-4">
                <h2 className="text-sm font-medium">Largest walls</h2>
                <ul className="mt-3 space-y-2">
                  {walls.map((w) => (
                    <li key={`${w.side}-${w.price}`} className="flex items-baseline justify-between gap-2 text-sm">
                      <span className={`w-8 font-mono text-[11px] uppercase ${w.side === "bid" ? "text-up" : "text-down"}`}>
                        {w.side}
                      </span>
                      <span className="font-mono tabular">{w.price.toFixed(0)}</span>
                      <span className="font-mono text-xs tabular text-fg">{w.size.toFixed(2)} BTC</span>
                      <span className="font-mono text-[11px] tabular text-muted">{usd(w.usd, 0)}</span>
                    </li>
                  ))}
                  {!walls.length ? <li className="text-sm text-muted">No walls in this band.</li> : null}
                </ul>
              </section>

              <section className="glass rounded-xl p-4">
                <h2 className="text-sm font-medium">Air pockets</h2>
                <ul className="mt-3 space-y-2">
                  {data.pockets.map((p) => (
                    <li key={`${p.side}-${p.lo}`} className="flex items-center justify-between gap-2 text-sm">
                      <span className={`font-mono text-[11px] uppercase ${p.side === "bid" ? "text-up" : "text-down"}`}>
                        {p.side}
                      </span>
                      <span className="font-mono text-xs tabular text-muted">
                        {p.lo.toFixed(0)} – {p.hi.toFixed(0)}
                      </span>
                      <span className="font-mono text-[11px] text-faint">thin</span>
                    </li>
                  ))}
                  {!data.pockets.length ? <li className="text-sm text-muted">No air in the ±1.2% band.</li> : null}
                </ul>
              </section>
            </div>
          </div>
        </>
      ) : book.isError ? (
        <p className="rounded-xl border border-dashed border-line px-4 py-10 text-center text-sm text-muted">
          Spot book not on the wire right now.
        </p>
      ) : null}
    </div>
  );
}

function Kpi({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: string;
}) {
  return (
    <section className="glass min-w-[9.5rem] shrink-0 rounded-xl p-3">
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted">{label}</p>
      <p className={`mt-1 font-mono text-lg tabular ${tone || "text-fg"}`}>{value}</p>
      {hint ? <p className="mt-1 truncate font-mono text-[11px] text-faint">{hint}</p> : null}
    </section>
  );
}
