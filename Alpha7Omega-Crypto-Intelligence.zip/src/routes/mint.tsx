import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { PageHead } from "@/components/page-head";
import { pct, px, usd } from "@/lib/market/format";
import {
  BLIND_SPOTS,
  CANON,
  CANON_MINT,
  COMPARE,
  VERIFY_STEPS,
} from "@/lib/market/mint-canon";
import type { AuthStatus, MintDossier } from "@/lib/market/mint";

export const Route = createFileRoute("/mint")({
  validateSearch: (s: Record<string, unknown>): { m?: string } => ({
    m: typeof s.m === "string" && s.m.length > 20 ? s.m : undefined,
  }),
  component: MintPage,
});

function useMint(mint: string) {
  return useQuery({
    queryKey: ["mint", mint],
    queryFn: async () => {
      const r = await fetch(`/api/mint?m=${encodeURIComponent(mint)}`);
      if (!r.ok) throw new Error(`mint ${r.status}`);
      return (await r.json()) as MintDossier;
    },
    refetchInterval: 30_000,
  });
}

function authClass(s: AuthStatus) {
  if (s === "revoked" || s === "immutable") return "text-up";
  if (s === "live" || s === "mutable") return "text-down";
  return "text-wait";
}

function MintPage() {
  const { m } = Route.useSearch();
  const navigate = useNavigate({ from: "/mint" });
  const mint = m && m.length >= 32 ? m : CANON_MINT;
  const [draft, setDraft] = useState(mint);
  const q = useMint(mint);
  const d = q.data;
  const main = d?.pairs[0];
  const perpOi = d?.perps.reduce((s, p) => s + (p.oiUsd ?? 0), 0) ?? 0;
  const pool = main?.liqUsd ?? d?.totalLiqUsd ?? 0;
  const cliff = pool > 0 && (d?.fdv || 0) > 0 ? (d!.fdv as number) / pool : null;
  const oiX = pool > 0 && perpOi > 0 ? perpOi / pool : null;

  const go = (value: string) => {
    const next = value.trim().replace(/\s/g, "");
    setDraft(next);
    void navigate({ search: next && next !== CANON_MINT ? { m: next } : {} });
  };

  return (
    <div>
      <PageHead kicker="Mint desk" title="Authorities vs the bag" />
      <p className="mb-4 max-w-3xl text-sm text-muted">
        Clean metadata only means nobody can print, freeze, or rebrand you. The unwind is still wallets and perps
        against a thin pool. Canonical USELESS mint ends in <span className="font-mono text-fg">Mbonk</span>.
      </p>

      <form
        className="mb-5 flex flex-wrap gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          go(draft);
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          spellCheck={false}
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 font-mono text-xs outline-none"
        />
        <button type="submit" className="h-11 rounded-md bg-accent px-4 text-sm text-accent-fg">
          Read CA
        </button>
        <button
          type="button"
          className="h-11 rounded-md bg-elevated px-3 font-mono text-xs"
          onClick={() => go(CANON_MINT)}
        >
          Canonical
        </button>
      </form>

      {q.isLoading && !d ? (
        <div className="skel flex h-40 items-center justify-center rounded-xl font-mono text-xs text-muted">
          Reading mint / freeze / Unipcs bag…
        </div>
      ) : null}
      {q.isError ? <p className="text-sm text-down">Scanner miss. Try again.</p> : null}

      {d ? (
        <div className="space-y-4">
          <section className="glass rounded-xl p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-faint">
                  {d.canonical ? "Canonical" : d.clone ? "Clone / reject" : "Unknown mint"}
                </p>
                <h2 className="mt-1 text-lg font-medium">
                  {d.symbol} · {d.name}
                </h2>
              </div>
              <div className="text-right">
                <p className="font-mono text-xl tabular">{px(d.priceUsd)}</p>
                <p className={`font-mono text-xs uppercase ${d.verdict.trade === "fade" ? "text-down" : d.verdict.trade === "reject" ? "text-wait" : "text-muted"}`}>
                  metadata {d.verdict.metadata} · trade {d.verdict.trade}
                </p>
              </div>
            </div>
            <p className="mt-3 text-sm text-muted">{d.verdict.note}</p>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Kpi label="Pool" value={usd(pool, 0)} />
              <Kpi label="FDV" value={usd(d.fdv, 0)} />
              <Kpi label="Cliff" value={cliff ? `${cliff.toFixed(1)}x` : "—"} />
              <Kpi label="Perps / pool" value={oiX ? `${oiX.toFixed(1)}x` : "—"} />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <Auth label="Mint" value={d.mintAuth} />
              <Auth label="Freeze" value={d.freezeAuth} />
              <Auth label="Update" value={d.updateAuth} />
            </div>
            <p className="mt-3 break-all font-mono text-[11px] text-faint">{d.mint}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="h-11 rounded-md bg-elevated px-3 text-xs"
                onClick={() => navigator.clipboard.writeText(d.mint)}
              >
                Copy CA
              </button>
              <Link to="/shorts" className="flex h-11 items-center rounded-md bg-elevated px-3 text-xs">
                Fade book
              </Link>
              <Link to="/ta" search={{ s: `${d.symbol}USDT` }} className="flex h-11 items-center rounded-md bg-elevated px-3 text-xs">
                Chart
              </Link>
            </div>
          </section>

          {d.unipcs ? (
            <section className="glass rounded-xl p-4">
              <h3 className="text-sm font-medium">Unipcs / Bonk Guy bag</h3>
              <p className="mt-2 font-mono text-sm tabular">
                {d.unipcs.amount.toLocaleString()} · {d.unipcs.pct.toFixed(2)}% · baseline {d.unipcs.baseline.toLocaleString()}
              </p>
              <p className={`mt-1 font-mono text-xs uppercase ${d.unipcs.moved ? "text-down" : "text-wait"}`}>
                {d.unipcs.moved ? "Moved off 15.9M — dump may have started" : "Still sitting — fade, don't chase"}
              </p>
            </section>
          ) : null}

          <div className="grid gap-3 lg:grid-cols-2">
            <section className="glass rounded-xl p-4">
              <h3 className="text-sm font-medium">Pools</h3>
              <ul className="mt-3 space-y-2">
                {d.pairs.map((p) => (
                  <li key={p.pair || p.url} className="flex items-baseline justify-between gap-2 text-sm">
                    <a href={p.url} target="_blank" rel="noreferrer" className="truncate hover:underline">
                      {p.dex} · {p.name}
                    </a>
                    <span className="font-mono text-xs tabular text-muted">{usd(p.liqUsd, 0)}</span>
                  </li>
                ))}
                {!d.pairs.length ? <p className="text-sm text-muted">No Solana pairs hydrated.</p> : null}
              </ul>
            </section>
            <section className="glass rounded-xl p-4">
              <h3 className="text-sm font-medium">Perps</h3>
              <ul className="mt-3 space-y-2">
                {d.perps.map((p) => (
                  <li key={p.venue} className="flex items-baseline justify-between text-sm">
                    <span>{p.venue}</span>
                    <span className="font-mono text-xs tabular">
                      {px(p.last)} · {pct(p.pct24)} · OI {usd(p.oiUsd, 0)}
                    </span>
                  </li>
                ))}
                {!d.perps.length ? <p className="text-sm text-muted">No perp tape.</p> : null}
              </ul>
            </section>
          </div>

          <section className="glass rounded-xl p-4">
            <h3 className="text-sm font-medium">USELESS vs MARSCOIN</h3>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full min-w-[520px] text-left text-sm">
                <thead className="text-[11px] uppercase tracking-widest text-muted">
                  <tr className="border-b border-line">
                    <th className="py-2 font-medium">Field</th>
                    <th className="py-2 font-medium">USELESS</th>
                    <th className="py-2 font-medium">MARSCOIN</th>
                  </tr>
                </thead>
                <tbody>
                  {COMPARE.map((c) => (
                    <tr key={c.field} className="border-b border-line/70">
                      <td className="py-2 text-muted">{c.field}</td>
                      <td className="py-2">{c.useless}</td>
                      <td className="py-2">{c.mars}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="glass rounded-xl p-4">
            <h3 className="text-sm font-medium">What metadata does not tell you</h3>
            <ul className="mt-3 space-y-2">
              {BLIND_SPOTS.map((b) => (
                <li key={b.title}>
                  <p className="text-sm">{b.title}</p>
                  <p className="text-xs text-muted">{b.body}</p>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex flex-wrap gap-2">
              {VERIFY_STEPS.map((s) => (
                <a
                  key={s.label}
                  href={s.href(d.mint)}
                  target="_blank"
                  rel="noreferrer"
                  className="h-11 rounded-md bg-elevated px-3 text-xs leading-[2.75rem]"
                >
                  {s.label}
                </a>
              ))}
            </div>
            <p className="mt-3 text-xs text-faint">{CANON.ctoNote}</p>
          </section>
        </div>
      ) : null}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</p>
      <p className="mt-1 font-mono text-sm tabular">{value}</p>
    </div>
  );
}

function Auth({ label, value }: { label: string; value: AuthStatus }) {
  return (
    <div className="rounded-md bg-elevated px-2 py-3">
      <p className="font-mono text-[10px] uppercase tracking-widest text-faint">{label}</p>
      <p className={`mt-1 font-mono text-xs uppercase ${authClass(value)}`}>{value}</p>
    </div>
  );
}
