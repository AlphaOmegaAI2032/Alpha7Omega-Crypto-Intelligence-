import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CandleChart } from "@/components/candle-chart";
import { PageHead } from "@/components/page-head";
import { dhFades, scoreDeepHeat } from "@/lib/market/deepheat";
import { fundingPct, pct, px } from "@/lib/market/format";
import { useKlines, useTape, useUniverse } from "@/lib/market/hooks";

type TaSearch = { s?: string; tf?: string };

export const Route = createFileRoute("/ta")({
  validateSearch: (s: Record<string, unknown>): TaSearch => ({
    s: typeof s.s === "string" ? s.s : undefined,
    tf: typeof s.tf === "string" ? s.tf : undefined,
  }),
  component: TaPage,
});

const TFS = ["15m", "1h", "4h", "1d"] as const;
const QUICK = ["BTC", "ETH", "SOL", "FF", "USELESS", "IOST", "MARSCOIN", "VVV", "ZEC"];

function TaPage() {
  const search = Route.useSearch();
  const [symbol, setSymbol] = useState((search.s || "BTCUSDT").replace(/[^A-Za-z0-9]/g, "").toUpperCase());
  const [tf, setTf] = useState(search.tf && TFS.includes(search.tf as (typeof TFS)[number]) ? search.tf : "1h");
  const [input, setInput] = useState(symbol);
  const [note, setNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const klines = useKlines(symbol, tf);
  const universe = useUniverse();
  const tape = useTape(true);
  const rows = useMemo(
    () => scoreDeepHeat(universe.data?.coins ?? [], tape.data?.movers ?? []),
    [universe.data?.coins, tape.data?.movers],
  );
  const base = symbol.replace(/USDT$/, "");
  const row = rows.find((r) => r.symbol.toUpperCase() === base);
  const mover = tape.data?.movers.find((m) => m.symbol.toUpperCase() === base);
  const last = klines.data?.candles.at(-1);

  async function loadBrief() {
    setBusy(true);
    try {
      const res = await fetch("/api/godmode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ desk: "chartist", force: false }),
      });
      const json = (await res.json()) as { ok?: boolean; text?: string; error?: string };
      setNote(json.text || json.error || "No brief.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHead kicker="Chartist" title="AI-augmented pattern book" />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value.toUpperCase())}
          onKeyDown={(e) => {
            if (e.key === "Enter") setSymbol(input.replace(/[^A-Z0-9]/g, ""));
          }}
          placeholder="MARSCOINUSDT"
          className="h-11 min-w-0 flex-1 rounded-md border border-line bg-surface px-3 font-mono text-sm outline-none sm:max-w-xs"
        />
        <button
          type="button"
          onClick={() => setSymbol(input.replace(/[^A-Z0-9]/g, ""))}
          className="h-11 rounded-md bg-accent px-4 text-sm text-accent-fg"
        >
          Load
        </button>
        {TFS.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTf(t)}
            className={`h-11 rounded-md px-3 font-mono text-[11px] uppercase ${tf === t ? "bg-accent text-accent-fg" : "bg-surface text-muted"}`}
          >
            {t}
          </button>
        ))}
        {QUICK.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              setInput(`${s}USDT`);
              setSymbol(`${s}USDT`);
            }}
            className={`h-11 rounded-md px-3 font-mono text-[11px] ${base === s ? "bg-elevated text-fg" : "text-muted"}`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="glass rounded-xl p-4">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="font-mono text-lg font-semibold">{base}</div>
            <div className="font-mono text-xs text-faint">
              {klines.data?.venue || "—"} · {tf}
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-2xl tabular">{px(last?.c ?? row?.price)}</div>
            <div className={`font-mono text-xs tabular ${(row?.chg24 ?? 0) >= 0 ? "text-up" : "text-down"}`}>
              {pct(row?.chg24)} 24h
              {mover?.perp ? ` · fund ${fundingPct(mover.perp.funding)}` : ""}
            </div>
          </div>
        </div>
        {klines.isLoading ? <div className="skel h-[280px] rounded-lg" /> : <CandleChart candles={klines.data?.candles ?? []} />}
      </div>

      {row ? (
        <p className="mt-3 text-sm leading-relaxed text-muted">
          {row.thesis} DH {row.dh} · fade {row.fadeScore} · long {row.longScore}
          {row.cliff ? ` · cliff ${row.cliff.toFixed(1)}×` : ""}
        </p>
      ) : null}

      <div className="mt-4">
        <button
          type="button"
          onClick={loadBrief}
          disabled={busy}
          className="h-11 rounded-md bg-surface px-4 text-sm text-fg hover:bg-elevated disabled:opacity-40"
        >
          {busy ? "Chartist running…" : "Run Chartist desk"}
        </button>
        {note ? (
          <pre className="mt-3 whitespace-pre-wrap rounded-xl border border-line bg-surface p-4 font-sans text-sm leading-relaxed text-muted">
            {note}
          </pre>
        ) : null}
      </div>

      <div className="mt-6 grid gap-2 lg:grid-cols-2">
        {dhFades(rows, 4).map((r) => (
          <button
            key={r.symbol}
            type="button"
            onClick={() => {
              setInput(`${r.symbol}USDT`);
              setSymbol(`${r.symbol}USDT`);
            }}
            className="glass rounded-xl p-3 text-left"
          >
            <span className="font-mono text-sm font-semibold">{r.symbol}</span>
            <span className="ml-2 font-mono text-xs text-down">{pct(r.chg24)}</span>
            <p className="mt-1 text-xs text-muted">{r.thesis}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
