import { Link, createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { DhRow } from "@/components/dh-row";
import { GiList } from "@/components/gi-list";
import { MatrixPanel } from "@/components/matrix-panel";
import { CircledTape } from "@/components/circled-tape";
import { NowBook } from "@/components/now-book";
import { PageHead } from "@/components/page-head";
import { Sparkline } from "@/components/sparkline";
import { SuperMatrix } from "@/components/super-matrix";
import { WeatherBar } from "@/components/weather-bar";
import { BRAND } from "@/lib/brand";
import { dhFades, dhLongs, rotationBuckets, scoreDeepHeat } from "@/lib/market/deepheat";
import { pct, px, usd } from "@/lib/market/format";
import { useBtcBook, useTape, useTerra, useUniverse } from "@/lib/market/hooks";
import { SECTOR_LABEL } from "@/lib/market/sectors";
import { useGiBook, usePins } from "@/lib/market/use-desk";
import type { Sector } from "@/lib/market/types";

export const Route = createFileRoute("/")({ component: Desk });

function Desk() {
  const universe = useUniverse();
  const tape = useTape(true);
  const { pins, toggle } = usePins();
  const coins = universe.data?.coins ?? [];
  const movers = tape.data?.movers ?? [];
  const rows = useMemo(() => scoreDeepHeat(coins, movers), [coins, movers]);
  const prices = useMemo(() => {
    const p: Record<string, number> = {};
    for (const c of coins) p[c.symbol] = c.price;
    for (const m of movers) {
      const last = m.perp?.last ?? m.dex?.priceUsd;
      if (last) p[m.symbol.toUpperCase()] = last;
    }
    return p;
  }, [coins, movers]);
  const quotes = useMemo(() => {
    const q: Record<string, { price: number; chg: number | null }> = {};
    for (const c of coins) q[c.symbol] = { price: c.price, chg: c.chg24h };
    for (const m of movers) {
      const last = m.perp?.last ?? m.dex?.priceUsd;
      if (last) q[m.symbol.toUpperCase()] = { price: last, chg: m.perp?.change24h ?? m.dex?.changeH24 ?? null };
    }
    return q;
  }, [coins, movers]);
  const gi = useGiBook(rows, prices);
  const longs = dhLongs(rows, 4);
  const fades = dhFades(rows, 4);
  const rot = rotationBuckets(rows);
  const pulse = universe.data?.pulse;
  const tickers = ["BTC", "ETH", "SOL"].map((s) => coins.find((c) => c.symbol === s)).filter(Boolean);
  const btc = coins.find((c) => c.symbol === "BTC");

  return (
    <div>
      <PageHead kicker={BRAND.kicker} title={BRAND.tagline} />
      {pulse ? <WeatherBar pulse={pulse} onSector={() => {}} /> : null}

      <TapeCall quotes={quotes} />
      <CircledTape quotes={quotes} />
      <NowBook quotes={quotes} />

      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-sm font-medium">Super matrix · Sun → Wed</h2>
          <span className="font-mono text-[10px] uppercase tracking-widest text-faint">09:50 SAST</span>
        </div>
        <SuperMatrix quotes={quotes} />
      </section>

      <div className="mt-6 mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tickers.map((c) =>
          c ? (
            <section key={c.symbol} className="glass rounded-xl p-4">
              <p className="text-xs uppercase tracking-widest text-muted">{c.symbol}</p>
              <div className="mt-1 flex items-end justify-between gap-2">
                <p className="font-mono text-xl tabular text-fg">{px(c.price)}</p>
                <span
                  className={`inline-flex min-w-[4.5rem] justify-end rounded-md px-2 py-1 font-mono text-xs tabular font-medium ${
                    (c.chg24h ?? 0) >= 0 ? "bg-up/15 text-up" : "bg-down/15 text-down"
                  }`}
                >
                  {pct(c.chg24h)}
                </span>
              </div>
              <Sparkline values={c.spark} className="mt-2 h-8 w-28" />
            </section>
          ) : null,
        )}
        <section className="glass rounded-xl p-4">
          <p className="text-xs uppercase tracking-widest text-muted">Fear & Greed</p>
          <div className="mt-1 flex items-end justify-between gap-2">
            <p className="font-mono text-xl tabular">{pulse?.fng ?? "—"}</p>
            <span className="font-mono text-xs text-muted">{pulse?.fngLabel || "—"}</span>
          </div>
          <p className="mt-2 text-xs text-faint">{pulse?.weather === "risk-on" ? "Risk on" : pulse?.weather === "risk-off" ? "Risk off" : "Mixed"}</p>
        </section>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="glass rounded-xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium">Today's GI book</h2>
            <Link to="/ledger" className="font-mono text-xs uppercase tracking-wide text-muted hover:text-fg">
              Full ledger
            </Link>
          </div>
          <GiList marks={gi.open} limit={8} />
          <p className="mt-3 font-mono text-[11px] text-faint">
            Hit rate {(gi.stats.hit * 100).toFixed(0)}% · avg PnL {pct(gi.stats.avg * 100, 2)} · {gi.stats.settled}{" "}
            settled
          </p>
        </section>

        <section className="glass rounded-xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-medium">BTC liquidity seat</h2>
              <p className="font-mono text-xs text-muted">Mid {btc ? px(btc.price) : "—"}</p>
            </div>
            <Link to="/btc" className="font-mono text-xs uppercase tracking-wide text-muted hover:text-fg">
              Open heatmap
            </Link>
          </div>
          <p className="text-sm leading-relaxed text-muted">
            Alts inherit whatever happens at the BTC book. Sentinel maps 48h volume-at-price plus live rest ±1.2% of
            mid — green bids, red asks, walls and air pockets.
          </p>
          <BtcSeatHint />
        </section>
      </div>

      <TerraSeat />

      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-sm font-medium">DeepHeat longs</h2>
          <span className="font-mono text-[10px] uppercase tracking-widest text-faint">{BRAND.dh}</span>
        </div>
        <div className="grid gap-3 lg:grid-cols-2">
          {longs.length ? longs.map((r) => (
            <DhRow key={r.symbol} row={r} onPin={toggle} pinned={pins.includes(r.symbol.toUpperCase())} />
          )) : <Empty label="No break windows on this snapshot." />}
        </div>
      </section>

      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-sm font-medium">24h fade shorts</h2>
          <Link to="/shorts" className="font-mono text-xs uppercase tracking-wide text-muted hover:text-fg">
            Fade book
          </Link>
        </div>
        <div className="grid gap-3 lg:grid-cols-2">
          {fades.length ? fades.map((r) => (
            <DhRow key={r.symbol} row={r} onPin={toggle} pinned={pins.includes(r.symbol.toUpperCase())} />
          )) : <Empty label="No climax prints cleared the filter." />}
        </div>
      </section>

      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-sm font-medium">CMC-style rotation</h2>
          <Link to="/flow" className="font-mono text-xs uppercase tracking-wide text-muted hover:text-fg">
            Open flow
          </Link>
        </div>
        <div className="flex flex-wrap gap-2">
          {rot.map((r) => (
            <div key={r.sector} className="glass rounded-xl px-4 py-3">
              <div className="font-mono text-xs uppercase tracking-widest text-faint">
                {SECTOR_LABEL[r.sector as Sector] || r.sector}
              </div>
              <div className="mt-1 font-mono text-sm tabular">
                n= {r.n} · <span className={r.avg >= 0 ? "text-up" : "text-down"}>{pct(r.avg, 1)}</span>
              </div>
            </div>
          ))}
          {pulse?.categories.slice(0, 6).map((c) => (
            <div key={c.id} className="glass rounded-xl px-4 py-3">
              <div className="font-mono text-xs uppercase tracking-widest text-faint">{c.name}</div>
              <div className={`mt-1 font-mono text-sm tabular ${c.change24 >= 0 ? "text-up" : "text-down"}`}>
                {pct(c.change24, 1)} · {usd(c.mcap)}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-sm font-medium">Master book</h2>
          <Link to="/mint" className="font-mono text-xs uppercase tracking-wide text-muted hover:text-fg">
            Mint desk
          </Link>
        </div>
        <MatrixPanel quotes={quotes} />
      </section>
    </div>
  );
}

function TapeCall({ quotes }: { quotes: Record<string, { price: number; chg: number | null }> }) {
  const u = quotes.USELESS;
  const f = quotes.FF;
  const i = quotes.IOST;
  const v = quotes.VVV;
  return (
    <section className="mt-4 glass rounded-xl p-4">
      <p className="font-mono text-[10px] uppercase tracking-widest text-wait">Wed 09:50 desk call · circled tape locked</p>
      <h2 className="mt-1 text-sm font-medium">Your purple marks: ZEC/BTC/ETH are the bid. FF is the take. USELESS is a trigger. SOPH is dead.</h2>
      <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">
        09:35 said wait the 1h. 09:50: the 1h stalled. FF
        {f ? ` ${px(f.price)} ${pct(f.chg)}` : " +23%"} is pressing the 0.152 abort — if you are in, no add; if not, wait for a loss of 0.145. USELESS
        {u ? ` ${px(u.price)} ${pct(u.chg)}` : " +38%"} is a NEW ticket not revenge: fire on 0.320 then 0.312 AVL, stop
        0.337, half Sunday size. IOST
        {i ? ` ${px(i.price)} ${pct(i.chg)}` : " +23%"} isolated on red 15m. VVV
        {v ? ` ${px(v.price)} ${pct(v.chg)}` : ""} is Venice AI — not a P&D. SOPH −45% and FORM −20% are already the
        dump. Trail MARS leftover, do not add.
      </p>
    </section>
  );
}

function BtcSeatHint() {
  const book = useBtcBook();
  const d = book.data;
  if (!d?.mid) return null;
  const wall = d.walls.find((w) => w.size >= 0.05);
  return (
    <div className="mt-3 space-y-1">
      <p className={`font-mono text-xs tabular ${d.imbalance >= 0.55 ? "text-up" : d.imbalance <= 0.45 ? "text-down" : "text-muted"}`}>
        {(d.imbalance * 100).toFixed(0)}% of the ±1.2% band is bids
      </p>
      {wall ? (
        <p className="font-mono text-[11px] text-faint">
          Wall {wall.side} {wall.price.toFixed(0)} · {wall.size.toFixed(2)} BTC · {usd(wall.usd, 0)}
        </p>
      ) : null}
    </div>
  );
}

function TerraSeat() {
  const terra = useTerra();
  const d = terra.data;
  if (!d) return null;
  const lunc = d.assets.find((a) => a.id === "lunc");
  const hard = d.impostors.find((i) => i.verdict === "SHORT_HARD");
  return (
    <section className="mt-4 glass rounded-xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-medium">Terra desk</h2>
          <p className="mt-1 max-w-2xl text-sm leading-relaxed text-muted">
            {hard
              ? `Native LUNC ${pct(lunc?.chg24h)} is not the print. ${hard.chain} ${hard.symbol} is ${pct(hard.chgH24, 0)} on a ${usd(hard.liq, 0)} pool · CLIFF ${hard.cliff.toFixed(0)}×.`
              : `columbus-5 and phoenix-1 are live. LUNC ${pct(lunc?.chg24h)} — burn-narrative, not a pool cliff.`}
          </p>
        </div>
        <Link to="/terra" className="inline-flex h-10 items-center rounded-sm bg-accent px-3 text-sm text-accent-fg">
          Open Terra
        </Link>
      </div>
    </section>
  );
}

function Empty({ label }: { label: string }) {
  return <p className="rounded-xl border border-dashed border-line px-4 py-8 text-sm text-muted">{label}</p>;
}
