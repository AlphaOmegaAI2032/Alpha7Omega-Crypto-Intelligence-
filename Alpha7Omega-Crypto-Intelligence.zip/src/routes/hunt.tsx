import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { DetailSheet } from "@/components/detail-sheet";
import { DhRow } from "@/components/dh-row";
import { IntelPanel } from "@/components/intel-panel";
import { PageHead } from "@/components/page-head";
import { RadarDesk } from "@/components/radar-desk";
import { BRAND } from "@/lib/brand";
import { scoreDeepHeat } from "@/lib/market/deepheat";
import { pct, px, usd } from "@/lib/market/format";
import { useBreakouts, useTape, useUniverse } from "@/lib/market/hooks";
import { isStable, SECTOR_LABEL } from "@/lib/market/sectors";
import { usePins } from "@/lib/market/use-desk";
import type { BreakoutHit, ScoredMover } from "@/lib/market/types";

export const Route = createFileRoute("/hunt")({ component: HuntPage });

type HuntTab = "gainers" | "dex" | "whales" | "deepheat";

function HuntPage() {
  const [tab, setTab] = useState<HuntTab>("gainers");
  const [intelSymbol, setIntelSymbol] = useState("MARSCOIN");
  const [hit, setHit] = useState<BreakoutHit | null>(null);
  const [mover, setMover] = useState<ScoredMover | null>(null);
  const universe = useUniverse();
  const tape = useTape(true);
  const brk = useBreakouts(tab === "dex");
  const { pins, toggle } = usePins();
  const coins = universe.data?.coins ?? [];
  const movers = tape.data?.movers ?? [];
  const rows = useMemo(() => scoreDeepHeat(coins, movers), [coins, movers]);
  const gainers = useMemo(
    () =>
      [...coins]
        .filter((c) => !isStable(c.symbol) && (c.chg24h ?? 0) > 0)
        .sort((a, b) => (b.chg24h ?? 0) - (a.chg24h ?? 0))
        .slice(0, 40),
    [coins],
  );
  const mars = movers.find((m) => m.symbol.toUpperCase() === "MARSCOIN") ?? null;
  const useless = movers.find((m) => m.symbol.toUpperCase() === "USELESS") ?? null;

  return (
    <div>
      <PageHead kicker="Hunt" title="DEX scanner + USDT-M gainers" />
      <p className="mb-4 text-sm text-muted">
        Direct APIs: Gate perps, GeckoTerminal, DexScreener boosts. {BRAND.dh} on top. Visual whale cliff on{" "}
        <Link to="/flow" className="text-fg underline">
          Flow
        </Link>
        . Paste a CA on{" "}
        <Link to="/mint" className="text-fg underline">
          Mint
        </Link>
        .
      </p>
      <div className="mb-4 flex gap-1 overflow-x-auto rounded-lg bg-surface p-1">
        {([
          ["gainers", "Gainers"],
          ["dex", "DEX"],
          ["whales", "Whales"],
          ["deepheat", "DeepHeat"],
        ] as const).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`h-11 flex-1 rounded-md px-3 text-sm ${tab === id ? "bg-accent text-accent-fg" : "text-muted"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "gainers" ? (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-[0.16em] text-muted">
              <tr className="border-b border-line">
                <th className="py-2 font-medium">Market</th>
                <th className="py-2 font-medium">Last</th>
                <th className="py-2 font-medium">24h</th>
                <th className="py-2 font-medium">Vol</th>
                <th className="py-2 font-medium">Sector</th>
              </tr>
            </thead>
            <tbody>
              {gainers.map((c) => (
                <tr key={c.id} className="border-b border-line/70">
                  <td className="py-2">
                    <Link to="/ta" search={{ s: `${c.symbol}USDT` }} className="font-mono font-semibold hover:underline">
                      {c.symbol}
                    </Link>
                    <div className="text-xs text-faint">{c.name}</div>
                  </td>
                  <td className="py-2 font-mono tabular">{px(c.price)}</td>
                  <td className={`py-2 font-mono tabular ${(c.chg24h ?? 0) >= 0 ? "text-up" : "text-down"}`}>
                    {pct(c.chg24h)}
                  </td>
                  <td className="py-2 font-mono tabular text-muted">{usd(c.volume)}</td>
                  <td className="py-2 font-mono text-xs text-faint">{SECTOR_LABEL[c.sector]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      {tab === "dex" ? (
        <RadarDesk
          hits={brk.data?.hits ?? []}
          loading={brk.isLoading}
          error={brk.isError}
          notes={brk.data?.sourceNotes}
          mars={mars}
          useless={useless}
          onOpenHit={(h) => setHit(h)}
          onOpenMover={(m) => setMover(m)}
        />
      ) : null}

      {tab === "whales" ? <IntelPanel symbol={intelSymbol} onSymbol={setIntelSymbol} /> : null}

      {tab === "deepheat" ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {rows.slice(0, 16).map((r) => (
            <DhRow key={r.symbol} row={r} onPin={toggle} pinned={pins.includes(r.symbol.toUpperCase())} />
          ))}
        </div>
      ) : null}

      <DetailSheet
        open={!!hit || !!mover}
        onOpenChange={(v) => {
          if (!v) {
            setHit(null);
            setMover(null);
          }
        }}
        target={mover ? { mode: "mover", item: mover } : hit ? { mode: "hit", item: hit } : null}
        pinned={pins}
        onTogglePin={toggle}
      />
    </div>
  );
}
