import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { GiTable } from "@/components/gi-list";
import { PageHead } from "@/components/page-head";
import { scoreDeepHeat } from "@/lib/market/deepheat";
import { pct } from "@/lib/market/format";
import { useTape, useUniverse } from "@/lib/market/hooks";
import { useGiBook } from "@/lib/market/use-desk";

export const Route = createFileRoute("/ledger")({ component: LedgerPage });

function LedgerPage() {
  const universe = useUniverse();
  const tape = useTape(true);
  const rows = useMemo(
    () => scoreDeepHeat(universe.data?.coins ?? [], tape.data?.movers ?? []),
    [universe.data?.coins, tape.data?.movers],
  );
  const prices = useMemo(() => {
    const p: Record<string, number> = {};
    for (const c of universe.data?.coins ?? []) p[c.symbol] = c.price;
    return p;
  }, [universe.data?.coins]);
  const gi = useGiBook(rows, prices);
  const [day, setDay] = useState<"all" | string>("all");
  const days = useMemo(() => ["all", ...Array.from(new Set(gi.marks.map((m) => m.day)))], [gi.marks]);
  const shown = day === "all" ? gi.marks : gi.marks.filter((m) => m.day === day);

  return (
    <div>
      <PageHead kicker="GI ledger" title="Every recommendation, dated" />
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Settled" value={String(gi.stats.settled)} />
        <Stat label="Targets" value={String(gi.stats.targets)} />
        <Stat label="Stopped" value={String(gi.stats.stopped)} />
        <Stat label="Expired" value={String(gi.stats.expired)} />
      </div>
      <p className="mb-3 font-mono text-xs text-faint">
        Hit rate {(gi.stats.hit * 100).toFixed(0)}% · avg PnL {pct(gi.stats.avg * 100, 2)} · {gi.stats.open} open
      </p>
      <div className="mb-3 flex flex-wrap gap-1">
        {days.map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => setDay(d)}
            className={`h-8 rounded-sm px-2.5 text-xs ${day === d ? "bg-accent text-accent-fg" : "bg-surface text-muted"}`}
          >
            {d === "all" ? "All days" : d}
          </button>
        ))}
      </div>
      <section className="glass rounded-xl p-4">
        <GiTable marks={shown} />
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <section className="glass rounded-xl p-4">
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted">{label}</p>
      <p className="mt-1 font-mono text-2xl tabular">{value}</p>
    </section>
  );
}
