import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHead } from "@/components/page-head";
import { GODMODE_DESKS, type GodmodeDeskId } from "@/lib/market/godmode";

export const Route = createFileRoute("/godmode")({ component: GodmodePage });

function GodmodePage() {
  const [desk, setDesk] = useState<GodmodeDeskId>("fade");
  const [force, setForce] = useState(false);
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState<string | null>(null);
  const [meta, setMeta] = useState<string | null>(null);
  const current = GODMODE_DESKS.find((d) => d.id === desk)!;

  async function run() {
    setBusy(true);
    setMeta(null);
    try {
      const res = await fetch("/api/godmode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ desk, force }),
      });
      const json = (await res.json()) as {
        ok?: boolean;
        text?: string;
        error?: string;
        cached?: boolean;
        at?: number;
      };
      if (!json.ok) {
        setText(json.error || "Desk failed.");
        setMeta("error");
        return;
      }
      setText(json.text || "");
      setMeta(json.cached ? "Cached — one run per desk per day. Force re-run spends quota." : "Fresh run.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHead kicker="Godmode" title="Eight Grok desks" />
      <p className="mb-4 max-w-3xl text-sm text-muted">
        Grok 4.5. One run per desk per day is cached. Force re-run spends quota. Snapshot of live gainers, DeepHeat,
        BTC and mint is attached.
      </p>
      <div className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {GODMODE_DESKS.map((d) => (
          <button
            key={d.id}
            type="button"
            onClick={() => {
              setDesk(d.id);
              setText(null);
              setMeta(null);
            }}
            className={`rounded-xl border p-4 text-left ${
              desk === d.id ? "border-accent bg-elevated" : "border-line bg-surface hover:border-line-strong"
            }`}
          >
            <div className="font-medium">{d.name}</div>
            <div className="mt-1 text-xs text-muted">{d.role}</div>
          </button>
        ))}
      </div>
      <section className="glass rounded-xl p-4">
        <h2 className="text-lg font-medium">{current.name}</h2>
        <p className="mt-1 text-sm text-muted">{current.brief}</p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={run}
            disabled={busy}
            className="h-11 rounded-md bg-accent px-4 text-sm text-accent-fg disabled:opacity-40"
          >
            {busy ? "Running…" : "Run desk"}
          </button>
          <label className="flex h-11 items-center gap-2 font-mono text-xs uppercase tracking-wide text-muted">
            <input type="checkbox" checked={force} onChange={(e) => setForce(e.target.checked)} />
            Force
          </label>
        </div>
        {!text && !busy ? (
          <p className="mt-4 text-sm text-muted">No brief yet for this desk today. Run it — the live snapshot is attached.</p>
        ) : null}
        {text ? (
          <pre className="mt-4 whitespace-pre-wrap font-sans text-sm leading-relaxed text-fg">{text}</pre>
        ) : null}
        {meta ? <p className="mt-3 font-mono text-[11px] text-faint">{meta}</p> : null}
      </section>
    </div>
  );
}
